# Declare a new coupling

Order: **`add` first, `why -m` second**, same logical step — not "check `why` first" as a
gate. `why` with no `-m` only reads; it never blocks `add`.

```
git span add <name> <path>#L<start>-L<end> <path2>#L<start2>-L<end2> ...
git span why <name> -m "One sentence: name the subsystem, say what it does across anchors."
git add .span && git commit -m "..."
```

**Anchors**: `<path>` = whole file; `<path>#L<start>-L<end>` = 1-indexed, inclusive line
range. Run `wc -l <path>` right before writing the anchor, especially right after editing
that same file — `add` rejects with `end=N exceeds file line count (M)` if the range
overshoots the file's current length, and the range must land exactly on the intended
lines (an off-by-one still succeeds if it's within bounds, it just anchors the wrong lines).

**Name grammar** (enforced, not just a convention): kebab-case segments separated by `/`
(e.g. `<slug>`, `<category>/<slug>`), each segment lowercase `a-z`/`0-9`/`-` and must
*start* with a letter or digit. A leading dot or uppercase letter fails immediately:
`error: invalid name: ... segment must start with a-z or 0-9`. Never name a span after a
literal dotfile path (`.github/workflows` is invalid) — pick a descriptive subsystem slug
instead (e.g. `ci/workflow-config`).

**`why` content**: one sentence, definitional — name the subsystem/flow and what it does
across the anchors, in role-words ("the parser", "the doc"), not filenames. Evergreen:
only rewrite it when the relationship itself changes, not on routine re-anchors.

Always finish with `git add .span && git commit -m "..."` — the span file lives under
`.span/` and is an ordinary tracked file; nothing is durable until committed.
