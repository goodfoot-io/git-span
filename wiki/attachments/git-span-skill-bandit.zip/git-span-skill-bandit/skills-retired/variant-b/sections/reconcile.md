# Reconcile drift / re-anchor and retire

`git span stale` human output, per drifting span:
```
## <span-name>
- <path>#L<start>-L<end> — changed in the working tree
- <path>#L<start>-L<end> — moved to <path>#L<newstart>-L<newend>

<why prose>

---
```
(`---` separates multiple spans; last span has no trailing `---`.) Exits **1** whenever any
drift is found — add `--no-exit-code` if chaining with `&&`.

**`--fix` cannot be trusted alone.** It only re-anchors `Moved` anchors and
whitespace-only `Changed` anchors. A `Changed` anchor whose content differs beyond
whitespace is left drifting on purpose (`Reconciled 0 spans, 0 anchors` and `stale` still
reports it) so a human confirms the coupling still holds. Don't rerun `--fix` expecting a
different result — re-anchor directly instead:

1. Read the diff at each drifting anchor; decide if the coupling still holds.
2. Re-anchor: `git span add <name> <path>#L<start>-L<end> ...` — run `wc -l <path>` first
   and use its current count; `add` rejects `end=N exceeds file line count (M)`.
3. If the anchor moved to a **different file** (not just shifted lines in the same file),
   retire the old one — `add` never removes what it supersedes:
   `git span remove <name> <old-path>#L<a>-L<b>` then `git span add <name> <new-path>#L<c>-L<d>`.
   Skipping `remove` leaves `stale` reporting the old anchor as `Moved` forever.
4. If the relationship itself changed (not just its location), refresh: `git span why
   <name> -m "..."`. Then `git add .span && git commit -m "..."`.
5. Re-run `git span stale <name>` to confirm exit 0 — don't just trust step 2 succeeded.

Scope `--fix`/re-anchoring to `<name>` or `<path>` when only one coupling is under repair;
a bare `git span stale --fix` scans and rewrites every span in the repo.

**Selector trap**: `stale <arg>` matches `<arg>` as a span name or an anchored path. If
`<arg>` is a real, tracked file that just isn't anchored by any span, you get a silent
`0 stale across 0 spans` (exit 0) — not an error. Only a genuinely nonexistent path errors
with "is not tracked". A clean zero-anchor result on a name/path you expected to be spanned
means check the spelling with `git span list`, not "already fixed".
