# Reference: delete, nonexistent flags, secondary commands

**`git span delete <name>`** — `<NAME>` only, no anchor args, no note/rationale flag; any
extra positional is a hard arg-parse error (exit 2). Record rationale via `git span why
<name> -m "..."` *before* deleting, or in the commit message. Used for a dead coupling, or
as the overwrite idiom during a rename (`delete` then re-`add` under the new name, instead
of `remove`+`add` when every anchor is being replaced at once).

**Flags that do not exist on this build — don't spend a `--help` call discovering this**:
`git span move` (no such subcommand at all — re-anchor is always `remove`+`add`, or
`delete`+`add`), `add --replace`, `why --at`/`-F`/`--edit`, `show --at`/`--patch`,
`stale --patch`/`--stat`/`--worktree`/`--staged`/`--head`/`--search`,
`list --search`/`--batch`, `doctor --strict`.

**Secondary, read-only, near-zero real usage — one line each, no flag deep-dive:**

- `git span tree <glob>... [-d N] [--format human|json]` — blast-radius impact tree from
  matched anchor paths outward through span co-occurrence; roots are paths/globs only, no
  span names or `#L` ranges.
- `git span doctor` — audits local span setup; run once at setup time, not part of any
  regular workflow.
- `git span merge-driver` — invoked automatically by git as a registered merge driver for
  `.span/` conflicts; never invoke manually.
