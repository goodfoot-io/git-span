# Inspect spans (read-only — no `add`/`remove`/`delete`/`commit` here)

Match the question to the command, don't reflexively mutate:

- Existence / what's currently anchored → `git span list [<target>...]` (all spans if no
  target; `--oneline` for terse `<span-name> <path>#Lx-Ly` rows) or
  `git span show <name>` (== bare `git span <name>`) for one span's full anchors+why+config.
- Rationale / definition → `git span why <name>` (bare, no `-m`, just prints the current why).
- Timeline / when something changed → `git span history <name>` — XML by default
  (`<commit>` blocks oldest→newest, plus a trailing `<current>` block if the worktree has
  drifted from HEAD), `--format json` for JSON.
- Drift check without fixing anything → `git span stale [<name-or-path>]` — read-only unless
  `--fix` is passed; omit `--fix` here.

**`stale --format json` is one JSON object, not NDJSON and not an array of per-anchor
records**: `{"findings": [...], "schema_version": N, "span": "..."}`, where `findings` holds
every drifting anchor across all matched spans. Parse it as one JSON document. When nothing
is stale, output is empty (no `{}`, no bytes at all) — don't `json.loads` an empty string
without checking for that case first.

**Selector trap**: `list`/`show`/`why`/`history`/`stale` all resolve their `<name>`/`<target>`
argument as a span name *or* a file path — never assume one. Passing a real, tracked file path
that happens not to be anchored by any span does **not** error: `list` prints
"No spans match the filters." and `stale` prints "0 stale across 0 spans", both exit 0. Only
a path that doesn't exist in the working tree at all produces an explicit error ("is not
tracked" / "did not match any span, file, or path"). Before reporting "no such span" in
answers, re-check the exact name/path against `git span list` — a silent-empty result is not
proof the span doesn't exist.
