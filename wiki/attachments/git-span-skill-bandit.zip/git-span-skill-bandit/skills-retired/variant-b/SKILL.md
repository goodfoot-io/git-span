---
name: git-span
description: Create, reconcile, inspect, and manage git spans — anchored file couplings with a durable why.
---

```
git span stale [<name-or-path>] [--fix] [--no-exit-code] [--format human|porcelain|json]
git span add <name> <anchor>...          # declare or re-anchor; anchor = path or path#Lx-Ly
git span why <name> [-m "..."]           # bare = read; -m = write, after add/remove
git span remove <name> <anchor>...       # paired with add to retire a superseded anchor
git span delete <name>                   # dead coupling, or overwrite-idiom during renames
git span list [<target>...] [--oneline]  # positional filter, not --search
git span show <name>   (== bare `git span <name>`)
```

- `git span stale` reports drift (Changed/Moved) on an edited file, `--fix` ran but the same
  anchor still shows stale, or an anchored block moved to a new file and the old anchor needs
  retiring: read `./sections/reconcile.md`
- A coupling (code/code, code/doc, code/test) has no span yet and needs one declared with a
  name, anchors, and why before committing: read `./sections/declare.md`
- Read-only questions — what spans exist, what a span's anchors/why currently say, or its
  history — answerable via `list`/`show`/`why`/`history`: read `./sections/inspect.md`
- Need `delete`'s exact arg shape, confirmation a flag doesn't exist, or a one-line pointer to
  `tree`/`doctor`/`merge-driver`: read `./sections/reference.md`
