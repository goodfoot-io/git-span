---
name: git-span
description: Track and reconcile file-anchored semantic couplings with git span (stale, add, why, remove, delete, list, show, history).
---

## Reconcile loop (drift on an already-anchored coupling)

```bash
git span stale [<name-or-path>]
# --fix only clears Moved anchors and whitespace-equivalent Changed — NOT content drift
wc -l <path>                                          # confirm current line count before re-anchoring
git span add <name> <path>#L<start>-L<end> ...
git span why <name> -m "..."                          # only if the relationship itself changed
git add .span && git commit -m "..."
git span stale [<name-or-path>]                       # recheck: must exit 0 / print "0 stale"
```

Watch for:
- `--fix` silently no-ops on content-level Changed anchors — it reports success but the anchor
  stales again next check. Re-anchor with `add` directly; don't trust `--fix` alone here.
- `stale <arg>` where `<arg>` is an existing file with no anchors returns "0 stale across 0
  spans" and exits 0 — reads as clean but really means nothing matched. Verify with `git span
  list` if that's unexpected.
- `stale` exits 1 whenever drift exists (normal mid-loop); only the final recheck must exit 0.
  Use `--no-exit-code` if you need to keep a `&&` chain alive while drift remains.
- Unscoped `stale --fix` (no name/path) rewrites every span in the repo — scope it to
  `<name-or-path>` when only one coupling is under repair.

## Declare-then-justify (new, undeclared coupling)

```bash
wc -l <path> ...                                      # confirm line counts before anchoring
git span add <name> <path>#L<start>-L<end> ...        # or bare <path> for a whole-file anchor
git span why <name> -m "one-sentence definition, role-words, survives rewrites"
git add .span && git commit -m "..."
```

Watch for:
- `<name>` must be kebab-case segments (`a-z0-9` start, `-` internal, `/`-separated categories);
  a leading dot or dotfile-style name (e.g. `.github`) is rejected — pick a descriptive slug.
- `add` errors `end=N exceeds file line count (M)` if the anchor overruns EOF — `wc -l` right
  before writing the anchor, especially right after editing that same file.
- `why -m "..."` must be non-empty prose; bare `git span why <name>` only reads, never writes.

## Re-anchor + retire (coupling moved to a new location)

```bash
git span remove <name> <old-anchor>
wc -l <new-path>                                       # confirm current line count
git span add <name> <new-anchor>
git span why <name> -m "..."                            # only if the relationship itself changed
git add .span && git commit -m "..."
git span stale [<name>]                                 # recheck: old anchor gone, must exit 0
```

Watch for:
- `add` never retires the anchor it supersedes — skipping `remove` leaves the old anchor on the
  span and `stale` keeps reporting it as drifted. Always pair `remove` (old) + `add` (new).
- Full-overwrite alternate: `git span delete <name>` then `git span add <name> <anchor>...` +
  `git span why <name> -m "..."` recreates the span from scratch instead of editing in place.
- Confirm with a fresh `git span stale` after committing — don't just trust `remove`/`add`
  exiting 0.

## Inspect (read-only — no `add`/`remove`/`why -m`/commit in this recipe)

```bash
git span list [<target>]         # --oneline for terse; filters by path, #Lx-Ly range, or name
git span show <name>             # == bare `git span <name>`; prints anchors + why + config
git span why <name>               # bare = read-only, prints the why text
git span history <name>           # --format xml (default) or json; -n/--limit caps the walk
```

Watch for:
- `list`/`stale`/`show` match on span *name* or *file path*. An existing-but-unanchored file
  path returns empty/"0" cleanly (exit 0) rather than erroring — that's a wrong-target hint,
  not proof "no coupling exists." A name/path that isn't tracked at all *does* error clearly
  ("is not tracked").
- `history` defaults to XML output; pass `--format json` if you need to parse it programmatically.

---

Also exists, read-only or automatic, rarely invoked directly: `git span tree <globs>` (blast-radius
trace), `git span doctor` (local setup audit), `git span merge-driver` (registered as a git merge
driver for `.span/`, never run by hand).

Not in this build (v1.0.134) — don't spend a `--help` call discovering these: no `move`
subcommand (re-anchor is `remove` + `add`); no `--replace` on `add`; no `--patch`/`--stat`/
`--worktree`/`--staged`/`--head`/`--search`/`--batch` on any subcommand; `why`/`show` take no
`--at`/`-F`/`--edit` despite the help prose mentioning them — only each command's `Options:`
list is authoritative.
