# git-span skill bandit test — shared contract

All components live under `/tmp/git-span-skill-test/`. Every piece must honor these interfaces exactly.

## Directory layout

```
CONTRACT.md                  # this file
research/                    # skill-authoring research + variant design briefs
skills/
  variant-a/SKILL.md         # candidate skills (may have sibling files, e.g. sections/)
  variant-b/SKILL.md
  variant-c/SKILL.md
envs/
  scenarios/<name>/
    setup.sh                 # bash setup.sh <dest-dir> — builds a fresh, deterministic
                             #   fixture git repo (with .span/ corpus) at <dest-dir>.
                             #   Idempotent per fresh dest. No network. Exit 0 on success.
    task-prompt.md           # the user prompt for the haiku agent. Contains the literal
                             #   placeholder {{SKILL_PATH}} where the absolute SKILL.md
                             #   path is substituted. Must instruct: read that file for
                             #   git-span guidance; do not read other docs except
                             #   `git span --help` / subcommand --help.
    grade.sh                 # bash grade.sh <env-dir> — deterministic terminal-state
                             #   grader. Exit 0 = pass, nonzero = fail. Prints reason
                             #   lines to stdout. Never inspects transcripts.
runner/
  run-trial.sh               # bash run-trial.sh <variant> <scenario> — one full trial:
                             #   fresh env → claude -p (haiku) → grade → measure chars
                             #   → append one JSON line to results/trials.jsonl → print it.
  bandit.py                  # python3 bandit.py next   → prints variant name to run next
                             #   python3 bandit.py report → posteriors + significance
results/
  trials.jsonl               # one JSON object per trial (schema below)
  envs/<trial-id>/           # each trial's env dir, kept for audit
```

## Trial record schema (results/trials.jsonl, one line each)

```json
{"trial_id": "t001", "ts": "2026-07-17T…Z", "variant": "variant-a",
 "scenario": "reconcile-drift", "session_id": "…", "env_dir": "…",
 "pass": true, "grade_output": "…", "main_chars": 12345,
 "subagent_chars": 0, "total_chars": 12345, "reward": 8.1e-5,
 "duration_s": 93, "notes": ""}
```

`reward` = 0 if `pass` is false, else `1 / total_chars`.
`total_chars` = byte-length sum of the session's main transcript `.jsonl` plus any
subagent transcript files attributable to that session (runner must discover the
transcript path convention empirically and document it in runner/NOTES.md).

## Haiku invocation (runner)

- cwd = the fresh env dir.
- `claude -p "<prompt>" --model haiku --output-format json --dangerously-skip-permissions`
- Session id comes from the JSON result (`session_id` field).
- Wall timeout 10 minutes per trial (kill ⇒ pass=false, note="timeout").
- The env dir is isolated; the haiku agent must NOT be pointed at /workspace.

## Bandit (bandit.py)

- Arms = variant dirs present under skills/.
- Two-level Thompson sampling: Beta(1+successes, 1+failures) on success probability;
  Normal posterior on log(total_chars) of successes (conjugate, weak prior) for the
  efficiency term. Sampled expected reward = p_sample * exp(-mu_sample) approximation
  via sampling: draw p ~ Beta, draw log-chars ~ posterior predictive, reward = p / exp(logc).
- Scenario rotation: round-robin over scenarios independent of arm choice, so each
  arm sees a balanced scenario mix.
- Seed phase: first 3 trials per arm are forced (rotating scenarios) before Thompson
  allocation starts. Phase-1 cap: 15 trials total.
- `report` must print: per-arm trials/successes/mean chars, P(arm is best) from 20k
  posterior draws, pairwise P(a beats b), and a frank significance statement
  (this round is deliberately underpowered; report exact posteriors, plus Fisher's
  exact p-value on success counts for the leading pair).

## Scenarios (phase 1)

Four scenarios targeting the real usage distribution from
/workspace/reports/used-git-mesh-functionality.md:

1. `reconcile-drift` — repo where an anchored file was edited post-commit; task: reconcile
   stale spans (stale → judge → re-anchor via add → why refresh → commit). Grader checks
   `git span stale` exits clean and the span's anchors/why match expectations.
2. `declare-coupling` — repo with an obvious undeclared coupling; task: declare it with
   correct name/anchors/why and commit. Grader checks span exists, name shape, anchors
   land on the right lines, why is non-empty prose, committed.
3. `reanchor-retire` — repo where an anchored block moved to a new file; task: re-anchor
   to the new location and retire the old anchor (remove + add, or delete+recreate).
   Grader checks old anchor gone, new anchor present, stale clean.
4. `inspect-report` — read-only: task asks specific questions answerable via
   list/show/why/history (agent writes answers to ANSWERS.md in the env dir).
   Grader checks ANSWERS.md content against known facts. No repo mutation expected.

Scenario authors: verify every scenario end-to-end by hand (run setup, perform the
intended solution manually with git-span CLI, run grader → must pass; run grader on
untouched env → must fail, except inspect-report which must fail on missing/wrong
ANSWERS.md).

## Round 2 (adopted after phase-1 methodology review)

Phase-1 findings driving this design: 15/15 pass (ceiling effect — success carried no
signal) and a scenario-mix confound (Thompson + arm-independent rotation gave arms
unbalanced scenario diets, biasing raw char comparisons).

**Allocation: scenario-matched complete blocks.** A block = one scenario run once by
EVERY active arm (arm order rotates per block for time-fairness). Blocks cycle
round-robin over all scenarios (old 4 + new 2 = 6). Round-2 cap: 18 trials
(one complete 3-arm × 6-scenario grid). `bandit.py next2` implements this; trial
records gain a `"block"` field (`"r2-<scenario>-1"`).

**Two new failure-capable scenarios** under envs/scenarios/:

5. `triage-mixed-drift` — three spans drift simultaneously in one repo, each demanding a
   DIFFERENT resolution: (i) one whole-file-rename Moved anchor (auto-fixable), (ii) one
   content-level Changed anchor where the coupling still holds (manual re-anchor, why
   intact), (iii) one span whose counterpart content was deliberately deleted from the
   project (coupling is dead → span must be deleted). Task states the end goal only
   ("bring span tracking back into a fully consistent, truthful state"), not the per-span
   resolutions. Grader: stale clean; moved span re-anchored at new path; changed span
   re-anchored with why intact; dead span GONE (not re-anchored to unrelated content);
   committed.
6. `consistent-update` — task asks for a real code change ("raise the retry limit to 7,
   keeping the repository fully consistent — `git span stale` must stay clean and all
   documentation truthful"). The value is span-coupled code+doc. Agent must edit BOTH
   sides, re-anchor the drifted span, and commit. Grader: new value present in code AND
   doc; span anchors still cover both sites; stale clean; committed. Fails if the agent
   edits one side only, or edits both but leaves the span drifted.

**Round-2 report (`bandit.py report2`)**: per-scenario stratified table (each arm's chars
per scenario, winner per scenario); overall posterior P(best) computed with equal scenario
weights (per-scenario Normal posteriors on log-chars aggregated, success handled per-arm
Beta as before); paired sign test across scenario blocks for the leading pair; the same
frank underpowering statement. Phase-1 trials stay in trials.jsonl but are excluded from
round-2 stats (filter on the `block` field).
