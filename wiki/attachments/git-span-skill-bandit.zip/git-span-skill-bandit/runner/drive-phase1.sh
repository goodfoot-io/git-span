#!/bin/bash
# Phase-1 driver: loop bandit.py next -> run-trial.sh until the 15-trial cap.
set -u
cd /tmp/git-span-skill-test || exit 1

while true; do
  pick=$(python3 runner/bandit.py next) || { echo "bandit next failed"; exit 1; }
  case "$pick" in
    STOP*) echo "BANDIT: $pick"; break ;;
  esac
  variant=${pick%% *}
  scenario=${pick##* }
  echo "=== $(date -u +%H:%M:%S) trial start: $variant / $scenario ==="
  bash runner/run-trial.sh "$variant" "$scenario" || echo "!!! trial errored for $variant/$scenario (continuing)"
done

echo
echo "================ PHASE 1 REPORT ================"
python3 runner/bandit.py report
