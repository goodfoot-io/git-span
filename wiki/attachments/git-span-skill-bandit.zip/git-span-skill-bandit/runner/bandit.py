#!/usr/bin/env python3
"""Two-level Thompson-sampling bandit over git-span skill variants.

Usage:
    bandit.py next     -> prints "<variant> <scenario>" (or "STOP cap-reached")
    bandit.py report   -> prints the per-arm posterior report (phase-1 only)
    bandit.py next2    -> prints "<variant> <scenario> <block-id>" (round-2
                          scenario-matched complete blocks) (or "STOP cap-reached")
    bandit.py report2  -> prints the round-2-only stratified report
    bandit.py next3    -> same as next2 but for round 3 (block-id prefix
                          "r3-", cap 24; see NOTES.md §10)
    bandit.py report3  -> same as report2 but for round 3 (r3- blocks only)
    bandit.py next4    -> round 4 ("confirmation round"): a FIXED 3-scenario
                          subset (ROUND4_SCENARIOS, not full discovery),
                          block-id prefix "r4-", cap 12; see NOTES.md §11
    bandit.py report4  -> report3-shaped stratified report over just the 3
                          round-4 scenarios (r4- blocks only), PLUS a pooled
                          r3+r4 paired sign test for two named "confirmation
                          pairs" (ROUND4_POOLED_PAIRS)

Stdlib only (random, math, json, statistics). See CONTRACT.md for the exact
policy this implements and runner/NOTES.md for empirical context (§9 for the
round-2 design, §10 for generalizing to round 3, §11 for round 4's fixed
scenario subset and pooled analysis).

Env var overrides (defaults match CONTRACT.md paths exactly; tests point
these at fixture directories):
    SKILLS_ROOT     default: <base>/skills
    SCENARIOS_ROOT  default: <base>/envs/scenarios
    TRIALS_PATH     default: <base>/results/trials.jsonl
    SEED            if set, seeds the RNG for fully deterministic output.

Policy summary, phase 1 (CONTRACT.md):
  - Arms = variant dirs under skills/ containing SKILL.md, excluding any
    name starting with "smoke" (defensive -- CONTRACT never puts smoke
    fixtures there, but bandit.py must not treat them as arms if it happens).
  - Seed phase: each arm is forced to 3 trials (round-robin, i.e. always
    pick the globally least-used arm, alphabetical tiebreak) before Thompson
    sampling kicks in.
  - Scenario choice is independent of arm choice: always the least-used
    scenario (alphabetical tiebreak), so every arm sees a balanced mix.
  - Phase-1 cap: once 15 trials (across recognized arms) exist, `next`
    prints "STOP cap-reached" and does nothing else.
  - Thompson draw per arm: p ~ Beta(1+successes, 1+failures). For the
    efficiency term, a Normal-Normal (known-variance approx) conjugate
    posterior on the mean of log(total_chars) of *successful* trials, weak
    prior mean=log(3e5), strength=1 pseudo-observation, variance = sample
    variance of that arm's successes' log-chars (floored -- see FLOOR_VAR --
    to avoid degenerate/zero variance with 0-2 data points). Draw logc from
    the posterior *predictive* (posterior-mean uncertainty + observation
    noise). Sampled reward = p * exp(-logc). Arm with the max sampled reward
    wins ties broken alphabetically for full determinism).
  - `next`/`report` only ever look at trials WITHOUT a `"block"` field, so
    they stay correct once round-2 trials (which do have that field) start
    landing in the same trials.jsonl.

Policy summary, round 2 (CONTRACT.md "Round 2" section): phase-1 hit a
ceiling effect (15/15 pass -- no signal in success rate) and a scenario-mix
confound (independent scenario rotation gave arms unbalanced scenario
diets). Round 2 fixes both with scenario-matched complete blocks instead of
Thompson allocation, and equal-scenario-weighted posteriors instead of raw
pooled chars:
  - A block = one scenario run once by EVERY discovered arm; arm order
    within a block rotates block-to-block for time-fairness. Blocks cycle
    round-robin over ALL scenarios currently discovered under
    envs/scenarios/ (discovered dynamically every call, never hardcoded).
  - Round-2 cap: 18 trials total (one complete arms x scenarios grid at the
    contract's target of 3 arms x 6 scenarios; with a different arm/scenario
    count the cap still applies as a flat number, so a grid may end up
    partially covered -- see NOTES.md §9).
  - Round-2 trial records carry `"block": "r2-<scenario>-<cycle>"`.
  - `report2` reads only block-tagged trials, stratifies pass/chars by
    scenario, and reports an overall P(best) where the success term is a
    single aggregate Beta per arm (as in phase 1) but the efficiency term is
    the *average* of per-scenario log-chars posterior-predictive draws (one
    draw per scenario, weighted equally regardless of how many actual
    trials each scenario has for that arm) -- this is what corrects the
    phase-1 scenario-mix confound.
"""
import json
import math
import os
import random
import statistics
import sys

PRIOR_MEAN_LOG = math.log(3e5)
PRIOR_STRENGTH = 1.0
# Floor on the log-chars variance plug-in. With 0-2 successes the sample
# variance is undefined/zero and would make the posterior predictive
# absurdly overconfident; with a handful of near-identical smoke trials the
# empirical variance is likewise near zero. 0.05 (~22% relative sd in raw
# chars) is a deliberately mild, tunable regularizer, not derived from data.
FLOOR_VAR = 0.05
SEED_PHASE_MIN_TRIALS = 3
PHASE1_CAP = 15
N_POSTERIOR_DRAWS = 20000
ROUND2_CAP = 18
ROUND3_CAP = 24
# Round 4 ("confirmation round"): a fixed, hardcoded subset of scenarios --
# the "discriminating set" -- NOT the full dynamically-discovered set (see
# NOTES.md §11). Kept in this exact order (already alphabetical) so the
# block sequence is declare-coupling, reconcile-drift, triage-mixed-drift,
# declare-coupling (cycle 2), ... matching CONTRACT's own description of
# the round-4 cap.
ROUND4_SCENARIOS = ["declare-coupling", "reconcile-drift", "triage-mixed-drift"]
ROUND4_CAP = 12
# The two "confirmation pairs" report4 runs its pooled r3+r4 sign test on.
ROUND4_POOLED_PAIRS = [("variant-e", "variant-d"), ("variant-e", "variant-a")]


def base_dir():
    return os.path.dirname(os.path.abspath(__file__)) + "/.."


def skills_root():
    return os.environ.get("SKILLS_ROOT", os.path.join(base_dir(), "skills"))


def scenarios_root():
    return os.environ.get("SCENARIOS_ROOT", os.path.join(base_dir(), "envs", "scenarios"))


def trials_path():
    return os.environ.get("TRIALS_PATH", os.path.join(base_dir(), "results", "trials.jsonl"))


def make_rng():
    seed = os.environ.get("SEED")
    if seed is not None:
        return random.Random(int(seed))
    return random.Random()


def discover_arms(skills_dir):
    if not os.path.isdir(skills_dir):
        return []
    arms = []
    for name in os.listdir(skills_dir):
        if name.startswith("smoke"):
            continue
        if os.path.isfile(os.path.join(skills_dir, name, "SKILL.md")):
            arms.append(name)
    return sorted(arms)


def discover_scenarios(scenarios_dir):
    if not os.path.isdir(scenarios_dir):
        return []
    scenarios = []
    for name in os.listdir(scenarios_dir):
        d = os.path.join(scenarios_dir, name)
        if all(os.path.isfile(os.path.join(d, f)) for f in ("setup.sh", "task-prompt.md", "grade.sh")):
            scenarios.append(name)
    return sorted(scenarios)


def round4_scenarios():
    """Round 4 deliberately does NOT use discover_scenarios()'s full set --
    it's restricted to the fixed ROUND4_SCENARIOS "discriminating set". Still
    validate each one actually exists as a real scenario dir (fail loudly,
    not silently, if one's missing/misconfigured -- CLAUDE.md's fail-closed
    preference) rather than trusting the hardcoded list blindly."""
    available = set(discover_scenarios(scenarios_root()))
    missing = [s for s in ROUND4_SCENARIOS if s not in available]
    if missing:
        sys.stderr.write(
            "bandit.py: round-4 scenario(s) not found under %s: %s\n"
            % (scenarios_root(), ", ".join(missing))
        )
        sys.exit(1)
    return sorted(ROUND4_SCENARIOS)


def load_trials(path):
    trials = []
    if not os.path.exists(path):
        return trials
    with open(path) as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                trials.append(json.loads(line))
            except json.JSONDecodeError as e:
                sys.stderr.write("bandit.py: WARNING: skipping malformed trials.jsonl line: %s\n" % e)
    return trials


def has_block(t):
    """A trial belongs to SOME round-N (N >= 2) iff it carries a non-empty
    "block" field. Phase-1 trial records predate this field entirely, so
    plain absence (not just falsiness) is the correct test -- but a
    falsy/empty value is treated the same defensively."""
    return bool(t.get("block"))


def is_round_trial(t, prefix):
    """A trial belongs to round `prefix` (e.g. "r2", "r3") iff its "block"
    field starts with "<prefix>-". Block ids are built as
    "<prefix>-<scenario>-<cycle>" (see block_id_for), so this exact-prefix
    check is unambiguous even though scenario names themselves contain
    dashes (e.g. "declare-coupling") -- round 2's blocks must never be
    mistaken for round 3's or vice versa once both share trials.jsonl."""
    return (t.get("block") or "").startswith(prefix + "-")


def phase1_trials(trials, arms):
    """Trials that count toward phase-1 stats: recognized arm, no block
    field at all. Filtering out block-tagged trials here (rather than
    leaving `next`/`report` to scan raw `trials`) is what keeps them correct
    once round-2+ trials start accumulating in the same trials.jsonl -- see
    NOTES.md §9/§10."""
    return [t for t in trials if t.get("variant") in arms and not has_block(t)]


def round_trials(trials, arms, prefix):
    """Trials that count toward round `prefix`'s stats: recognized arm,
    block field starting with "<prefix>-" (CONTRACT: "Phase-1 trials stay in
    trials.jsonl but are excluded from round-2 stats -- filter on the block
    field"; extended the same way so round 2's and round 3's records don't
    leak into each other once both coexist -- see NOTES.md §10)."""
    return [t for t in trials if t.get("variant") in arms and is_round_trial(t, prefix)]


def is_smoke_variant(name):
    return bool(name) and name.startswith("smoke")


def phase1_trials_all(trials):
    """Like phase1_trials, but NOT restricted to currently-discovered arms --
    only excludes smoke-fixture variants and block-tagged trials. Used only
    by REPORT commands (never allocation) so a retired arm's historical
    phase-1 rows don't silently vanish from `report` just because its
    skills/ dir is gone -- see NOTES.md §10."""
    return [t for t in trials if t.get("variant") and not is_smoke_variant(t["variant"]) and not has_block(t)]


def round_trials_all(trials, prefix):
    """Like round_trials, but NOT restricted to currently-discovered arms --
    see phase1_trials_all's docstring; same rationale, for report2/report3."""
    return [t for t in trials if t.get("variant") and not is_smoke_variant(t["variant"]) and is_round_trial(t, prefix)]


def historical_arms(trials_for_report, live_arms):
    """Union of currently-discovered ("live") arms and any variant that
    actually appears in an already phase/round-filtered, smoke-excluded
    trial list. REPORT commands (report/report2/report3) use this so a
    retired arm's completed data keeps showing up in retrospective reports
    forever, even after its skills/ dir is removed. ALLOCATION commands
    (next/next2/next3) must NEVER use this -- they need the live arm set
    only, since a retired arm must never be handed a new trial."""
    seen = set(live_arms)
    for t in trials_for_report:
        seen.add(t["variant"])
    return sorted(seen)


def arm_stats(trials, arms):
    stats = {a: {"trials": 0, "successes": 0, "failures": 0, "chars": [], "rewards": []} for a in arms}
    for t in trials:
        a = t.get("variant")
        if a not in stats:
            continue
        s = stats[a]
        s["trials"] += 1
        s["rewards"].append(float(t.get("reward", 0) or 0))
        if t.get("pass"):
            s["successes"] += 1
            tc = t.get("total_chars")
            if isinstance(tc, (int, float)) and tc > 0:
                s["chars"].append(tc)
        else:
            s["failures"] += 1
    return stats


def scenario_counts(trials, scenarios):
    counts = {s: 0 for s in scenarios}
    for t in trials:
        sc = t.get("scenario")
        if sc in counts:
            counts[sc] += 1
    return counts


def seed_phase_pick(stats, arms):
    """Return the arm to force next during the seed phase, or None if every
    arm already has >= SEED_PHASE_MIN_TRIALS trials."""
    under = [a for a in arms if stats[a]["trials"] < SEED_PHASE_MIN_TRIALS]
    if not under:
        return None
    # Least-used first, alphabetical tiebreak -> naturally round-robins.
    under.sort(key=lambda a: (stats[a]["trials"], a))
    return under[0]


def draw_logc(rng, chars):
    """Draw one sample of log(total_chars) from the Normal-Normal
    (known-variance approx) posterior *predictive*, given a list of
    total_chars values from an arm's (optionally scenario-filtered)
    successful trials. Shared by both the phase-1 pooled-chars draw and
    round 2's per-scenario draws."""
    n = len(chars)
    if n == 0:
        sigma2 = FLOOR_VAR
        post_mean = PRIOR_MEAN_LOG
    else:
        logs = [math.log(c) for c in chars]
        xbar = statistics.mean(logs)
        sample_var = statistics.variance(logs) if n >= 2 else FLOOR_VAR
        sigma2 = max(sample_var, FLOOR_VAR)
        post_mean = (PRIOR_STRENGTH * PRIOR_MEAN_LOG + n * xbar) / (PRIOR_STRENGTH + n)
    predictive_var = sigma2 * (1.0 + 1.0 / (PRIOR_STRENGTH + n))
    return rng.gauss(post_mean, math.sqrt(predictive_var))


def sampled_reward(rng, successes, failures, chars):
    p = rng.betavariate(1 + successes, 1 + failures)
    logc = draw_logc(rng, chars)
    return p * math.exp(-logc)


def sampled_reward_equal_scenario_weight(rng, successes, failures, chars_by_scenario, scenarios):
    """Round-2 draw: same aggregate Beta on success as phase 1, but the
    efficiency term is the average of ONE posterior-predictive log-chars
    draw per scenario (each scenario weighted equally regardless of how
    many actual trials that arm has run in it) -- this is what corrects the
    phase-1 scenario-mix confound (arms previously saw unbalanced scenario
    diets, biasing raw/pooled chars comparisons)."""
    p = rng.betavariate(1 + successes, 1 + failures)
    per_scenario_rewards = [
        math.exp(-draw_logc(rng, chars_by_scenario.get(s, []))) for s in scenarios
    ]
    return p * (sum(per_scenario_rewards) / len(per_scenario_rewards))


def thompson_pick(rng, stats, arms):
    best_arm = None
    best_val = None
    for a in sorted(arms):  # sorted for a stable draw order given a seeded rng
        s = stats[a]
        val = sampled_reward(rng, s["successes"], s["failures"], s["chars"])
        if best_val is None or val > best_val:
            best_val = val
            best_arm = a
    return best_arm


def scenario_pick(counts, scenarios):
    ordered = sorted(scenarios, key=lambda s: (counts[s], s))
    return ordered[0]


def cmd_next():
    arms = discover_arms(skills_root())
    if not arms:
        sys.stderr.write("bandit.py: no arms found under %s\n" % skills_root())
        sys.exit(1)
    scenarios = discover_scenarios(scenarios_root())
    if not scenarios:
        sys.stderr.write("bandit.py: no scenarios found under %s\n" % scenarios_root())
        sys.exit(1)

    all_trials = load_trials(trials_path())

    # Cap check: ALL phase-1 trials count, including any now-retired arm's --
    # a trial already spent is spent, regardless of whether its arm is still
    # live. Restricting this to live arms only would let retiring an arm
    # silently "refund" its historical trials and reopen an already-closed
    # phase-1 budget (found for real: retiring variant-c mid-round-3-prep
    # made `next` propose a brand new phase-1 trial instead of correctly
    # printing STOP, since phase-1 had already hit its cap counting all 3
    # original arms -- see NOTES.md §10).
    if len(phase1_trials_all(all_trials)) >= PHASE1_CAP:
        print("STOP cap-reached")
        return

    # Which arm to run next, though, must only ever consider LIVE arms'
    # own trial counts -- a retired arm's count is irrelevant to balancing
    # among the arms actually still running.
    trials = phase1_trials(all_trials, arms)
    stats = arm_stats(trials, arms)

    rng = make_rng()
    arm = seed_phase_pick(stats, arms)
    if arm is None:
        arm = thompson_pick(rng, stats, arms)

    # Scenario rotation was never arm-scoped (CONTRACT: "round-robin over
    # scenarios independent of arm choice") -- it's a single shared tally,
    # so it correctly includes every historical phase-1 trial regardless of
    # which arm ran it, live or retired.
    counts = scenario_counts(phase1_trials_all(all_trials), scenarios)
    scenario = scenario_pick(counts, scenarios)

    print("%s %s" % (arm, scenario))


# --- round 2+: scenario-matched complete blocks --------------------------
# Shared by every round after phase 1 (round 2, round 3, ...) -- only the
# block-id prefix and the trial cap differ between rounds. See NOTES.md
# §9 (round 2) and §10 (generalizing to round 3) for the design rationale.

def block_id_for(prefix, scenario, cycle):
    return "%s-%s-%d" % (prefix, scenario, cycle)


def arm_order_for_block(arms_sorted, block_index):
    """Rotate the (already-sorted) arm list by block_index so the arm that
    goes first varies block-to-block ("arm order rotates per block for
    time-fairness")."""
    n = len(arms_sorted)
    rot = block_index % n
    return arms_sorted[rot:] + arms_sorted[:rot]


def next_block_pick(arms, scenarios, this_round_trials, prefix):
    """Find the next (variant, scenario, block_id) to run for round
    `prefix`: scan the block sequence (cycle 1: scenario[0], scenario[1],
    ...; cycle 2: same order again; ...) for the first block that doesn't
    yet have every arm recorded, and return that block's next arm in
    rotated order.

    Recomputing `scenarios` (and `arms`) fresh from disk on every call
    (discover_scenarios/discover_arms are dynamic, never hardcoded) is what
    makes this self-correcting if new scenarios or arms appear mid-round:
    already-complete blocks stay complete regardless of where they now fall
    in the recomputed sequence, and anything newly added simply becomes (or
    contributes to) the first incomplete slot found. `this_round_trials`
    must already be filtered to this round's own prefix (round_trials()) --
    a sibling round's blocks sharing the same trials.jsonl must never be
    visible here, since a stray "r2-declare-coupling-1" must not be
    mistaken for completion of round 3's identically-shaped scenario
    block."""
    completed = {}
    for t in this_round_trials:
        completed.setdefault(t["block"], set()).add(t["variant"])

    n_scen = len(scenarios)
    n_arms = len(arms)
    b = 0
    # Safety valve only -- a real run stops via the round's cap check in
    # cmd_next_round long before this could ever be reached.
    while b < 100000:
        cycle = b // n_scen + 1
        scenario = scenarios[b % n_scen]
        block_id = block_id_for(prefix, scenario, cycle)
        done = completed.get(block_id, set())
        order = arm_order_for_block(arms, b)
        remaining = [a for a in order if a not in done]
        if remaining:
            return remaining[0], scenario, block_id
        b += 1
    raise RuntimeError("next_block_pick: exhausted search space without an open block slot")


def cmd_next_round(prefix, cap, scenarios):
    """Shared allocator body for round 2+. `scenarios` is passed in (rather
    than discovered here) so a round can use either the full dynamically-
    discovered scenario set (round 2/3) or a fixed, hardcoded subset
    (round 4's 3-scenario "discriminating set") -- see cmd_next4/NOTES.md
    §11."""
    arms = discover_arms(skills_root())
    if not arms:
        sys.stderr.write("bandit.py: no arms found under %s\n" % skills_root())
        sys.exit(1)
    if not scenarios:
        sys.stderr.write("bandit.py: no scenarios configured for round %s\n" % prefix)
        sys.exit(1)

    all_trials = load_trials(trials_path())

    # Cap check: ALL of this round's trials count, including any now-retired
    # arm's -- same reasoning as cmd_next's cap check (a spent trial is
    # spent; retiring an arm must not silently reopen an already-closed
    # round's budget). See NOTES.md §10.
    if len(round_trials_all(all_trials, prefix)) >= cap:
        print("STOP cap-reached")
        return

    # Block completeness/rotation, though, is only ever about LIVE arms --
    # a retired arm must never be handed a new trial, and block completeness
    # only needs every LIVE arm accounted for (whether a retired arm's old
    # entry is also present in that block is irrelevant either way, since
    # `arms` here already excludes it from consideration).
    rt = round_trials(all_trials, arms, prefix)
    variant, scenario, block_id = next_block_pick(arms, scenarios, rt, prefix)
    print("%s %s %s" % (variant, scenario, block_id))


def cmd_next2():
    cmd_next_round("r2", ROUND2_CAP, discover_scenarios(scenarios_root()))


def cmd_next3():
    cmd_next_round("r3", ROUND3_CAP, discover_scenarios(scenarios_root()))


def cmd_next4():
    cmd_next_round("r4", ROUND4_CAP, round4_scenarios())


# --- report ------------------------------------------------------------

def normal_cdf(x):
    return 0.5 * (1 + math.erf(x / math.sqrt(2)))


def fisher_exact_two_sided(a, b, c, d):
    """Two-sided Fisher's exact test p-value for a 2x2 table [[a,b],[c,d]],
    via direct hypergeometric enumeration (math.comb), summing the
    probability of every table with the same margins that is no more likely
    than the observed table -- the standard two-sided definition."""
    n = a + b + c + d
    row1 = a + b
    row2 = c + d
    col1 = a + c
    col2 = b + d
    denom = math.comb(n, row1)

    def pmf(x):
        return math.comb(col1, x) * math.comb(col2, row1 - x) / denom

    lo = max(0, row1 - col2)
    hi = min(row1, col1)
    observed = pmf(a)
    tol = observed * 1e-9
    return sum(pmf(x) for x in range(lo, hi + 1) if pmf(x) <= observed + tol)


def mann_whitney_u(xs, ys):
    """Two-sided Mann-Whitney U test, normal approximation with tie
    correction and continuity correction. Returns (U_x, z, p_two_sided)."""
    combined = sorted((v, 0) for v in xs) + sorted((v, 1) for v in ys)
    combined.sort(key=lambda t: t[0])
    n1, n2 = len(xs), len(ys)
    n = n1 + n2

    # Average ranks for ties (1-indexed).
    ranks = [0.0] * n
    i = 0
    while i < n:
        j = i
        while j + 1 < n and combined[j + 1][0] == combined[i][0]:
            j += 1
        avg_rank = (i + 1 + j + 1) / 2.0
        for k in range(i, j + 1):
            ranks[k] = avg_rank
        i = j + 1

    rank_sum_x = sum(r for r, (v, grp) in zip(ranks, combined) if grp == 0)
    u_x = rank_sum_x - n1 * (n1 + 1) / 2.0

    # Tie correction term.
    tie_term = 0.0
    i = 0
    while i < n:
        j = i
        while j + 1 < n and combined[j + 1][0] == combined[i][0]:
            j += 1
        t = j - i + 1
        if t > 1:
            tie_term += t ** 3 - t
        i = j + 1

    mean_u = n1 * n2 / 2.0
    var_u = (n1 * n2 / 12.0) * ((n + 1) - tie_term / (n * (n - 1))) if n > 1 else 0.0
    if var_u <= 0:
        return u_x, float("nan"), float("nan")
    sd_u = math.sqrt(var_u)
    diff = u_x - mean_u
    cc = 0.5 if diff > 0 else (-0.5 if diff < 0 else 0.0)
    z = (diff - cc) / sd_u
    p = 2 * (1 - normal_cdf(abs(z)))
    return u_x, z, min(1.0, p)


def cmd_report():
    # Deliberately NOT restricted to live discover_arms() output: a retired
    # arm's historical phase-1 rows must keep showing up here even after its
    # skills/ dir is removed (see historical_arms()'s docstring / NOTES.md
    # §10 -- this exact gap was found by running `report` for real right
    # after variant-c was retired mid-round-3-prep).
    live_arms = discover_arms(skills_root())
    trials = phase1_trials_all(load_trials(trials_path()))
    arms = historical_arms(trials, live_arms)
    if not arms:
        sys.stderr.write("bandit.py: no arms found under %s and no historical phase-1 trial data either\n" % skills_root())
        sys.exit(1)
    stats = arm_stats(trials, arms)
    rng = make_rng()

    print("=== git-span skill bandit -- phase 1 report ===")
    print()
    header = "%-20s %7s %11s %9s %14s %14s %10s" % (
        "arm", "trials", "successes", "succ.rate", "mean chars(ok)", "median chars(ok)", "mean reward",
    )
    print(header)
    print("-" * len(header))
    for a in arms:
        s = stats[a]
        n = s["trials"]
        succ = s["successes"]
        rate = succ / n if n else float("nan")
        chars = s["chars"]
        mean_chars = statistics.mean(chars) if chars else float("nan")
        median_chars = statistics.median(chars) if chars else float("nan")
        mean_reward = statistics.mean(s["rewards"]) if s["rewards"] else 0.0
        print("%-20s %7d %11d %9s %14s %14s %10.3e" % (
            a, n, succ,
            ("%.2f" % rate) if n else "n/a",
            ("%.0f" % mean_chars) if chars else "n/a",
            ("%.0f" % median_chars) if chars else "n/a",
            mean_reward,
        ))
    print()

    if len(arms) < 2:
        print("Only one arm present -- posterior comparisons need >= 2 arms to be meaningful.")
        return

    # 20k paired posterior draws, reused for both P(best) and pairwise P(a beats b).
    draws = {a: [0.0] * N_POSTERIOR_DRAWS for a in arms}
    for i in range(N_POSTERIOR_DRAWS):
        for a in arms:
            s = stats[a]
            draws[a][i] = sampled_reward(rng, s["successes"], s["failures"], s["chars"])

    win_counts = {a: 0 for a in arms}
    for i in range(N_POSTERIOR_DRAWS):
        best_a, best_v = None, None
        for a in arms:
            v = draws[a][i]
            if best_v is None or v > best_v:
                best_v, best_a = v, a
        win_counts[best_a] += 1

    print("P(arm is best) from %d posterior draws:" % N_POSTERIOR_DRAWS)
    for a in sorted(arms, key=lambda x: -win_counts[x]):
        print("  %-20s %.4f" % (a, win_counts[a] / N_POSTERIOR_DRAWS))
    print()

    print("Pairwise P(row beats col):")
    col_w = max(len(a) for a in arms) + 2
    print(" " * col_w + "".join("%12s" % a for a in arms))
    for a in arms:
        row = []
        for b in arms:
            if a == b:
                row.append("%12s" % "-")
            else:
                wins = sum(1 for i in range(N_POSTERIOR_DRAWS) if draws[a][i] > draws[b][i])
                row.append("%12.4f" % (wins / N_POSTERIOR_DRAWS))
        print(("%-" + str(col_w) + "s") % a + "".join(row))
    print()

    top2 = sorted(arms, key=lambda a: (-win_counts[a], a))[:2]
    a1, a2 = top2[0], top2[1]
    s1, s2 = stats[a1], stats[a2]
    print("Leading pair (by P(best)): %s vs %s" % (a1, a2))
    p_fisher = fisher_exact_two_sided(s1["successes"], s1["failures"], s2["successes"], s2["failures"])
    print("  Fisher's exact test (two-sided) on success counts: p = %.4f" % p_fisher)
    print("  (%s: %d/%d successes; %s: %d/%d successes)" % (
        a1, s1["successes"], s1["trials"], a2, s2["successes"], s2["trials"],
    ))

    if len(s1["chars"]) >= 3 and len(s2["chars"]) >= 3:
        u, z, p_mw = mann_whitney_u(s1["chars"], s2["chars"])
        print("  Mann-Whitney U (normal approx) on total_chars of successes: U=%.1f z=%.3f p=%.4f" % (u, z, p_mw))
    else:
        print("  Mann-Whitney U: skipped (%s has %d successes, %s has %d -- need >=3 each)" % (
            a1, len(s1["chars"]), a2, len(s2["chars"]),
        ))

    print()
    print("--- Significance statement ---")
    print(
        "Round 1 is deliberately underpowered (phase-1 cap = %d trials total, "
        "seed phase alone spends %d trials just reaching 3-per-arm coverage). "
        "Treat the posteriors above as directional, not confirmatory: with this few "
        "trials per arm, both the success-rate and the efficiency (chars) posteriors "
        "have wide credible intervals, and P(best)/pairwise numbers can swing a lot "
        "with just one or two more trials. The Fisher's exact p-value above is the "
        "one part of this report you should not need a Bayesian-jargon translator for -- "
        "read it plainly: p >= ~0.05 means round 1 cannot distinguish the leading pair's "
        "success rates from chance. Use this report to pick where to spend the *next* "
        "batch of trials, not to declare a winner."
        % (PHASE1_CAP, SEED_PHASE_MIN_TRIALS * len(arms))
    )


# --- report2 (round 2, stratified by scenario) ---------------------------

def stratified_stats(trials, arms, scenarios):
    """{scenario: {arm: {trials, successes, failures, chars}}} over the
    given (already round-2-filtered) trials."""
    stats = {
        s: {a: {"trials": 0, "successes": 0, "failures": 0, "chars": []} for a in arms}
        for s in scenarios
    }
    for t in trials:
        s = t.get("scenario")
        a = t.get("variant")
        if s not in stats or a not in stats[s]:
            continue
        st = stats[s][a]
        st["trials"] += 1
        if t.get("pass"):
            st["successes"] += 1
            tc = t.get("total_chars")
            if isinstance(tc, (int, float)) and tc > 0:
                st["chars"].append(tc)
        else:
            st["failures"] += 1
    return stats


def scenario_winner(stats_for_scenario, arms):
    """Winner for one scenario's row-group: most successes first, then
    lower mean chars-of-successes (more efficient), then alphabetical.
    Returns None if no arm has any trial recorded for this scenario yet."""
    candidates = [a for a in arms if stats_for_scenario[a]["trials"] > 0]
    if not candidates:
        return None

    def key(a):
        st = stats_for_scenario[a]
        mean_chars = statistics.mean(st["chars"]) if st["chars"] else float("inf")
        return (-st["successes"], mean_chars, a)

    return min(candidates, key=key)


def sign_test_two_sided(k, n):
    """Exact two-sided binomial sign test p-value: k successes ("row beats
    col") out of n non-tied paired comparisons, null p=0.5."""
    if n == 0:
        return float("nan")

    def binom_pmf(i):
        return math.comb(n, i) / (2 ** n)

    cum_le = sum(binom_pmf(i) for i in range(0, k + 1))
    cum_ge = sum(binom_pmf(i) for i in range(k, n + 1))
    return min(1.0, 2 * min(cum_le, cum_ge))


def paired_sign_test_detailed(trials_for_pair, a1, a2):
    """Pair a1 vs a2 within each block_id present in `trials_for_pair` where
    both have exactly one recorded trial (works whether those blocks all
    share one round's prefix, e.g. report2/report3's own use, or span
    multiple rounds pooled together, e.g. report4's pooled r3+r4 analysis --
    this function only ever looks at `block`/`variant`/`reward`, never the
    prefix). Returns (wins_a1, wins_a2, ties, p) where p is the two-sided
    exact binomial sign test p-value on wins_a1 vs. (wins_a1 + wins_a2)
    non-tied comparisons."""
    per_block = {}
    for t in trials_for_pair:
        v = t.get("variant")
        if v not in (a1, a2):
            continue
        per_block.setdefault(t["block"], {})[v] = float(t.get("reward", 0) or 0)

    wins_a1 = 0
    wins_a2 = 0
    ties = 0
    for block_id, d in per_block.items():
        if a1 in d and a2 in d:
            r1, r2v = d[a1], d[a2]
            if r1 == r2v:
                ties += 1
            elif r1 > r2v:
                wins_a1 += 1
            else:
                wins_a2 += 1
    p = sign_test_two_sided(wins_a1, wins_a1 + wins_a2)
    return wins_a1, wins_a2, ties, p


def paired_sign_test(round_trials_for_pair, a1, a2):
    """report2/report3's original (k, n, p) shape: k = a1's wins, n = total
    non-tied comparisons. Thin wrapper over paired_sign_test_detailed so the
    tie-counting logic isn't duplicated -- see NOTES.md §11."""
    wins_a1, wins_a2, _ties, p = paired_sign_test_detailed(round_trials_for_pair, a1, a2)
    return wins_a1, wins_a1 + wins_a2, p


def cmd_report_round(prefix, cap, round_num, scenarios):
    """Shared stratified-by-scenario report for round `round_num`
    (block-id prefix `prefix`, trial cap `cap`, over `scenarios`).
    `report2`/`report3`/`report4` are thin wrappers around this -- see
    NOTES.md §10/§11. `scenarios` is passed in (not discovered here) so a
    round can stratify over either the full dynamically-discovered scenario
    set (round 2/3) or a fixed, hardcoded subset (round 4's 3-scenario
    "discriminating set"). Every print statement here is parameterized so
    that calling this with (prefix="r2", cap=ROUND2_CAP, round_num=2,
    scenarios=discover_scenarios(...)) reproduces report2's original
    (pre-round-3) output byte-for-byte against the same data; only the
    round number substitutes into otherwise-identical wording.

    Arms are the union of currently-live arms and any variant that actually
    appears in this round's data (historical_arms()), NOT restricted to
    discover_arms() alone -- so a retired arm's completed round-N rows keep
    showing up here forever, even after its skills/ dir is removed. This
    exact gap was found by running `report2` for real right after variant-c
    was retired mid-round-3-prep: its 6 real round-2 trials would otherwise
    have silently vanished from the table, and the significance
    statement's block/arm-count arithmetic would have quietly described a
    round-2 design that never actually happened (see NOTES.md §10)."""
    live_arms = discover_arms(skills_root())
    if not scenarios:
        sys.stderr.write("bandit.py: no scenarios configured for round %s\n" % prefix)
        sys.exit(1)

    rt = round_trials_all(load_trials(trials_path()), prefix)
    arms = historical_arms(rt, live_arms)
    if not arms:
        sys.stderr.write(
            "bandit.py: no arms found under %s and no historical round-%d trial data either\n"
            % (skills_root(), round_num)
        )
        sys.exit(1)

    print("=== git-span skill bandit -- round %d report (scenario-matched blocks) ===" % round_num)
    print()
    if not rt:
        print("No round-%d trials recorded yet (nothing carries a \"block\" field)." % round_num)
        return

    strat = stratified_stats(rt, arms, scenarios)

    print("Per-scenario stratified results:")
    for s in scenarios:
        print()
        print("  [%s]" % s)
        row_header = "    %-20s %7s %11s %14s" % ("arm", "trials", "successes", "mean chars(ok)")
        print(row_header)
        print("    " + "-" * (len(row_header) - 4))
        for a in arms:
            st = strat[s][a]
            mean_chars = statistics.mean(st["chars"]) if st["chars"] else float("nan")
            print("    %-20s %7d %11d %14s" % (
                a, st["trials"], st["successes"],
                ("%.0f" % mean_chars) if st["chars"] else "n/a",
            ))
        winner = scenario_winner(strat[s], arms)
        print("    winner: %s" % (winner if winner else "n/a (no data yet)"))
    print()

    # Aggregate (pooled-across-scenarios) success counts per arm -- reused
    # as-is from phase 1's arm_stats, since it just tallies by variant
    # regardless of scenario.
    agg = arm_stats(rt, arms)

    if len(arms) < 2:
        print("Only one arm present -- posterior comparisons need >= 2 arms to be meaningful.")
        return

    rng = make_rng()
    chars_by_scenario_per_arm = {a: {s: strat[s][a]["chars"] for s in scenarios} for a in arms}

    draws = {a: [0.0] * N_POSTERIOR_DRAWS for a in arms}
    for i in range(N_POSTERIOR_DRAWS):
        for a in arms:
            st = agg[a]
            draws[a][i] = sampled_reward_equal_scenario_weight(
                rng, st["successes"], st["failures"], chars_by_scenario_per_arm[a], scenarios,
            )

    win_counts = {a: 0 for a in arms}
    for i in range(N_POSTERIOR_DRAWS):
        best_a, best_v = None, None
        for a in arms:
            v = draws[a][i]
            if best_v is None or v > best_v:
                best_v, best_a = v, a
        win_counts[best_a] += 1

    print("Overall P(arm is best) from %d posterior draws (equal scenario weighting):" % N_POSTERIOR_DRAWS)
    for a in sorted(arms, key=lambda x: -win_counts[x]):
        print("  %-20s %.4f" % (a, win_counts[a] / N_POSTERIOR_DRAWS))
    print()

    print("Pairwise P(row beats col):")
    col_w = max(len(a) for a in arms) + 2
    print(" " * col_w + "".join("%12s" % a for a in arms))
    for a in arms:
        row = []
        for b in arms:
            if a == b:
                row.append("%12s" % "-")
            else:
                wins = sum(1 for i in range(N_POSTERIOR_DRAWS) if draws[a][i] > draws[b][i])
                row.append("%12.4f" % (wins / N_POSTERIOR_DRAWS))
        print(("%-" + str(col_w) + "s") % a + "".join(row))
    print()

    top2 = sorted(arms, key=lambda a: (-win_counts[a], a))[:2]
    a1, a2 = top2[0], top2[1]
    print("Leading pair (by P(best)): %s vs %s" % (a1, a2))
    k, n, p_sign = paired_sign_test(rt, a1, a2)
    if n > 0:
        print("  Paired sign test across completed blocks: %s wins %d/%d (ties dropped), p = %.4f" % (a1, k, n, p_sign))
    else:
        print("  Paired sign test: skipped (no blocks where both %s and %s have recorded trials)" % (a1, a2))

    print()
    print("--- Significance statement ---")
    n_blocks_target = cap // len(arms) if arms else 0
    print(
        "Round %d is still underpowered by design (cap = %d trials = %d complete "
        "%d-arm blocks across %d scenario(s) currently discovered). Phase 1 hit a "
        "ceiling effect (15/15 pass, no signal in success rate) and a scenario-mix "
        "confound (arms saw unbalanced scenario diets, biasing raw chars "
        "comparisons); this report fixes the second problem by weighting every "
        "scenario equally in the efficiency term regardless of how many trials it "
        "actually has so far, but that does not manufacture statistical power out "
        "of a handful of blocks. Read the paired sign test plainly: p >= ~0.05 means "
        "round %d cannot yet distinguish the leading pair block-for-block. Treat "
        "P(best)/pairwise numbers as directional and expect them to move with the "
        "next batch of blocks."
        % (round_num, cap, n_blocks_target, len(arms), len(scenarios), round_num)
    )


def cmd_report2():
    cmd_report_round("r2", ROUND2_CAP, 2, discover_scenarios(scenarios_root()))


def cmd_report3():
    cmd_report_round("r3", ROUND3_CAP, 3, discover_scenarios(scenarios_root()))


def cmd_report4():
    cmd_report_round("r4", ROUND4_CAP, 4, round4_scenarios())
    print()
    print("--- Pooled r3+r4 paired analysis (confirmation pairs) ---")
    print(
        "Round 3 and round 4 share the same scenario set, task prompts, and graders for "
        "every round-4 scenario, so pooling every completed block from BOTH rounds into "
        "one paired comparison is legitimate -- this is NOT a round-4-only result."
    )
    all_trials = load_trials(trials_path())
    pooled = round_trials_all(all_trials, "r3") + round_trials_all(all_trials, "r4")
    for a1, a2 in ROUND4_POOLED_PAIRS:
        wins1, wins2, ties, p = paired_sign_test_detailed(pooled, a1, a2)
        print()
        print("%s vs %s (pooled r3+r4 blocks):" % (a1, a2))
        print("  %s wins: %d, %s wins: %d, ties: %d" % (a1, wins1, a2, wins2, ties))
        if wins1 + wins2 > 0:
            print("  Two-sided exact binomial sign test: p = %.4f" % p)
        else:
            print("  Two-sided exact binomial sign test: skipped (no non-tied comparable blocks)")


COMMANDS = {
    "next": cmd_next,
    "report": cmd_report,
    "next2": cmd_next2,
    "report2": cmd_report2,
    "next3": cmd_next3,
    "report3": cmd_report3,
    "next4": cmd_next4,
    "report4": cmd_report4,
}


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in COMMANDS:
        sys.stderr.write("usage: bandit.py <%s>\n" % "|".join(COMMANDS))
        sys.exit(2)
    COMMANDS[sys.argv[1]]()


if __name__ == "__main__":
    main()
