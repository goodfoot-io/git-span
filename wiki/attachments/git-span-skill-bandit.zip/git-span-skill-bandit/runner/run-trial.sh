#!/usr/bin/env bash
# run-trial.sh <variant> <scenario> [block-id]
#
# One full bandit trial: fresh env -> claude -p (haiku) -> grade -> measure
# transcript chars -> append one JSON line to results/trials.jsonl -> print it.
#
# The optional third arg is a round-2 block id (e.g. "r2-declare-coupling-1",
# as produced by `bandit.py next2`). When given, the trial record gains a
# "block" field with that value; phase-1 trials (no third arg) get no such
# field at all. No other behavior changes based on its presence.
#
# See CONTRACT.md for the schema and runner/NOTES.md for the empirical
# findings this script's behavior is built on (transcript path/encoding,
# subagent transcript layout, `claude --output-format json` shape, env vars
# that must be neutralized before invoking a nested `claude`).
#
# Env var overrides (for the runner's own smoke-testing only; real trials
# never need these -- they default to the exact CONTRACT paths):
#   SKILLS_ROOT     default: <base>/skills
#   SCENARIOS_ROOT  default: <base>/envs/scenarios
#   PARALLEL=1      reserved no-op for now. Trial-id allocation is already
#                   flock-safe for back-to-back sequential runs; this flag
#                   does nothing else yet.
set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BASE_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
HELPER="$SCRIPT_DIR/lib/trial_helper.py"

variant="${1:?usage: run-trial.sh <variant> <scenario> [block-id]}"
scenario="${2:?usage: run-trial.sh <variant> <scenario> [block-id]}"
block_id="${3:-}"  # optional; round-2 only, see header comment
: "${PARALLEL:=0}"  # reserved, currently a no-op

SKILLS_ROOT="${SKILLS_ROOT:-$BASE_DIR/skills}"
SCENARIOS_ROOT="${SCENARIOS_ROOT:-$BASE_DIR/envs/scenarios}"
RESULTS_DIR="$BASE_DIR/results"
PROJECTS_ROOT="$HOME/.claude/projects"

die() {
  echo "run-trial.sh: FATAL: $*" >&2
  exit 1
}

# --- 1. Validate variant -------------------------------------------------
variant_dir="$SKILLS_ROOT/$variant"
skill_path="$variant_dir/SKILL.md"
[[ -f "$skill_path" ]] || die "variant '$variant': no SKILL.md at $skill_path"
skill_path_abs="$(cd "$variant_dir" && pwd)/SKILL.md"

# --- 2. Validate scenario -------------------------------------------------
scenario_dir="$SCENARIOS_ROOT/$scenario"
[[ -f "$scenario_dir/setup.sh" ]]       || die "scenario '$scenario': no setup.sh at $scenario_dir"
[[ -f "$scenario_dir/task-prompt.md" ]] || die "scenario '$scenario': no task-prompt.md at $scenario_dir"
[[ -f "$scenario_dir/grade.sh" ]]       || die "scenario '$scenario': no grade.sh at $scenario_dir"
scenario_dir="$(cd "$scenario_dir" && pwd)"

# --- 3. Allocate trial id + env dir ---------------------------------------
# env_dir is the pristine repo working tree the agent operates in and the
# grader inspects (e.g. `git status --porcelain` must show only what the
# agent itself did). meta_dir is a SIBLING directory -- never nested inside
# env_dir -- that holds every runner-owned artifact (rendered prompt, raw
# claude output, grade output, the trial record itself). Nothing runner-
# owned may ever be written under env_dir. (Root cause of a prior bug: these
# were previously written inside env_dir and tripped "working tree clean"
# graders -- see NOTES.md root-cause section.)
trial_id="$(python3 "$HELPER" next-trial-dir "$RESULTS_DIR")" || die "could not allocate trial id"
env_dir="$RESULTS_DIR/envs/$trial_id"
meta_dir="$RESULTS_DIR/envs/${trial_id}.meta"
mkdir -p "$meta_dir"
echo "run-trial.sh: trial=$trial_id variant=$variant scenario=$scenario env_dir=$env_dir meta_dir=$meta_dir" >&2

# --- 4. Scenario setup -----------------------------------------------------
if ! bash "$scenario_dir/setup.sh" "$env_dir" >"$meta_dir/setup.log" 2>&1; then
  cat "$meta_dir/setup.log" >&2
  die "scenario '$scenario' setup.sh failed for trial $trial_id (env kept at $env_dir, meta at $meta_dir for inspection)"
fi
env_dir_abs="$(cd "$env_dir" && pwd)"

# --- 5. Build the task prompt (substitute {{SKILL_PATH}}) -----------------
prompt_file="$meta_dir/task-prompt.md"
python3 "$SCRIPT_DIR/lib/render_prompt.py" "$scenario_dir/task-prompt.md" "$skill_path_abs" "$prompt_file"
prompt="$(cat "$prompt_file")"

# --- 6. Invoke haiku headlessly, isolated from this (nested) session ------
# Empirically (runner/NOTES.md), these env vars can make a nested `claude`
# behave as an async agent-team member of *this* session (duplicated
# multi-turn "result" events, agentId task-notification plumbing) instead of
# a clean standalone session. Neutralize them so every trial is a genuinely
# fresh, independent session.
NEUTRALIZE_VARS=(
  CLAUDECODE
  CLAUDE_CODE_ENTRYPOINT
  CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS
  CLAUDE_CODE_SESSION_ID
  CLAUDE_CODE_CHILD_SESSION
  CLAUDE_CODE_BRIDGE_SESSION_ID
  CLAUDE_CODE_SSE_PORT
  CLAUDE_CODE_EXECPATH
  CLAUDE_CODE_MAX_OUTPUT_TOKENS
  CLAUDE_CODE_NO_FLICKER
  CLAUDE_BASH_MAINTAIN_PROJECT_WORKING_DIR
  CLAUDE_EFFORT
  CARDS_TRANSCRIPT_PATH
  AI_AGENT
  TMUX
)
unset_args=()
for v in "${NEUTRALIZE_VARS[@]}"; do
  unset_args+=(-u "$v")
done

out_json="$meta_dir/claude-output.json"
err_log="$meta_dir/claude-stderr.log"

start_ts=$(date -u +%s)
( cd "$env_dir" && env "${unset_args[@]}" timeout 600 \
    claude -p "$prompt" --model haiku --output-format json --dangerously-skip-permissions \
    >"$out_json" 2>"$err_log" )
invoke_rc=$?
end_ts=$(date -u +%s)
duration_s=$(( end_ts - start_ts ))

timed_out=false
if [[ "$invoke_rc" -eq 124 || "$invoke_rc" -eq 137 ]]; then
  timed_out=true
fi

# --- 7. Extract session_id / is_error from claude's output ----------------
extracted="$(python3 "$HELPER" extract-result "$out_json")"
session_id="$(python3 -c 'import json,sys; print(json.loads(sys.argv[1]).get("session_id") or "")' "$extracted")"
is_error="$(python3 -c 'import json,sys; d=json.loads(sys.argv[1]); print("true" if d.get("is_error") else "false")' "$extracted")"
found="$(python3 -c 'import json,sys; print("true" if json.loads(sys.argv[1]).get("found") else "false")' "$extracted")"
extract_error="$(python3 -c 'import json,sys; print(json.loads(sys.argv[1]).get("error") or "")' "$extracted")"

notes=""
append_note() {
  if [[ -z "$notes" ]]; then notes="$1"; else notes="$notes; $1"; fi
}
if $timed_out; then
  append_note "timeout"
elif [[ "$found" != "true" ]]; then
  append_note "claude-invocation-error: ${extract_error:-unknown} (rc=$invoke_rc)"
elif [[ "$is_error" == "true" ]]; then
  append_note "claude-reported-is_error"
fi

# --- 8. Grade ---------------------------------------------------------------
grade_output_file="$meta_dir/grade-output.log"
bash "$scenario_dir/grade.sh" "$env_dir_abs" >"$grade_output_file" 2>&1
grade_rc=$?

pass=false
if [[ "$grade_rc" -eq 0 && "$is_error" != "true" && "$timed_out" != "true" ]]; then
  pass=true
fi

# --- 9. Measure transcript size ---------------------------------------------
main_chars=0
subagent_chars=0
total_chars=0
if [[ -n "$session_id" ]]; then
  measured="$(python3 "$HELPER" measure-transcript "$PROJECTS_ROOT" "$env_dir_abs" "$session_id")"
  main_chars="$(python3 -c 'import json,sys; print(json.loads(sys.argv[1])["main_chars"])' "$measured")"
  subagent_chars="$(python3 -c 'import json,sys; print(json.loads(sys.argv[1])["subagent_chars"])' "$measured")"
  total_chars="$(python3 -c 'import json,sys; print(json.loads(sys.argv[1])["total_chars"])' "$measured")"
  main_found="$(python3 -c 'import json,sys; print(json.loads(sys.argv[1])["main_found"])' "$measured")"
  if [[ "$main_found" != "True" ]]; then
    append_note "main transcript not found (session_id=$session_id)"
  fi
else
  append_note "no session_id extracted, transcript not measured"
fi

# --- 10. Reward --------------------------------------------------------------
if $pass && [[ "$total_chars" -eq 0 ]]; then
  append_note "pass=true but total_chars=0, reward forced to 0"
fi
reward="$(python3 -c '
import sys
pass_ = sys.argv[1] == "true"
total_chars = int(sys.argv[2])
print(repr(1.0 / total_chars if (pass_ and total_chars > 0) else 0))
' "$pass" "$total_chars")"

ts="$(date -u +%Y-%m-%dT%H:%M:%SZ)"

# --- 11. Assemble + append the trial record ---------------------------------
# All free-text fields (grade_output, notes) are handed to Python via files
# or argv -- never interpolated into a heredoc/source string -- so arbitrary
# quotes/newlines in grade output can't corrupt the record.
record_file="$meta_dir/trial-record.json"
block_args=()
if [[ -n "$block_id" ]]; then
  block_args=(--block "$block_id")
fi
python3 "$SCRIPT_DIR/lib/build_record.py" \
  --out "$record_file" \
  --trial-id "$trial_id" \
  --ts "$ts" \
  --variant "$variant" \
  --scenario "$scenario" \
  --session-id "$session_id" \
  --env-dir "$env_dir_abs" \
  --pass "$pass" \
  --grade-output-file "$grade_output_file" \
  --main-chars "$main_chars" \
  --subagent-chars "$subagent_chars" \
  --total-chars "$total_chars" \
  --reward "$reward" \
  --duration-s "$duration_s" \
  --notes "$notes" \
  "${block_args[@]}"

python3 "$HELPER" append-trial "$RESULTS_DIR/trials.jsonl" "$record_file"
