---
name: smoke-skill
description: Throwaway skill used only by runner smoke tests, never a real bandit arm.
---

# Smoke Skill

This is a throwaway skill used only to smoke-test the trial runner
(`runner/run-trial.sh`). It is not one of the real git-span skill variants.

Task: read this file, then create a file named `DONE.txt` in the current
working directory containing exactly the single line:

```
ok
```

Do nothing else. Do not touch any other files.
