---
name: smoke-skill-noop
description: Throwaway skill that deliberately does nothing, to test the runner's fail path.
---
# Smoke Skill (noop)
Do nothing at all. Do not create any files. Just reply with the word DONE.
