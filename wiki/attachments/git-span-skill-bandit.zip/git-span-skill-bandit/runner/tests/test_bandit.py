#!/usr/bin/env python3
"""Plain-assert unit + integration tests for bandit.py.

Run directly: `python3 runner/tests/test_bandit.py`
Exits 0 and prints "ALL TESTS PASSED" if everything passes, else prints the
failing test name(s) and exits 1.
"""
import importlib.util
import json
import math
import os
import subprocess
import sys
import tempfile

TESTS_DIR = os.path.dirname(os.path.abspath(__file__))
RUNNER_DIR = os.path.dirname(TESTS_DIR)
BANDIT_PY = os.path.join(RUNNER_DIR, "bandit.py")

spec = importlib.util.spec_from_file_location("bandit", BANDIT_PY)
bandit = importlib.util.module_from_spec(spec)
spec.loader.exec_module(bandit)


# --------------------------------------------------------------------------
# Fixture helpers
# --------------------------------------------------------------------------

def make_fixture_tree(tmp, arm_names, scenario_names, smoke_arm_names=()):
    skills_root = os.path.join(tmp, "skills")
    scenarios_root = os.path.join(tmp, "envs", "scenarios")
    for a in list(arm_names) + list(smoke_arm_names):
        d = os.path.join(skills_root, a)
        os.makedirs(d, exist_ok=True)
        with open(os.path.join(d, "SKILL.md"), "w") as f:
            f.write("# %s\n" % a)
    for s in scenario_names:
        d = os.path.join(scenarios_root, s)
        os.makedirs(d, exist_ok=True)
        for fname in ("setup.sh", "task-prompt.md", "grade.sh"):
            with open(os.path.join(d, fname), "w") as f:
                f.write("# %s\n" % fname)
    results_dir = os.path.join(tmp, "results")
    os.makedirs(results_dir, exist_ok=True)
    trials_path = os.path.join(results_dir, "trials.jsonl")
    open(trials_path, "w").close()
    return skills_root, scenarios_root, trials_path


def write_trial(trials_path, trial_id, variant, scenario, pass_, total_chars, reward=None, block=None):
    if reward is None:
        reward = (1.0 / total_chars) if (pass_ and total_chars) else 0.0
    rec = {
        "trial_id": trial_id, "ts": "2026-01-01T00:00:00Z", "variant": variant,
        "scenario": scenario, "session_id": "s-%s" % trial_id, "env_dir": "/tmp/x",
        "pass": pass_, "grade_output": "", "main_chars": total_chars, "subagent_chars": 0,
        "total_chars": total_chars, "reward": reward, "duration_s": 10, "notes": "",
    }
    if block is not None:
        rec["block"] = block
    with open(trials_path, "a") as f:
        f.write(json.dumps(rec) + "\n")


def run_bandit(cmd, skills_root, scenarios_root, trials_path, seed=None, extra_env=None):
    env = dict(os.environ)
    env["SKILLS_ROOT"] = skills_root
    env["SCENARIOS_ROOT"] = scenarios_root
    env["TRIALS_PATH"] = trials_path
    if seed is not None:
        env["SEED"] = str(seed)
    if extra_env:
        env.update(extra_env)
    p = subprocess.run(
        [sys.executable, BANDIT_PY, cmd], env=env, capture_output=True, text=True, timeout=60,
    )
    return p


# --------------------------------------------------------------------------
# Unit tests: pure functions
# --------------------------------------------------------------------------

def test_discover_arms_excludes_smoke():
    with tempfile.TemporaryDirectory() as tmp:
        skills_root, _, _ = make_fixture_tree(
            tmp, ["variant-a", "variant-b"], ["scenario-1"], smoke_arm_names=["smoke-skill", "smoke-x"],
        )
        arms = bandit.discover_arms(skills_root)
        assert arms == ["variant-a", "variant-b"], arms


def test_discover_scenarios_requires_all_three_files():
    with tempfile.TemporaryDirectory() as tmp:
        scenarios_root = os.path.join(tmp, "envs", "scenarios")
        os.makedirs(os.path.join(scenarios_root, "complete"))
        for fname in ("setup.sh", "task-prompt.md", "grade.sh"):
            open(os.path.join(scenarios_root, "complete", fname), "w").close()
        os.makedirs(os.path.join(scenarios_root, "incomplete"))
        open(os.path.join(scenarios_root, "incomplete", "setup.sh"), "w").close()
        scenarios = bandit.discover_scenarios(scenarios_root)
        assert scenarios == ["complete"], scenarios


def test_seed_phase_round_robin():
    arms = ["variant-a", "variant-b"]
    stats = {a: {"trials": 0, "successes": 0, "failures": 0, "chars": [], "rewards": []} for a in arms}
    order = []
    for _ in range(6):
        pick = bandit.seed_phase_pick(stats, arms)
        assert pick is not None
        order.append(pick)
        stats[pick]["trials"] += 1
    assert order == ["variant-a", "variant-b", "variant-a", "variant-b", "variant-a", "variant-b"], order
    # All arms now at 3 -> seed phase over.
    assert bandit.seed_phase_pick(stats, arms) is None


def test_seed_phase_respects_preexisting_counts():
    arms = ["variant-a", "variant-b"]
    stats = {
        "variant-a": {"trials": 3, "successes": 3, "failures": 0, "chars": [1000], "rewards": [0.001]},
        "variant-b": {"trials": 1, "successes": 0, "failures": 1, "chars": [], "rewards": [0.0]},
    }
    assert bandit.seed_phase_pick(stats, arms) == "variant-b"


def test_scenario_pick_least_used_alphabetical_tiebreak():
    scenarios = ["scenario-b", "scenario-a", "scenario-c"]
    counts = {"scenario-a": 2, "scenario-b": 0, "scenario-c": 0}
    assert bandit.scenario_pick(counts, scenarios) == "scenario-b"
    counts2 = {"scenario-a": 1, "scenario-b": 1, "scenario-c": 1}
    assert bandit.scenario_pick(counts2, scenarios) == "scenario-a"


def test_arm_stats_ignores_unrecognized_variants():
    trials = [
        {"variant": "variant-a", "pass": True, "total_chars": 1000, "reward": 0.001},
        {"variant": "smoke-skill", "pass": True, "total_chars": 999, "reward": 0.001},
        {"variant": "variant-a", "pass": False, "total_chars": 0, "reward": 0.0},
    ]
    stats = bandit.arm_stats(trials, ["variant-a"])
    assert stats["variant-a"]["trials"] == 2
    assert stats["variant-a"]["successes"] == 1
    assert stats["variant-a"]["failures"] == 1
    assert stats["variant-a"]["chars"] == [1000]


def test_sampled_reward_is_probability_times_positive():
    rng = bandit.random.Random(1234)
    for _ in range(50):
        r = bandit.sampled_reward(rng, successes=2, failures=1, chars=[100000, 200000, 150000])
        assert r > 0


def test_sampled_reward_no_data_uses_prior():
    rng = bandit.random.Random(1234)
    vals = [bandit.sampled_reward(rng, 0, 0, []) for _ in range(2000)]
    # With Beta(1,1) and prior mean log(3e5), expected reward on average
    # should be roughly 0.5 * exp(-log(3e5)) = 0.5/3e5, well within an order
    # of magnitude given sampling noise.
    mean_val = sum(vals) / len(vals)
    assert 1e-7 < mean_val < 1e-5, mean_val


def test_fisher_exact_perfect_separation_n4():
    # Classic hand-checkable case: [[2,0],[0,2]] -> p = 1/3.
    p = bandit.fisher_exact_two_sided(2, 0, 0, 2)
    assert abs(p - (1.0 / 3.0)) < 1e-9, p


def test_fisher_exact_trivial_n2():
    # [[1,0],[0,1]] -> both possible tables have equal probability -> p = 1.
    p = bandit.fisher_exact_two_sided(1, 0, 0, 1)
    assert abs(p - 1.0) < 1e-9, p


def test_fisher_exact_symmetric_under_relabeling():
    p1 = bandit.fisher_exact_two_sided(8, 2, 1, 5)
    p2 = bandit.fisher_exact_two_sided(2, 8, 5, 1)  # swap columns
    assert abs(p1 - p2) < 1e-9, (p1, p2)
    assert 0.0 <= p1 <= 1.0


def test_mann_whitney_fully_separated():
    u, z, p = bandit.mann_whitney_u([1, 2, 3], [4, 5, 6])
    assert u == 0.0, u
    assert p < 0.2, p  # normal approx on n=3,3; exact min p is ~0.1


def test_mann_whitney_identical_values_returns_nan_safely():
    u, z, p = bandit.mann_whitney_u([1, 1, 1], [1, 1, 1])
    assert u == 4.5, u
    assert math.isnan(z)
    assert math.isnan(p)


# --------------------------------------------------------------------------
# Integration tests: full CLI via subprocess
# --------------------------------------------------------------------------

def test_next_seed_phase_end_to_end():
    with tempfile.TemporaryDirectory() as tmp:
        skills_root, scenarios_root, trials_path = make_fixture_tree(
            tmp, ["variant-a", "variant-b"], ["scenario-1", "scenario-2"],
        )
        picks = []
        for _ in range(6):
            p = run_bandit("next", skills_root, scenarios_root, trials_path, seed=42)
            assert p.returncode == 0, p.stderr
            out = p.stdout.strip()
            variant, scenario = out.split()
            picks.append((variant, scenario))
            write_trial(trials_path, "t%03d" % (len(picks)), variant, scenario, True, 100000)
        variants_picked = [v for v, s in picks]
        assert variants_picked == ["variant-a", "variant-b", "variant-a", "variant-b", "variant-a", "variant-b"], variants_picked
        scenarios_picked = [s for v, s in picks]
        assert scenarios_picked == ["scenario-1", "scenario-2", "scenario-1", "scenario-2", "scenario-1", "scenario-2"], scenarios_picked


def test_next_stops_at_cap():
    with tempfile.TemporaryDirectory() as tmp:
        skills_root, scenarios_root, trials_path = make_fixture_tree(
            tmp, ["variant-a", "variant-b"], ["scenario-1"],
        )
        for i in range(15):
            variant = "variant-a" if i % 2 == 0 else "variant-b"
            write_trial(trials_path, "t%03d" % i, variant, "scenario-1", True, 100000)
        p = run_bandit("next", skills_root, scenarios_root, trials_path, seed=1)
        assert p.returncode == 0, p.stderr
        assert p.stdout.strip() == "STOP cap-reached", p.stdout


def test_next_cap_ignores_unrecognized_variants():
    with tempfile.TemporaryDirectory() as tmp:
        skills_root, scenarios_root, trials_path = make_fixture_tree(
            tmp, ["variant-a"], ["scenario-1"],
        )
        # 20 leftover/smoke trials for a variant that isn't a discovered arm
        # must not count toward the cap or the seed phase.
        for i in range(20):
            write_trial(trials_path, "t%03d" % i, "smoke-skill", "scenario-1", True, 100000)
        p = run_bandit("next", skills_root, scenarios_root, trials_path, seed=1)
        assert p.returncode == 0, p.stderr
        assert p.stdout.strip() == "variant-a scenario-1", p.stdout


def test_next_is_deterministic_with_seed():
    with tempfile.TemporaryDirectory() as tmp:
        skills_root, scenarios_root, trials_path = make_fixture_tree(
            tmp, ["variant-a", "variant-b", "variant-c"], ["scenario-1", "scenario-2"],
        )
        # Push past the seed phase (3 per arm = 9 trials) so we exercise the
        # Thompson-sampling branch, then confirm the same SEED reproduces
        # the same pick given identical trial history.
        for i in range(9):
            variant = ["variant-a", "variant-b", "variant-c"][i % 3]
            scenario = ["scenario-1", "scenario-2"][i % 2]
            write_trial(trials_path, "t%03d" % i, variant, scenario, i % 4 != 0, 80000 + i * 1000)
        p1 = run_bandit("next", skills_root, scenarios_root, trials_path, seed=777)
        p2 = run_bandit("next", skills_root, scenarios_root, trials_path, seed=777)
        assert p1.returncode == 0 and p2.returncode == 0, (p1.stderr, p2.stderr)
        assert p1.stdout == p2.stdout, (p1.stdout, p2.stdout)


def test_report_runs_and_mentions_underpowered():
    with tempfile.TemporaryDirectory() as tmp:
        skills_root, scenarios_root, trials_path = make_fixture_tree(
            tmp, ["variant-a", "variant-b"], ["scenario-1"],
        )
        for i in range(10):
            variant = "variant-a" if i % 2 == 0 else "variant-b"
            write_trial(trials_path, "t%03d" % i, variant, "scenario-1", i % 3 != 0, 90000 + i * 500)
        p = run_bandit("report", skills_root, scenarios_root, trials_path, seed=99)
        assert p.returncode == 0, p.stderr
        assert "P(arm is best)" in p.stdout
        assert "Pairwise P(row beats col)" in p.stdout
        assert "Fisher's exact test" in p.stdout
        assert "underpowered" in p.stdout
        assert "variant-a" in p.stdout and "variant-b" in p.stdout


def test_report_single_arm_does_not_crash():
    with tempfile.TemporaryDirectory() as tmp:
        skills_root, scenarios_root, trials_path = make_fixture_tree(
            tmp, ["variant-a"], ["scenario-1"],
        )
        write_trial(trials_path, "t001", "variant-a", "scenario-1", True, 100000)
        p = run_bandit("report", skills_root, scenarios_root, trials_path, seed=1)
        assert p.returncode == 0, p.stderr
        assert "Only one arm present" in p.stdout


# --------------------------------------------------------------------------
# Round 2: next2 block sequencing (pure-function, no subprocess)
# --------------------------------------------------------------------------

def test_next_block_pick_full_sequence_arm_completeness_scenario_cycling_and_rotation():
    arms = ["variant-a", "variant-b", "variant-c"]
    scenarios = ["s1", "s2"]
    r2_trials = []
    picks = []
    for _ in range(7):
        variant, scenario, block_id = bandit.next_block_pick(arms, scenarios, r2_trials, "r2")
        picks.append((variant, scenario, block_id))
        r2_trials.append({"variant": variant, "block": block_id})

    expected = [
        ("variant-a", "s1", "r2-s1-1"),
        ("variant-b", "s1", "r2-s1-1"),
        ("variant-c", "s1", "r2-s1-1"),
        # scenario cycles to s2 only once every arm has run s1's block;
        # arm order rotates (this block starts with variant-b, not -a).
        ("variant-b", "s2", "r2-s2-1"),
        ("variant-c", "s2", "r2-s2-1"),
        ("variant-a", "s2", "r2-s2-1"),
        # cycles back to s1 for cycle 2, rotated again (starts with variant-c).
        ("variant-c", "s1", "r2-s1-2"),
    ]
    assert picks == expected, picks

    # Every completed block (r2-s1-1, r2-s2-1) has exactly the full arm set.
    for block_id in ("r2-s1-1", "r2-s2-1"):
        variants_in_block = {t["variant"] for t in r2_trials if t["block"] == block_id}
        assert variants_in_block == set(arms), (block_id, variants_in_block)


def test_next_block_pick_resumes_from_partial_block():
    arms = ["variant-a", "variant-b", "variant-c"]
    scenarios = ["s1"]
    # variant-a already ran r2-s1-1; only b and c should remain candidates.
    r2_trials = [{"variant": "variant-a", "block": "r2-s1-1"}]
    variant, scenario, block_id = bandit.next_block_pick(arms, scenarios, r2_trials, "r2")
    assert block_id == "r2-s1-1" and scenario == "s1"
    assert variant in ("variant-b", "variant-c")


def test_next_block_pick_uses_given_prefix_for_round3():
    arms = ["variant-a", "variant-b"]
    scenarios = ["s1"]
    variant, scenario, block_id = bandit.next_block_pick(arms, scenarios, [], "r3")
    assert block_id == "r3-s1-1", block_id
    assert variant == "variant-a"


def test_round_trials_r2_and_r3_do_not_leak_into_each_other():
    arms = ["variant-a", "variant-b"]
    trials = [
        {"variant": "variant-a", "block": "r2-s1-1", "pass": True, "scenario": "s1"},
        {"variant": "variant-b", "block": "r3-s1-1", "pass": True, "scenario": "s1"},
        {"variant": "variant-a", "scenario": "s1", "pass": True},  # phase-1, no block at all
    ]
    r2 = bandit.round_trials(trials, arms, "r2")
    r3 = bandit.round_trials(trials, arms, "r3")
    assert [t["block"] for t in r2] == ["r2-s1-1"]
    assert [t["block"] for t in r3] == ["r3-s1-1"]
    p1 = bandit.phase1_trials(trials, arms)
    assert len(p1) == 1 and "block" not in p1[0]

    # A stray block_id that merely CONTAINS "r3-" past position 0 (e.g. a
    # hypothetical scenario literally named "r3-thing") must not be mistaken
    # for round 3 -- only a block_id starting with "r3-" counts.
    tricky = [{"variant": "variant-a", "block": "r2-r3-thing-1", "pass": True, "scenario": "r3-thing"}]
    assert bandit.round_trials(tricky, arms, "r3") == []
    assert bandit.round_trials(tricky, arms, "r2") == tricky


def test_arm_order_for_block_rotates():
    arms = ["variant-a", "variant-b", "variant-c"]
    assert bandit.arm_order_for_block(arms, 0) == ["variant-a", "variant-b", "variant-c"]
    assert bandit.arm_order_for_block(arms, 1) == ["variant-b", "variant-c", "variant-a"]
    assert bandit.arm_order_for_block(arms, 2) == ["variant-c", "variant-a", "variant-b"]
    assert bandit.arm_order_for_block(arms, 3) == ["variant-a", "variant-b", "variant-c"]  # wraps


# --------------------------------------------------------------------------
# Round 2: next2 integration (subprocess CLI)
# --------------------------------------------------------------------------

def run_full_round2(skills_root, scenarios_root, trials_path, seed, n_calls):
    """Repeatedly call `bandit.py next2`, writing back a synthetic trial (with
    the block id it printed) after each non-STOP call, exactly as run-trial.sh
    would. Returns the list of (variant, scenario, block_id) tuples printed,
    stopping early (and appending "STOP") if the cap is hit."""
    picks = []
    for i in range(n_calls):
        p = run_bandit("next2", skills_root, scenarios_root, trials_path, seed=seed)
        assert p.returncode == 0, p.stderr
        out = p.stdout.strip()
        if out == "STOP cap-reached":
            picks.append("STOP")
            break
        variant, scenario, block_id = out.split()
        picks.append((variant, scenario, block_id))
        write_trial(trials_path, "t%03d" % i, variant, scenario, True, 100000 + i * 111, block=block_id)
    return picks


def test_next2_full_cycle_matches_expected_blocks_and_stops_at_cap():
    with tempfile.TemporaryDirectory() as tmp:
        arms = ["variant-a", "variant-b", "variant-c"]
        scenarios = ["scenario-1", "scenario-2", "scenario-3", "scenario-4"]
        skills_root, scenarios_root, trials_path = make_fixture_tree(tmp, arms, scenarios)

        picks = run_full_round2(skills_root, scenarios_root, trials_path, seed=1, n_calls=25)

        # 18-trial cap = 6 complete 3-arm blocks: cycle 1 covers all 4
        # scenarios (4 blocks), cycle 2 covers the first 2 (alphabetical) of
        # the 4 scenarios (2 more blocks) = 6 blocks * 3 arms = 18, then STOP.
        assert picks[-1] == "STOP", picks
        real_picks = picks[:-1]
        assert len(real_picks) == 18, len(real_picks)

        blocks_seen = []
        for variant, scenario, block_id in real_picks:
            if block_id not in blocks_seen:
                blocks_seen.append(block_id)
        assert blocks_seen == [
            "r2-scenario-1-1", "r2-scenario-2-1", "r2-scenario-3-1", "r2-scenario-4-1",
            "r2-scenario-1-2", "r2-scenario-2-2",
        ], blocks_seen

        # Every block got every arm exactly once.
        from collections import defaultdict
        by_block = defaultdict(list)
        for variant, scenario, block_id in real_picks:
            by_block[block_id].append(variant)
        for block_id, variants in by_block.items():
            assert sorted(variants) == arms, (block_id, variants)


def test_next2_ignores_phase1_records():
    with tempfile.TemporaryDirectory() as tmp:
        arms = ["variant-a", "variant-b"]
        scenarios = ["scenario-1", "scenario-2"]
        skills_root, scenarios_root, trials_path = make_fixture_tree(tmp, arms, scenarios)
        # A pile of phase-1 (no block field) trials for these same arms/scenarios
        # must not perturb round-2 sequencing at all.
        for i in range(10):
            write_trial(trials_path, "p%03d" % i, arms[i % 2], scenarios[i % 2], True, 50000)
        p = run_bandit("next2", skills_root, scenarios_root, trials_path, seed=1)
        assert p.returncode == 0, p.stderr
        variant, scenario, block_id = p.stdout.strip().split()
        assert block_id == "r2-scenario-1-1", p.stdout
        assert variant == "variant-a", p.stdout  # first block, no rotation yet


# --------------------------------------------------------------------------
# Round 2: record block-field passthrough (build_record.py)
# --------------------------------------------------------------------------

def test_build_record_omits_block_when_absent_and_includes_when_present():
    build_record_py = os.path.join(RUNNER_DIR, "lib", "build_record.py")
    with tempfile.TemporaryDirectory() as tmp:
        grade_log = os.path.join(tmp, "grade.log")
        with open(grade_log, "w") as f:
            f.write("PASS: ok\n")

        def build(out_name, block_args):
            out = os.path.join(tmp, out_name)
            args = [
                sys.executable, build_record_py,
                "--out", out, "--trial-id", "t001", "--ts", "2026-01-01T00:00:00Z",
                "--variant", "variant-a", "--scenario", "declare-coupling",
                "--session-id", "sess1", "--env-dir", "/tmp/x", "--pass", "true",
                "--grade-output-file", grade_log, "--main-chars", "100",
                "--subagent-chars", "0", "--total-chars", "100", "--reward", "0.01",
                "--duration-s", "5", "--notes", "",
            ] + block_args
            p = subprocess.run(args, capture_output=True, text=True, timeout=30)
            assert p.returncode == 0, p.stderr
            with open(out) as f:
                return json.load(f)

        rec_no_block = build("no_block.json", [])
        assert "block" not in rec_no_block, rec_no_block

        rec_with_block = build("with_block.json", ["--block", "r2-declare-coupling-1"])
        assert rec_with_block.get("block") == "r2-declare-coupling-1", rec_with_block

        rec_empty_block = build("empty_block.json", ["--block", ""])
        assert "block" not in rec_empty_block, rec_empty_block  # empty value -> treated as absent


# --------------------------------------------------------------------------
# Round 2: stratified stats / scenario winner / sign test (pure functions)
# --------------------------------------------------------------------------

def test_stratified_stats_and_scenario_winner():
    arms = ["variant-a", "variant-b"]
    scenarios = ["s1", "s2"]
    trials = [
        {"variant": "variant-a", "scenario": "s1", "pass": True, "total_chars": 100000, "block": "r2-s1-1"},
        {"variant": "variant-b", "scenario": "s1", "pass": True, "total_chars": 50000, "block": "r2-s1-1"},
        {"variant": "variant-a", "scenario": "s2", "pass": False, "total_chars": 0, "block": "r2-s2-1"},
        {"variant": "variant-b", "scenario": "s2", "pass": True, "total_chars": 200000, "block": "r2-s2-1"},
    ]
    strat = bandit.stratified_stats(trials, arms, scenarios)
    assert strat["s1"]["variant-a"]["successes"] == 1
    assert strat["s1"]["variant-a"]["chars"] == [100000]
    assert strat["s2"]["variant-a"]["failures"] == 1
    assert strat["s2"]["variant-a"]["chars"] == []

    # s1: both pass, variant-b is cheaper (50k < 100k) -> variant-b wins.
    assert bandit.scenario_winner(strat["s1"], arms) == "variant-b"
    # s2: variant-a failed, variant-b passed -> variant-b wins (more successes).
    assert bandit.scenario_winner(strat["s2"], arms) == "variant-b"

    # No data at all for a scenario -> no winner.
    empty_strat = bandit.stratified_stats([], arms, ["s3"])
    assert bandit.scenario_winner(empty_strat["s3"], arms) is None


def test_sign_test_two_sided_hand_checkable():
    # All 5/5 wins: p = 2 * P(X=5 | Binomial(5, 0.5)) = 2 * (1/32) = 0.0625.
    p = bandit.sign_test_two_sided(5, 5)
    assert abs(p - 0.0625) < 1e-9, p
    # 3/6 wins (exactly at the null) -> p should be 1.0 (most likely outcome).
    p2 = bandit.sign_test_two_sided(3, 6)
    assert abs(p2 - 1.0) < 1e-9, p2
    # n=0 (no comparable pairs) -> nan, not a crash.
    assert math.isnan(bandit.sign_test_two_sided(0, 0))


def test_paired_sign_test_all_wins():
    r2 = []
    for i in range(5):
        r2.append({"variant": "variant-a", "block": "r2-s-%d" % i, "reward": 0.01})
        r2.append({"variant": "variant-b", "block": "r2-s-%d" % i, "reward": 0.001})
    k, n, p = bandit.paired_sign_test(r2, "variant-a", "variant-b")
    assert (k, n) == (5, 5), (k, n)
    assert abs(p - 0.0625) < 1e-9, p


def test_paired_sign_test_drops_ties_and_unmatched_blocks():
    r2 = [
        {"variant": "variant-a", "block": "r2-s-0", "reward": 0.5},
        {"variant": "variant-b", "block": "r2-s-0", "reward": 0.5},  # tie -> dropped
        {"variant": "variant-a", "block": "r2-s-1", "reward": 0.9},
        {"variant": "variant-b", "block": "r2-s-1", "reward": 0.1},  # a wins
        {"variant": "variant-a", "block": "r2-s-2", "reward": 0.1},  # no matching b -> dropped
    ]
    k, n, p = bandit.paired_sign_test(r2, "variant-a", "variant-b")
    assert (k, n) == (1, 1), (k, n)


# --------------------------------------------------------------------------
# Round 2: report2 integration (subprocess CLI)
# --------------------------------------------------------------------------

def test_report2_ignores_phase1_and_reports_no_data_message():
    with tempfile.TemporaryDirectory() as tmp:
        skills_root, scenarios_root, trials_path = make_fixture_tree(
            tmp, ["variant-a", "variant-b"], ["scenario-1"],
        )
        for i in range(5):
            write_trial(trials_path, "t%03d" % i, "variant-a", "scenario-1", True, 90000)
        p = run_bandit("report2", skills_root, scenarios_root, trials_path, seed=1)
        assert p.returncode == 0, p.stderr
        assert "No round-2 trials recorded yet" in p.stdout


def test_report2_filters_phase1_and_runs_stratified_report():
    with tempfile.TemporaryDirectory() as tmp:
        arms = ["variant-a", "variant-b"]
        scenarios = ["scenario-1", "scenario-2"]
        skills_root, scenarios_root, trials_path = make_fixture_tree(tmp, arms, scenarios)

        # Phase-1 noise that must be excluded from report2 entirely.
        for i in range(5):
            write_trial(trials_path, "p%03d" % i, "variant-a", "scenario-1", False, 0)

        # A couple of complete round-2 blocks.
        for i, (scenario, cycle) in enumerate([("scenario-1", 1), ("scenario-2", 1)]):
            block_id = "r2-%s-%d" % (scenario, cycle)
            write_trial(trials_path, "r%03da" % i, "variant-a", scenario, True, 80000, block=block_id)
            write_trial(trials_path, "r%03db" % i, "variant-b", scenario, True, 120000, block=block_id)

        p = run_bandit("report2", skills_root, scenarios_root, trials_path, seed=1)
        assert p.returncode == 0, p.stderr
        assert "No round-2 trials recorded yet" not in p.stdout
        assert "[scenario-1]" in p.stdout and "[scenario-2]" in p.stdout
        assert "winner: variant-a" in p.stdout  # cheaper (80k < 120k) in both scenarios
        assert "Overall P(arm is best)" in p.stdout
        assert "Paired sign test" in p.stdout
        # The 5 phase-1 failures for variant-a/scenario-1 must not leak into
        # the round-2 table (which would otherwise show variant-a with 7
        # trials / 2 successes instead of 2 trials / 2 successes there).
        assert "        5           0" not in p.stdout


# --------------------------------------------------------------------------
# Round 3: next3/report3 (r3- prefix, cap 24, 4 arms x 6 scenarios) +
# r2/r3 mutual isolation now that both can coexist in trials.jsonl
# --------------------------------------------------------------------------

def test_next3_full_cycle_4arms_6scenarios_matches_expected_blocks_and_stops_at_cap_24():
    with tempfile.TemporaryDirectory() as tmp:
        arms = ["variant-a", "variant-b", "variant-d", "variant-e"]
        scenarios = [
            "consistent-update", "declare-coupling", "inspect-report",
            "reanchor-retire", "reconcile-drift", "triage-mixed-drift",
        ]
        skills_root, scenarios_root, trials_path = make_fixture_tree(tmp, arms, scenarios)

        picks = []
        for i in range(30):
            p = run_bandit("next3", skills_root, scenarios_root, trials_path, seed=1)
            assert p.returncode == 0, p.stderr
            out = p.stdout.strip()
            if out == "STOP cap-reached":
                picks.append("STOP")
                break
            variant, scenario, block_id = out.split()
            picks.append((variant, scenario, block_id))
            write_trial(trials_path, "t%03d" % i, variant, scenario, True, 100000 + i * 111, block=block_id)

        assert picks[-1] == "STOP", picks
        real_picks = picks[:-1]
        # cap 24 / 4 arms = exactly 6 blocks = one full cycle over the 6
        # scenarios (one complete 4x6 grid, as CONTRACT specifies for round 3).
        assert len(real_picks) == 24, len(real_picks)
        blocks_seen = []
        for variant, scenario, block_id in real_picks:
            assert block_id.startswith("r3-"), block_id
            if block_id not in blocks_seen:
                blocks_seen.append(block_id)
        assert blocks_seen == ["r3-%s-1" % s for s in scenarios], blocks_seen

        from collections import defaultdict
        by_block = defaultdict(list)
        for variant, scenario, block_id in real_picks:
            by_block[block_id].append(variant)
        for block_id, variants in by_block.items():
            assert sorted(variants) == arms, (block_id, variants)
        # Arm-order rotation: block 0 starts with variant-a, block 1 (next
        # scenario) starts with the next arm in rotation (variant-b), etc.
        # Derived from pick order (not from by_block, which loses ordering).
        firsts = []
        seen_blocks = set()
        for variant, scenario, block_id in real_picks:
            if block_id not in seen_blocks:
                seen_blocks.add(block_id)
                firsts.append(variant)
        assert firsts == ["variant-a", "variant-b", "variant-d", "variant-e", "variant-a", "variant-b"], firsts


def test_next3_and_next2_are_mutually_blind_to_each_others_blocks():
    with tempfile.TemporaryDirectory() as tmp:
        arms = ["variant-a", "variant-b"]
        scenarios = ["scenario-1", "scenario-2"]
        skills_root, scenarios_root, trials_path = make_fixture_tree(tmp, arms, scenarios)

        # Fully complete round-2's first block for BOTH arms.
        write_trial(trials_path, "t000", "variant-a", "scenario-1", True, 90000, block="r2-scenario-1-1")
        write_trial(trials_path, "t001", "variant-b", "scenario-1", True, 90000, block="r2-scenario-1-1")

        # next3 must start completely fresh -- round 2 being fully done with
        # scenario-1's first block must not make next3 think r3-scenario-1-1
        # is done, nor skip ahead.
        p3 = run_bandit("next3", skills_root, scenarios_root, trials_path, seed=1)
        assert p3.returncode == 0, p3.stderr
        variant, scenario, block_id = p3.stdout.strip().split()
        assert block_id == "r3-scenario-1-1", p3.stdout
        assert variant == "variant-a", p3.stdout

        # Now complete round 3's first block too, and confirm next2 (run
        # again from scratch) still correctly reports its own next slot
        # (scenario-2's block) rather than being confused by r3 data.
        write_trial(trials_path, "t002", "variant-a", "scenario-1", True, 90000, block="r3-scenario-1-1")
        write_trial(trials_path, "t003", "variant-b", "scenario-1", True, 90000, block="r3-scenario-1-1")
        p2 = run_bandit("next2", skills_root, scenarios_root, trials_path, seed=1)
        assert p2.returncode == 0, p2.stderr
        variant2, scenario2, block_id2 = p2.stdout.strip().split()
        assert block_id2 == "r2-scenario-2-1", p2.stdout


def test_report3_filters_to_r3_only_ignoring_phase1_and_r2():
    with tempfile.TemporaryDirectory() as tmp:
        arms = ["variant-a", "variant-b"]
        scenarios = ["scenario-1", "scenario-2"]
        skills_root, scenarios_root, trials_path = make_fixture_tree(tmp, arms, scenarios)

        # Phase-1 noise.
        for i in range(3):
            write_trial(trials_path, "p%03d" % i, "variant-a", "scenario-1", False, 0)
        # Round-2 noise (completed block) -- must not leak into report3.
        write_trial(trials_path, "s000", "variant-a", "scenario-1", True, 999999, block="r2-scenario-1-1")
        write_trial(trials_path, "s001", "variant-b", "scenario-1", True, 999999, block="r2-scenario-1-1")

        # report3 with no r3- trials yet -> short-circuit message.
        p_empty = run_bandit("report3", skills_root, scenarios_root, trials_path, seed=1)
        assert p_empty.returncode == 0, p_empty.stderr
        assert "No round-3 trials recorded yet" in p_empty.stdout

        # Now add round-3 data and confirm it (and only it) shows up.
        write_trial(trials_path, "t000", "variant-a", "scenario-1", True, 80000, block="r3-scenario-1-1")
        write_trial(trials_path, "t001", "variant-b", "scenario-1", True, 120000, block="r3-scenario-1-1")
        p = run_bandit("report3", skills_root, scenarios_root, trials_path, seed=1)
        assert p.returncode == 0, p.stderr
        assert "round 3 report" in p.stdout
        assert "No round-3 trials recorded yet" not in p.stdout
        assert "winner: variant-a" in p.stdout  # 80k < 120k
        # The round-2 block's 999999-char trials must not appear anywhere.
        assert "999999" not in p.stdout


def test_discover_arms_ignores_sibling_retired_dir():
    with tempfile.TemporaryDirectory() as tmp:
        skills_root = os.path.join(tmp, "skills")
        retired_root = os.path.join(tmp, "skills-retired")
        for a in ("variant-a", "variant-b"):
            d = os.path.join(skills_root, a)
            os.makedirs(d)
            open(os.path.join(d, "SKILL.md"), "w").close()
        d = os.path.join(retired_root, "variant-c")
        os.makedirs(d)
        open(os.path.join(d, "SKILL.md"), "w").close()

        arms = bandit.discover_arms(skills_root)
        assert arms == ["variant-a", "variant-b"], arms  # variant-c never seen


# --------------------------------------------------------------------------
# Arm retirement: a completed round's cap must stay closed, and its
# historical rows must keep showing up in reports, after an arm's skills/
# dir is removed. (Found for real: retiring variant-c mid-round-3-prep made
# `next`/`next2` propose fresh trials instead of correctly saying STOP,
# because their cap checks were filtering out the retired arm's already-
# spent trials. See NOTES.md §10.)
# --------------------------------------------------------------------------

def test_next_cap_stays_closed_after_arm_retirement():
    with tempfile.TemporaryDirectory() as tmp:
        # Phase-1 fully completed (15 trials) across 3 arms...
        skills_root, scenarios_root, trials_path = make_fixture_tree(
            tmp, ["variant-a", "variant-b", "variant-c"], ["scenario-1"],
        )
        for i in range(15):
            variant = ["variant-a", "variant-b", "variant-c"][i % 3]
            write_trial(trials_path, "t%03d" % i, variant, "scenario-1", True, 100000)
        p_before = run_bandit("next", skills_root, scenarios_root, trials_path, seed=1)
        assert p_before.stdout.strip() == "STOP cap-reached", p_before.stdout

        # ...then variant-c is retired (its skills/ dir removed).
        import shutil
        shutil.rmtree(os.path.join(skills_root, "variant-c"))

        p_after = run_bandit("next", skills_root, scenarios_root, trials_path, seed=1)
        assert p_after.stdout.strip() == "STOP cap-reached", p_after.stdout  # must NOT reopen


def test_next2_cap_stays_closed_after_arm_retirement():
    with tempfile.TemporaryDirectory() as tmp:
        arms = ["variant-a", "variant-b", "variant-c"]
        scenarios = ["scenario-1", "scenario-2", "scenario-3"]
        skills_root, scenarios_root, trials_path = make_fixture_tree(tmp, arms, scenarios)
        # A complete 3-arm x 3-scenario grid = cap-equivalent for this fixture.
        i = 0
        for scenario in scenarios:
            for variant in arms:
                write_trial(trials_path, "t%03d" % i, variant, scenario, True, 100000, block="r2-%s-1" % scenario)
                i += 1
        p_before = run_bandit("next2", skills_root, scenarios_root, trials_path, seed=1)
        # Not necessarily STOP (ROUND2_CAP is a fixed 18, this fixture only
        # made 9) -- what matters is what happens across the retirement.
        before_out = p_before.stdout.strip()

        import shutil
        shutil.rmtree(os.path.join(skills_root, "variant-c"))
        p_after = run_bandit("next2", skills_root, scenarios_root, trials_path, seed=1)
        after_out = p_after.stdout.strip()

        # Whatever next2 said before retirement (STOP or a real pick), the
        # trial *count* feeding the cap must be identical after retirement
        # too -- i.e. retirement must not change whether the round looks
        # capped. Assert this directly via the underlying trial count rather
        # than the exact pick (which may legitimately differ once variant-c
        # is no longer a candidate arm).
        assert (before_out == "STOP cap-reached") == (after_out == "STOP cap-reached")


def test_cmd_next_cap_counts_retired_arm_trials_directly():
    # Narrower, deterministic version of the above: directly exercise the
    # counting helper next/next2 rely on, rather than the full CLI, so this
    # doesn't depend on incidental fixture sizing.
    trials = [
        {"variant": "variant-a", "pass": True, "total_chars": 100000, "reward": 1e-5},
        {"variant": "variant-b", "pass": True, "total_chars": 100000, "reward": 1e-5},
        {"variant": "variant-c", "pass": True, "total_chars": 100000, "reward": 1e-5},
    ]
    # Even if "arms" (live) no longer includes variant-c, the "_all" cap-check
    # helper must still count its trial.
    assert len(bandit.phase1_trials_all(trials)) == 3
    assert len(bandit.phase1_trials(trials, ["variant-a", "variant-b"])) == 2  # for arm balancing only

    r2_trials = [
        {"variant": "variant-a", "block": "r2-s-1", "pass": True, "total_chars": 1, "reward": 1.0},
        {"variant": "variant-c", "block": "r2-s-1", "pass": True, "total_chars": 1, "reward": 1.0},
    ]
    assert len(bandit.round_trials_all(r2_trials, "r2")) == 2
    assert len(bandit.round_trials(r2_trials, ["variant-a"], "r2")) == 1


def test_historical_arms_includes_retired_variant():
    live_arms = ["variant-a", "variant-b"]
    trials = [
        {"variant": "variant-a", "pass": True},
        {"variant": "variant-c", "pass": True},  # retired, but has historical data
        {"variant": "smoke-skill", "pass": True},  # must still be excluded upstream (not present here since caller pre-filters)
    ]
    # historical_arms itself doesn't re-filter smoke -- callers pass it
    # already-smoke-filtered trials (phase1_trials_all/round_trials_all do
    # that filtering). Simulate that contract here.
    filtered = [t for t in trials if not bandit.is_smoke_variant(t["variant"])]
    arms = bandit.historical_arms(filtered, live_arms)
    assert arms == ["variant-a", "variant-b", "variant-c"], arms


def test_report_shows_retired_arm_and_report2_arithmetic_reflects_original_arm_count():
    with tempfile.TemporaryDirectory() as tmp:
        skills_root, scenarios_root, trials_path = make_fixture_tree(
            tmp, ["variant-a", "variant-b", "variant-c"], ["scenario-1", "scenario-2"],
        )
        for i, variant in enumerate(["variant-a", "variant-b", "variant-c"] * 2):
            write_trial(trials_path, "t%03d" % i, variant, "scenario-1", True, 100000)
        # Complete one round-2 block across all 3 original arms.
        for variant in ["variant-a", "variant-b", "variant-c"]:
            write_trial(trials_path, "r-%s" % variant, variant, "scenario-1", True, 100000, block="r2-scenario-1-1")

        # Retire variant-c.
        import shutil
        shutil.rmtree(os.path.join(skills_root, "variant-c"))

        p_report = run_bandit("report", skills_root, scenarios_root, trials_path, seed=1)
        assert p_report.returncode == 0, p_report.stderr
        assert "variant-c" in p_report.stdout  # historical row still present

        p_report2 = run_bandit("report2", skills_root, scenarios_root, trials_path, seed=1)
        assert p_report2.returncode == 0, p_report2.stderr
        assert "variant-c" in p_report2.stdout
        # 3 arms actually ran this block -> "3-arm blocks" in the prose, not
        # "2-arm" (which is what live-arms-only arithmetic would wrongly say).
        assert "3-arm blocks" in p_report2.stdout


# --------------------------------------------------------------------------
# Round 4 ("confirmation round"): fixed 3-scenario subset, cap 12, r4-
# prefix, plus the pooled r3+r4 paired analysis
# --------------------------------------------------------------------------

ALL_SIX_SCENARIOS = [
    "consistent-update", "declare-coupling", "inspect-report",
    "reanchor-retire", "reconcile-drift", "triage-mixed-drift",
]


def test_next4_restricted_to_fixed_scenarios_cap12_and_ignores_r2_r3():
    with tempfile.TemporaryDirectory() as tmp:
        arms = ["variant-a", "variant-d", "variant-e"]
        skills_root, scenarios_root, trials_path = make_fixture_tree(tmp, arms, ALL_SIX_SCENARIOS)

        # Leftover r2/r3 data for these same arms/scenarios must not
        # consume or influence r4 allocation at all.
        for i, s in enumerate(ALL_SIX_SCENARIOS):
            for a in arms:
                write_trial(trials_path, "r2_%d_%s" % (i, a), a, s, True, 90000, block="r2-%s-1" % s)
                write_trial(trials_path, "r3_%d_%s" % (i, a), a, s, True, 90000, block="r3-%s-1" % s)

        picks = []
        for i in range(15):
            p = run_bandit("next4", skills_root, scenarios_root, trials_path, seed=1)
            assert p.returncode == 0, p.stderr
            out = p.stdout.strip()
            if out == "STOP cap-reached":
                picks.append("STOP")
                break
            variant, scenario, block_id = out.split()
            picks.append((variant, scenario, block_id))
            write_trial(trials_path, "t%03d" % i, variant, scenario, True, 100000 + i * 111, block=block_id)

        assert picks[-1] == "STOP", picks
        real_picks = picks[:-1]
        assert len(real_picks) == 12, len(real_picks)  # cap 12 = 4 complete 3-arm blocks

        scenarios_used = {scenario for _, scenario, _ in real_picks}
        assert scenarios_used == {"declare-coupling", "reconcile-drift", "triage-mixed-drift"}, scenarios_used
        for _, _, block_id in real_picks:
            assert block_id.startswith("r4-"), block_id

        blocks_seen = []
        for variant, scenario, block_id in real_picks:
            if block_id not in blocks_seen:
                blocks_seen.append(block_id)
        assert blocks_seen == [
            "r4-declare-coupling-1", "r4-reconcile-drift-1", "r4-triage-mixed-drift-1",
            "r4-declare-coupling-2",
        ], blocks_seen


def test_next4_fails_loudly_if_a_round4_scenario_dir_is_missing():
    with tempfile.TemporaryDirectory() as tmp:
        arms = ["variant-a", "variant-d", "variant-e"]
        # Only 2 of the 3 required round-4 scenarios exist.
        skills_root, scenarios_root, trials_path = make_fixture_tree(
            tmp, arms, ["declare-coupling", "reconcile-drift"],
        )
        p = run_bandit("next4", skills_root, scenarios_root, trials_path, seed=1)
        assert p.returncode != 0, p.stdout
        assert "triage-mixed-drift" in p.stderr, p.stderr


def test_report4_pools_r3_and_r4_for_confirmation_pairs():
    with tempfile.TemporaryDirectory() as tmp:
        arms = ["variant-a", "variant-d", "variant-e"]
        skills_root, scenarios_root, trials_path = make_fixture_tree(tmp, arms, ALL_SIX_SCENARIOS)

        # Round 3: variant-e beats variant-d in 2 blocks, loses 1; variant-e
        # beats variant-a in all 3. (variant-e reward always higher when it
        # "wins".)
        r3_results = [
            ("scenario-x1", {"variant-e": 0.9, "variant-d": 0.1, "variant-a": 0.1}),
            ("scenario-x2", {"variant-e": 0.9, "variant-d": 0.1, "variant-a": 0.1}),
            # variant-a's reward here (0.05) is deliberately distinct from
            # variant-e's (0.1) -- this block is a LOSS for e vs d but must
            # still be a (non-tied) WIN for e vs a.
            ("scenario-x3", {"variant-e": 0.1, "variant-d": 0.9, "variant-a": 0.05}),
        ]
        for scenario, rewards in r3_results:
            block_id = "r3-%s-1" % scenario
            for variant, reward in rewards.items():
                write_trial(trials_path, "r3-%s-%s" % (scenario, variant), variant, scenario,
                            True, int(1.0 / reward), reward=reward, block=block_id)

        # Round 4: variant-e beats variant-d and variant-a once each.
        block_id_r4 = "r4-declare-coupling-1"
        for variant, reward in {"variant-e": 0.9, "variant-d": 0.1, "variant-a": 0.1}.items():
            write_trial(trials_path, "r4-%s" % variant, variant, "declare-coupling",
                        True, int(1.0 / reward), reward=reward, block=block_id_r4)

        p = run_bandit("report4", skills_root, scenarios_root, trials_path, seed=1)
        assert p.returncode == 0, p.stderr
        out = p.stdout

        assert "Pooled r3+r4 paired analysis" in out
        # variant-e vs variant-d: e won r3-scenario-x1, r3-scenario-x2, r4-declare-coupling-1
        # (3 wins) and lost r3-scenario-x3 (1 win for d) -> 3 vs 1.
        assert "variant-e wins: 3, variant-d wins: 1, ties: 0" in out
        # variant-e vs variant-a: e won all 4 comparable blocks.
        assert "variant-e wins: 4, variant-a wins: 0, ties: 0" in out

        # Cross-check the printed p-values against the function directly.
        pooled = bandit.round_trials_all(bandit.load_trials(trials_path), "r3") + \
            bandit.round_trials_all(bandit.load_trials(trials_path), "r4")
        w1, w2, ties, p_ed = bandit.paired_sign_test_detailed(pooled, "variant-e", "variant-d")
        assert (w1, w2, ties) == (3, 1, 0)
        assert ("p = %.4f" % p_ed) in out

        # report4's OWN stratified table is round-4-only (r4- blocks), not
        # polluted by the pooled section's r3 data -- only 1 real r4- block
        # exists (declare-coupling), so the other two round-4 scenarios must
        # show zero trials in the stratified part of the output (before the
        # pooled section).
        stratified_part = out.split("Pooled r3+r4")[0]
        assert "[reconcile-drift]" in stratified_part
        assert "variant-e                  0           0" in stratified_part


def test_paired_sign_test_detailed_matches_paired_sign_test():
    trials = [
        {"variant": "variant-e", "block": "r3-s-1", "reward": 0.9},
        {"variant": "variant-d", "block": "r3-s-1", "reward": 0.1},
        {"variant": "variant-e", "block": "r4-s-1", "reward": 0.1},
        {"variant": "variant-d", "block": "r4-s-1", "reward": 0.9},
        {"variant": "variant-e", "block": "r4-s-2", "reward": 0.5},
        {"variant": "variant-d", "block": "r4-s-2", "reward": 0.5},  # tie
    ]
    w1, w2, ties, p_detailed = bandit.paired_sign_test_detailed(trials, "variant-e", "variant-d")
    assert (w1, w2, ties) == (1, 1, 1)
    k, n, p_old = bandit.paired_sign_test(trials, "variant-e", "variant-d")
    assert (k, n) == (1, 2)  # ties dropped from n, matching the old (k, n, p) shape
    assert abs(p_detailed - p_old) < 1e-12


def test_next_next2_next3_all_stay_stopped_after_second_retirement():
    with tempfile.TemporaryDirectory() as tmp:
        # Mirrors the real production history: phase-1 + round-2 ran with
        # {a, b, c}; round-3 ran with {a, b, d, e} (c already retired by
        # then); now b retires too, leaving only {a, d, e} live.
        all_ever_arms = ["variant-a", "variant-b", "variant-c", "variant-d", "variant-e"]
        skills_root, scenarios_root, trials_path = make_fixture_tree(tmp, all_ever_arms, ALL_SIX_SCENARIOS)

        for i in range(15):  # phase-1 cap, arms a/b/c
            write_trial(trials_path, "p%03d" % i, ["variant-a", "variant-b", "variant-c"][i % 3],
                        "declare-coupling", True, 100000)
        i = 0
        for s in ALL_SIX_SCENARIOS:  # round-2 cap, arms a/b/c
            for a in ["variant-a", "variant-b", "variant-c"]:
                write_trial(trials_path, "r2_%d" % i, a, s, True, 100000, block="r2-%s-1" % s)
                i += 1
        i = 0
        for s in ALL_SIX_SCENARIOS:  # round-3 cap, arms a/b/d/e
            for a in ["variant-a", "variant-b", "variant-d", "variant-e"]:
                write_trial(trials_path, "r3_%d" % i, a, s, True, 100000, block="r3-%s-1" % s)
                i += 1

        # Sanity: all three rounds are indeed closed while b/c are still live.
        for cmd in ("next", "next2", "next3"):
            p = run_bandit(cmd, skills_root, scenarios_root, trials_path, seed=1)
            assert p.stdout.strip() == "STOP cap-reached", (cmd, p.stdout)

        # Retire b (variant-c was already "retired" simply by never being
        # a live skills/ dir here -- mirror that too for realism).
        import shutil
        shutil.rmtree(os.path.join(skills_root, "variant-b"))
        shutil.rmtree(os.path.join(skills_root, "variant-c"))

        for cmd in ("next", "next2", "next3"):
            p = run_bandit(cmd, skills_root, scenarios_root, trials_path, seed=1)
            assert p.returncode == 0, (cmd, p.stderr)
            assert p.stdout.strip() == "STOP cap-reached", (cmd, p.stdout)


def main():
    tests = [(name, fn) for name, fn in sorted(globals().items()) if name.startswith("test_") and callable(fn)]
    failures = []
    for name, fn in tests:
        try:
            fn()
            print("PASS: %s" % name)
        except AssertionError as e:
            print("FAIL: %s -- %s" % (name, e))
            failures.append(name)
        except Exception as e:  # noqa: BLE001
            print("ERROR: %s -- %r" % (name, e))
            failures.append(name)
    print()
    if failures:
        print("%d/%d tests FAILED: %s" % (len(failures), len(tests), ", ".join(failures)))
        sys.exit(1)
    print("ALL TESTS PASSED (%d/%d)" % (len(tests), len(tests)))


if __name__ == "__main__":
    main()
