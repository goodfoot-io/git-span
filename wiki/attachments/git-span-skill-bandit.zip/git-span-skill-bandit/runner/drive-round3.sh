#!/bin/bash
# Round-3 driver: 4-arm scenario-matched blocks via bandit.py next3.
set -u
cd /tmp/git-span-skill-test || exit 1

while true; do
  pick=$(python3 runner/bandit.py next3) || { echo "bandit next3 failed"; exit 1; }
  case "$pick" in
    STOP*) echo "BANDIT: $pick"; break ;;
  esac
  read -r variant scenario block <<<"$pick"
  echo "=== $(date -u +%H:%M:%S) round-3 trial: $variant / $scenario / $block ==="
  bash runner/run-trial.sh "$variant" "$scenario" "$block" || echo "!!! trial errored for $variant/$scenario (continuing)"
done

echo
echo "================ ROUND 3 REPORT ================"
python3 runner/bandit.py report3
