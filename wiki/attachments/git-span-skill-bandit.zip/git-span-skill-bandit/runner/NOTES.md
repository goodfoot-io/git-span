# Runner empirical notes

Everything below was determined empirically against `claude 2.1.212` running
in this container, by driving raw `claude -p ... --output-format json`
invocations and inspecting `~/.claude/projects/` and `/tmp/claude-1000/`
before writing `run-trial.sh`. All probe artifacts were deleted after use;
only the findings and (below) smoke-run evidence are kept here.

## 1. `claude --output-format json` is an ARRAY of stream events, not a single object

`claude --help` describes `--output-format json` as "single result", but in
2.1.212 it actually prints a JSON **array** of every stream event (system,
assistant, user/tool_result, `rate_limit_event`, `thinking_tokens`, ...),
ending in one or more `type: "result"` events. `run-trial.sh` / `bandit.py`
never assume a bare object.

- Normal (no subagents) run: array of N events, exactly **one** trailing
  `type: "result"` event. That event has `session_id`, `is_error`,
  `duration_ms`, `result` (text), `subtype` ("success"/...), `num_turns`.
- Run that spawns a subagent while the **parent shell's own** Claude-Code
  env vars (`CLAUDECODE`, `CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS`, etc.) are
  inherited by the nested `claude` process: the nested session behaves like
  an async agent-team member of the *outer* session. Symptom: the array
  contains **two** `type: "result"` events (one per "turn" -- the turn that
  launched the async agent and returned early, then a second turn triggered
  by the completion notification), interleaved with an extra `system init`
  partway through. This is confusing and not representative of a normal
  standalone headless session.
- Same subagent-spawning prompt with those env vars neutralized (see ¶3):
  clean single `type: "result"` event at the very end, `num_turns: 2`
  (blocked synchronously on the subagent inside one turn). This is the
  behavior `run-trial.sh` is built against.

**Parsing rule implemented** (`lib/trial_helper.py extract-result`): parse
the top-level JSON as either a list or a single dict, filter to
`type == "result"`, and take the **last** one. `session_id`, `is_error`,
and `result` text come from that event.

## 2. Project-directory cwd encoding (for locating the transcript)

`~/.claude/projects/<encoded-cwd>/<session_id>.jsonl` is the main
transcript. The encoding is **not** simply "replace `/` with `-`": every
character that is not `[a-zA-Z0-9-]` is replaced with `-`. Confirmed with
three probes:

| abs cwd | encoded dir name |
|---|---|
| `/workspace` | `-workspace` |
| `/tmp/git-span-skill-test/results/envs/_probe_subagent` | `-tmp-git-span-skill-test-results-envs--probe-subagent` (the `_` becomes `-`, stacking with the `/`'s `-` to make a double dash) |
| `/tmp/git-span-skill-test/results/envs/_enc.test_1` | `-tmp-git-span-skill-test-results-envs--enc-test-1` (both `_` and `.` become `-`) |

Implemented in `lib/trial_helper.py:encode_cwd` as
`re.sub(r"[^a-zA-Z0-9-]", "-", abs_path)`. This didn't matter for the actual
trial dirs (`results/envs/t001` etc. are plain alphanumeric, so naive
slash-replacement would have "worked by accident"), but the general rule is
implemented anyway since it's what's actually happening and it's a one-line
regex.

## 3. Env vars to neutralize before invoking a nested `claude`

The outer session (this orchestrating agent) exports (at least):
`CLAUDECODE=1`, `CLAUDE_CODE_ENTRYPOINT=cli`,
`CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS=1`, `CLAUDE_CODE_SESSION_ID=...`,
`CLAUDE_CODE_CHILD_SESSION=1` (when itself a spawned agent),
`CLAUDE_CODE_BRIDGE_SESSION_ID=...`, `CARDS_TRANSCRIPT_PATH=...`,
`CLAUDE_CODE_SSE_PORT=...`, `AI_AGENT=...`, `TMUX=...`,
`CLAUDE_BASH_MAINTAIN_PROJECT_WORKING_DIR=1`, `CLAUDE_EFFORT=...`,
`CLAUDE_CODE_MAX_OUTPUT_TOKENS=...`, `CLAUDE_CODE_NO_FLICKER=1`,
`CLAUDE_CODE_EXECPATH=...`.

Empirically, leaving `CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS=1` (plus the
session-id vars) set for the nested `claude -p` call is what caused the
double-turn/double-result behavior in ¶1 when the trial's own skill spawns a
subagent. Without a subagent in play it didn't visibly break anything in a
handful of runs, but there's no upside to leaving it set, and cheap
insurance against a genuinely nested/confused session is worth it. `claude`
started with these unset behaves as a plain standalone session either way
(same subagent-transcript layout, ¶4) -- so `run-trial.sh` always
neutralizes the full list via `env -u ...` before every invocation. See the
`NEUTRALIZE_VARS` array in `run-trial.sh`.

Nothing else was needed -- no `--add-dir`, no special settings file. Plain
`claude -p "<prompt>" --model haiku --output-format json
--dangerously-skip-permissions` from inside the fresh env dir, wrapped in
`timeout 600`, is sufficient.

## 4. Subagent (Task/Agent tool) transcript layout

Confirmed by running (in an isolated fixture git repo) a prompt that uses
the Task tool with `subagent_type: general-purpose`, both with and without
the env vars from ¶3 neutralized -- same layout in both cases:

```
~/.claude/projects/<encoded-cwd>/<session_id>.jsonl                      <- main transcript
~/.claude/projects/<encoded-cwd>/<session_id>/subagents/
    agent-<agentId>.jsonl                                                <- one file per spawned subagent
    agent-<agentId>.meta.json                                            <- {"agentType","description","toolUseId","spawnDepth"} -- small, NOT counted
```

There's also an ephemeral duplicate under
`/tmp/claude-<uid>/<encoded-cwd>/<session_id>/tasks/<agentId>.output` --
byte-identical to the durable copy above -- which is scratch/cache state,
not the transcript of record; `run-trial.sh` ignores it and reads only from
`~/.claude/projects/`.

`agentId` is a distinct hex id per spawned subagent (unrelated to
`toolUseId`); `spawnDepth` in the meta file suggests nested (subagent
spawning its own subagent) is possible, but in every case observed the
nested file still landed flat inside the **top-level session's**
`subagents/` directory, not inside a nested subagent-of-a-subagent
directory. `lib/trial_helper.py:measure-transcript` still walks
`subagents/` recursively (`os.walk`) rather than assuming flat, so nothing
would be silently dropped if a deeper nesting ever occurs.

**`total_chars` = main transcript byte size + byte size of every
`subagents/*.jsonl` file** (not the `.meta.json` sidecars, not the
`/tmp/claude-*/.../tasks/*.output` scratch copies).

## 5. claude CLI quirks on 2.1.212 relevant to this harness

- `--output-format json` result event's `duration_ms` reflects only the
  last "turn" in the multi-turn-array case (¶1), not full wall time, so
  `run-trial.sh` measures its own wall-clock `duration_s` around the whole
  invocation instead of trusting the JSON's duration field.
- `is_error` and `session_id` are reliably present on every `result` event
  observed, including the timeout case is not applicable (a `timeout`-killed
  process produces no output at all / partial unparseable JSON --
  `run-trial.sh` treats that as `notes="timeout"`, `pass=false`, no
  transcript measurement attempted).
- No permission prompts were seen with `--dangerously-skip-permissions`
  across any smoke run (direct file writes, git commands, and Task-tool
  subagent spawns all went through silently), so no `--allowedTools` tuning
  was needed for the smoke fixtures.

## 6. Smoke-run evidence (all since deleted from `results/`)

Ran through the **actual** `runner/run-trial.sh` (not just raw probes),
using `SKILLS_ROOT=runner SCENARIOS_ROOT=runner` to point at the throwaway
`runner/smoke-skill*` / `runner/smoke-scenario` fixtures instead of the real
`skills/` / `envs/scenarios/` trees:

| trial | variant | outcome | session_id | main_chars | subagent_chars | total_chars | duration_s | notes |
|---|---|---|---|---|---|---|---|---|
| t001 | smoke-skill | pass | a4134efa-f5b8-4d3a-9777-27b357bd0c21 | 28426 | 0 | 28426 | 9 | (none) |
| t002 | smoke-skill-subagent (spawns 1 Task-tool subagent) | pass | e2c342dc-35b4-42bb-be7f-7e14de0f3e94 | 35332 | 17856 | 53188 | 17 | (none) |
| t003 | smoke-skill-noop (deliberately does nothing) | **fail** | a1794f25-7da0-478b-a48c-68d68b747743 | 21401 | 0 | 21401 | 8 | (none -- grade.sh correctly failed, reward forced to 0) |
| t004, t005 | smoke-skill, launched **concurrently** (`&` + `wait`) | pass, pass | afa86a22-..., 1cccc57a-... | 29085, 29447 | 0, 0 | 29085, 29447 | 10, 9 | trial ids allocated without collision (t004/t005), both records appended to trials.jsonl without corruption |

For t002, directly diffed the measured sizes against the files on disk:
`~/.claude/projects/-tmp-git-span-skill-test-results-envs-t002/e2c342dc-....jsonl`
was exactly 35332 bytes and
`.../e2c342dc-.../subagents/agent-af83206cbc3d8caa2.jsonl` was exactly
17856 bytes -- matches the recorded `main_chars`/`subagent_chars` exactly.

Also confirmed the missing-variant fail-loud path
(`run-trial.sh does-not-exist smoke-scenario` -> exit 1, clear stderr
message, **no** trial record written) and re-ran the id-allocator directly
(`trial_helper.py next-trial-dir`) as a standalone sanity check before
wiring it into the full script.

All five smoke trial lines were removed from `results/trials.jsonl`
(the file was deleted entirely, which satisfies "empty or absent") and all
five `results/envs/t00{1..5}` directories were deleted. `runner/smoke-skill/`,
`runner/smoke-skill-subagent/`, `runner/smoke-skill-noop/`, and
`runner/smoke-scenario/` are kept as permanent throwaway fixtures for future
regression-testing of `run-trial.sh` itself; they are excluded from
`bandit.py`'s arm discovery because their names start with `smoke`.

## 7. `bandit.py` design notes not fully spelled out in CONTRACT.md

- **Seed-phase / scenario tiebreak mechanism**: "least-used first,
  alphabetical tiebreak" is implemented as the single rule for both (a) the
  seed-phase arm choice and (b) scenario choice. Applied repeatedly, it
  produces exact round-robin cycling (verified in
  `tests/test_bandit.py::test_next_seed_phase_end_to_end`), so it
  simultaneously satisfies "force 3 per arm, round-robin" and "scenario
  round-robin, least-used first, deterministic tiebreak" without needing
  two different code paths.
- **Phase-1 cap counting**: `total_trials` for the 15-trial cap only counts
  trials whose `variant` matches a *currently discovered* arm. Stale/smoke
  rows left in `trials.jsonl` (e.g. from a previous debugging session) do
  not count against the cap or the seed phase. This is a deliberate
  deviation from a literal "count every line" reading, justified because
  otherwise leftover smoke-test rows (or an arm later removed from `skills/`)
  would silently eat into the real budget.
- **`FLOOR_VAR = 0.05`** (log-chars variance floor): CONTRACT specifies
  "known-variance approx using sample variance with floor" but not the
  floor's value. With 0 or 1 successes the sample variance is
  undefined/zero, and even with a handful of near-identical trials (see the
  smoke evidence above -- `main_chars` varying by only ~2% across three
  otherwise-identical runs) the raw sample variance can be near zero, which
  would make the posterior predictive absurdly overconfident. 0.05 (log
  space) is a mild, explicitly tunable regularizer, not fit to any data.
- **"Top-2 arms" for Fisher/Mann-Whitney in `report`**: defined as the two
  arms with the highest `P(arm is best)` from the 20k-draw posterior (i.e.
  the actual leading pair worth distinguishing), tie-broken alphabetically.
  CONTRACT doesn't define "top-2" precisely; ranking by the same posterior
  the rest of the report already computes seemed most internally consistent
  (vs., e.g., ranking by raw trial count or raw success rate).

## 8. Incident: runner artifacts dirtied the env working tree (found in real trial t001)

**Root cause.** The original `run-trial.sh` wrote every runner-owned
artifact -- `.setup.log`, `.task-prompt.md`, `.claude-output.json`,
`.claude-stderr.log`, `.grade-output.log`, `.trial-record.json` -- directly
inside `env_dir`, i.e. inside the fixture git repo the agent works in and
the grader inspects. 3 of the 4 phase-1 scenarios grade on "working tree
clean" as one of their checks. Real trial t001 (`variant-a` /
`declare-coupling`) is a clean, fully-worked example of the bug: the agent
did everything right (declared the span, correct anchors, correct kebab-case
name, non-trivial `why`, `git span stale` clean) and the grader's *only*
failure was:
```
FAIL: working tree not clean:
?? .claude-output.json
?? .claude-stderr.log
?? .grade-output.log
?? .setup.log
?? .task-prompt.md
```
i.e. the runner's own bookkeeping files, not anything the agent left
behind. This would have systematically failed every trial on every
scenario that checks tree cleanliness, silently corrupting phase-1 data
(rewarding variants that happen to have agents run `git add -A`/`git clean`
defensively, punishing equally-good variants that don't) -- not a narrow
cosmetic issue.

**Fix.** `run-trial.sh` now allocates a `meta_dir` (`results/envs/<trial-id>.meta/`)
as a **sibling** of `env_dir`, created immediately after the trial id is
allocated, and every runner-owned artifact is written there instead:
`setup.log`, `task-prompt.md`, `claude-output.json`, `claude-stderr.log`,
`grade-output.log`, `trial-record.json`. `env_dir` now only ever receives
whatever `setup.sh` and the agent itself put there. The rendered task
prompt was already passed to `claude -p` as a CLI argument (never read back
from disk by anything) -- writing it to a file at all was only ever for
human readability, so relocating it was a pure path change, no behavior
change.

**Verified no other runner-induced pollution.** Diffed the full file tree
(excluding `.git/` internals) of both t001 and the orphaned t002 against
what each scenario's `setup.sh` is expected to produce, before deleting
either: the *only* extra entries were the 6 files above. No stray
`.claude/` local-settings directory, no cache files, no leftover env-var
artifacts (`GIT_SPAN_CARGO_TARGET_ROOT` etc. are irrelevant here -- these
fixture repos don't build git-span, they only call the already-built
`git-span` binary). Confirmed post-fix with `git status --porcelain` inside
a fresh real trial's `env_dir`: only the agent's own new/changed files show
up (see re-verification below).

**Trial-id allocation choice.** `trial_helper.py next-trial-dir`'s allocator
scans `results/envs/` for directory names matching `^t(\d+)$` (in addition
to scanning `trials.jsonl`). Renaming an invalidated trial's directory to
`<id>.invalid` (and its artifacts to `<id>.invalid.meta`) removes it from
that regex's matches with zero code changes, so the id becomes available
for reuse automatically. **Chosen policy: invalidated/excluded trial ids
are reused**, not skipped -- t001 (the original dirty-tree failure) was
archived as `results/envs/t001.invalid` + `t001.invalid.meta`, freeing
`t001` for the very next `run-trial.sh` call, sequential numbering
otherwise. (An alternative -- always burn the id and continue at `t003` --
would also have worked with the same allocator; reuse was picked so gaps in
`results/envs/` don't accumulate every time a trial needs invalidating.)

**Cleanup performed:**
- `results/envs/t001` (dirty-tree failure) archived to `t001.invalid` +
  `t001.invalid.meta`, working tree confirmed pristine after separating out
  the 6 runner files. Its `trials.jsonl` line moved to
  `results/invalid-trials.jsonl` with
  `"invalid_reason": "infrastructure: runner artifacts dirtied working tree; agent work was substantively correct"`.
- `results/envs/t002` (`variant-b` / `inspect-report`, started by the
  phase-1 driver, never finished -- no `grade-output.log`, never appended
  to `trials.jsonl`) deleted outright as an orphan; nothing to invalidate
  since it was never recorded.
- `results/trials.jsonl` left empty (later deleted entirely -- "absent" is
  the accepted terminal state) for the restarted driver.

**Post-fix re-verification** (real variant + real scenario, through the
now-fixed runner): `bash run-trial.sh variant-a declare-coupling` ->
`pass: true`, `grade_output` starts with `PASS: working tree clean`, full
scenario satisfied (span declared, anchors, name grammar, why, `git span
stale` clean). Directly confirmed via `git status --porcelain` inside the
resulting `env_dir`: no output at all (agent committed everything). Per
instruction, this run's line was appended to `trials.jsonl` then
immediately moved to `results/invalid-trials.jsonl` with
`"invalid_reason": "post-fix smoke, excluded from phase-1"` so it can't bias
phase-1 stats; its env dir was renamed `t001.postfix-smoke` /
`t001.postfix-smoke.meta` (same reuse-friendly archival pattern as above),
re-freeing `t001` for the driver's real first trial. `results/trials.jsonl`
was confirmed empty/absent again afterward, and `bandit.py`'s 19-test suite
was re-run clean (this fix touches only `run-trial.sh`'s file layout, not
`bandit.py`, but re-ran it anyway as cheap insurance).

## 9. Round 2: scenario-matched complete blocks (`bandit.py next2`/`report2`)

**Why.** CONTRACT's Round 2 section records two phase-1 methodology
problems: (a) a ceiling effect -- confirmed directly against the real
completed phase-1 run, `bandit.py report` now shows 15/15 passes across all
three arms, so success rate carried zero discriminating signal; (b) a
scenario-mix confound -- phase-1's Thompson arm choice and independent
scenario round-robin could (and, looking at the real `trials.jsonl`, did)
give different arms different scenario diets, biasing raw/pooled
`total_chars` comparisons since scenarios differ hugely in how much
transcript a correct solution takes. Round 2 replaces Thompson allocation
with forced scenario-matched complete blocks and replaces pooled chars with
equal-scenario-weighted chars, fixing (b) directly; it does not and cannot
fix (a) -- that requires scenarios with real failure modes, which is why two
new failure-capable scenarios (`triage-mixed-drift`, `consistent-update`)
were added alongside this mechanism.

**`next2` block-sequencing algorithm** (`block_id_for`, `arm_order_for_block`,
`next2_pick` in `bandit.py`): a block is identified by
`"r2-<scenario>-<cycle>"`. The full block sequence is generated on demand,
never precomputed/stored: for a 0-indexed global block counter `b`,
`cycle = b // n_scenarios + 1` and `scenario = scenarios[b % n_scenarios]`
(scenarios always freshly discovered + alphabetically sorted, so this is
stable call-to-call). `next2_pick` scans `b = 0, 1, 2, ...` for the first
block whose recorded arms (from block-tagged trials in `trials.jsonl`) don't
yet cover every discovered arm, and returns that block's earliest
not-yet-run arm in **that block's own rotated order**
(`arm_order_for_block(arms_sorted, b)` rotates the sorted arm list by `b mod
n_arms`, so which arm goes first varies block-to-block as CONTRACT
requires for time-fairness).

This scan-forward-from-zero design is deliberately stateless (no
"current block" pointer stored anywhere) and was chosen specifically so it
self-heals if the scenario set changes mid-round -- which is exactly what
happened during this build: `next2` was implemented and tested against a
4-scenario fixture, and by the time of the real-directory smoke check
env-builder had already landed both new scenarios, so the real
`envs/scenarios/` had all 6. No code path needed adjusting: already-complete
blocks for the original 4 scenarios stay complete regardless of where they
now fall in the freshly-recomputed 6-scenario alphabetical sequence, and the
new scenarios' blocks simply surface as the next incomplete slots found by
the same scan. Verified live: `python3 bandit.py next2` against the real
(now 6-scenario, 3-arm, zero-round-2-trials) directories printed
`variant-a consistent-update r2-consistent-update-1` -- `consistent-update`
sorts before all the phase-1 scenario names alphabetically, so it correctly
becomes cycle 1's first scenario.

**Round-2 cap = 18**, checked by counting trials with a non-empty `"block"`
field (and a recognized arm) BEFORE searching for the next slot, so it can
never be exceeded by one stray call. With the contract's target of 3 arms x
6 scenarios that's exactly one complete grid (18 = 3x6). The cap is a flat
trial count, not "stop after N complete blocks" -- if the arm or scenario
count were ever different from 3x6, `next2` would still stop at exactly 18
trials, which could land mid-block-sequence-cycle (e.g. verified in
`test_next2_full_cycle_matches_expected_blocks_and_stops_at_cap`: with 3
arms and only 4 scenarios, 18 trials = 6 blocks = all 4 scenarios' cycle-1
blocks plus the first 2 scenarios' cycle-2 blocks, an uneven cutoff). This
is intentional -- CONTRACT fixes the cap number, not "always finish whole
cycles" -- but is worth knowing if the scenario count ever isn't a divisor
of 6.

**Phase-1/round-2 isolation, both directions.** CONTRACT says phase-1
trials "stay in trials.jsonl but are excluded from round-2 stats" -- that's
`round2_trials()`'s job (keep only records with a truthy `"block"` field).
The reverse direction isn't spelled out in CONTRACT but is needed for
correctness once both kinds of records coexist in the same file: `next`/
`report` (phase 1) now also filter to records WITHOUT a `"block"` field
(`phase1_trials()`), so a phase-1 `report` run after round-2 trials exist
still reflects phase-1 only, not a mix. This is a pure filter added at the
top of `cmd_next`/`cmd_report`; it's a no-op on any trials.jsonl that
predates the `"block"` field (nothing to filter out), so all of phase-1's
own historical behavior (seed phase, Thompson pick, cap-15, the report
table) is completely unchanged in the recorded-so-far real data -- verified
directly: `bandit.py next`/`report` against the real 15-trial phase-1
history still print `STOP cap-reached` / the same 15/15-pass table as
before this change.

**`run-trial.sh` block-id passthrough**: a new optional 3rd positional arg.
When given, it's forwarded to `lib/build_record.py --block <id>`, which only
adds the `"block"` key to the JSON record when the flag is passed with a
non-empty value -- so phase-1 invocations (2 args, as always) produce
records that genuinely lack the key, not just an empty/null one. No other
part of `run-trial.sh` branches on whether a block id was given.

**`report2` design choices not fully pinned down by CONTRACT:**
- **Per-scenario "winner"**: most successes first, then lower mean
  chars-of-successes (more efficient) as tiebreak, then alphabetical for
  full determinism. Same rationale as phase-1's "top-2 arms" choice
  (§7) -- CONTRACT says "winner per scenario" but not the metric; success
  count first is the obvious primary axis once phase-1's ceiling effect is
  gone and scenarios can actually fail, chars is the natural secondary axis
  CONTRACT already cares about everywhere else.
- **Equal-scenario-weighted posterior**: implemented as
  `sampled_reward_equal_scenario_weight` -- one aggregate Beta
  draw for `p` per arm (pooling successes/failures across all scenarios,
  "as before" per CONTRACT), then ONE posterior-predictive `logc` draw per
  scenario (via the same `draw_logc` helper phase-1 uses, now scenario-
  filtered instead of pooled), averaged with equal weight across scenarios
  regardless of each scenario's actual trial count for that arm. This
  directly targets the phase-1 confound: an arm that happened to draw a
  cheap scenario more often no longer gets an advantage from that alone.
  An arm with zero successes in a given scenario falls back to the same
  prior-only branch `draw_logc` already has for `n=0`.
- **Paired sign test for the leading pair**: CONTRACT specifies a sign test
  across "completed blocks" but not the exact pairing rule. Implemented as:
  for every block id where BOTH of the top-2-by-P(best) arms have a
  recorded trial, compare their `reward` values (already 0-if-failed /
  1-if-chars-else per CONTRACT's existing reward formula) and count wins;
  exact ties are dropped from `n` (standard sign-test practice, not a
  CONTRACT choice). Implemented via direct binomial enumeration
  (`math.comb`), no scipy, hand-verified against the classic n=5-all-wins
  case (p = 2 x C(5,5)/2^5 = 0.0625).
- **`report2`'s "no round-2 trials yet" short-circuit**: if zero
  block-tagged trials exist, `report2` prints one line and returns rather
  than rendering an all-empty stratified table -- there was nothing in
  CONTRACT against this, and an all-`n/a` table for a scenario set that may
  still be growing (per the task, two scenarios were still being authored
  in parallel while this was built) seemed like noise, not signal.

**Tests** (`runner/tests/test_bandit.py`, 31/31 passing, up from 19): added
pure-function coverage for `next2_pick`'s full sequencing behavior (hand-
traced 3-arm/2-scenario/7-call sequence asserting arm completeness per
block, scenario cycling, AND arm-order rotation all at once), a
partial-block resume case, `arm_order_for_block`'s rotation directly,
`stratified_stats`/`scenario_winner`, the sign test (hand-checkable
n=5-all-wins and n=6-at-the-null cases, plus the n=0 nan-safe case), and
`paired_sign_test`'s tie-dropping/unmatched-block-dropping behavior.
Subprocess-level integration coverage: a full 3-arm/4-scenario round-2 run
via repeated `next2` calls (each one's output fed back as a synthetic trial,
exactly as `run-trial.sh` + a driver loop would) asserting the exact block
order and the cap firing at 18; phase-1 noise mixed into the same
`trials.jsonl` provably not perturbing `next2`'s pick; `build_record.py`
called directly to confirm the block-field-absent/present/empty-string
cases; and `report2` both on phase-1-only data (prints the short-circuit
message) and on a mix of phase-1 + round-2 data (confirms phase-1 rows don't
leak into the round-2 stratified table, per-scenario winners are correct,
and the report sections all render).

## 10. Round 3: generalizing next2/report2, and two real bugs arm retirement surfaced

**Generalizing round 2 -> round N.** `next3`/`report3` are round 3's
(4 arms x 6 scenarios, block prefix `r3-`, cap 24) counterparts to
`next2`/`report2`. Rather than copy-paste, the shared machinery was
factored out and parameterized by a `prefix` (block-id prefix, e.g. `"r2"`/
`"r3"`) and a `cap`:
- `block_id_for(prefix, scenario, cycle)` (was hardcoded to `"r2-..."`).
- `next_block_pick(arms, scenarios, this_round_trials, prefix)` (renamed
  from `next2_pick`; same algorithm, prefix now a parameter).
- `cmd_next_round(prefix, cap)`, with `cmd_next2`/`cmd_next3` as one-line
  wrappers (`"r2"`/`ROUND2_CAP` and `"r3"`/`ROUND3_CAP`).
- `cmd_report_round(prefix, cap, round_num)`, with `cmd_report2`/
  `cmd_report3` as one-line wrappers. Every print statement in the shared
  body is parameterized by `round_num` (and `cap`) rather than hardcoding
  "2"/"18" -- verified this reproduces report2's original wording
  byte-for-byte for `round_num=2` (only the substituted number changes;
  the surrounding sentences are untouched), and confirmed against the real,
  already-completed 18-trial round-2 dataset that `report2`'s output still
  renders correctly end-to-end post-refactor.
- `is_round_trial(t, prefix)` / `round_trials(trials, arms, prefix)`
  generalize the old `is_round2_trial`/`round2_trials` (which merely checked
  "does this trial have any block field" -- no longer sufficient once two
  rounds' records share one prefix scheme). The prefix check is an exact
  `block.startswith(prefix + "-")`, which stays unambiguous even for a
  scenario literally named e.g. `"r3-thing"` (tested directly:
  `test_round_trials_r2_and_r3_do_not_leak_into_each_other`), since the
  prefix always occupies the fixed leading `"r2-"`/`"r3-"` position in
  `"<prefix>-<scenario>-<cycle>"`.
- `main()`'s command dispatch became a small dict (`COMMANDS`) instead of
  an `if/else`, purely to avoid a 6-way manual branch as more rounds
  accumulate.

**Retirement:** `variant-c` was moved from `skills/` to `skills-retired/`
as part of round-3 prep. `discover_arms()` only ever lists the directory it
is given (`SKILLS_ROOT`, default `skills/`), so a sibling `skills-retired/`
was already invisible to it with zero code changes -- confirmed directly
(`test_discover_arms_ignores_sibling_retired_dir`) and against the real
directory layout (`skills/` now lists only `variant-a`/`variant-b`;
`skills-retired/variant-c` is never scanned).

**Two real allocation/reporting bugs this retirement surfaced** (found by
re-running `bandit.py` against the real, now-post-retirement state --
not by the fixture tests alone, which is exactly why the "verify against
real data" step matters):

1. **`report`/`report2` were silently dropping the retired arm's historical
   rows, and mis-stating the round's own design.** Both commands compute
   their `arms` list via `discover_arms()` (live only) and then filter
   `trials.jsonl` to `variant in arms` before doing anything else -- so the
   instant `variant-c` left `skills/`, its 7 real phase-1 trials and 6 real
   round-2 trials vanished from the tables, AND `report2`'s significance
   statement recomputed `cap // len(arms)` with `len(arms) == 2` instead of
   the actual `3` arms round 2 was run with, printing "9 complete 2-arm
   blocks" -- describing a round-2 design that never happened, when the
   real one was "6 complete 3-arm blocks". Fix: added
   `historical_arms(trials_for_report, live_arms)` (union of live arms and
   whatever non-smoke variant actually appears in the relevant, already
   phase/round-filtered trial set) plus retired-arm-inclusive trial filters
   `phase1_trials_all(trials)` / `round_trials_all(trials, prefix)` (same
   as `phase1_trials`/`round_trials` but without the live-arm restriction,
   smoke-fixture variants still excluded). `cmd_report`/`cmd_report_round`
   now build their `arms`/`trials` from these instead of `discover_arms()`
   alone. Verified against real data before/after: `report`/`report2` now
   show all 3 historical arms again, and the significance statement
   correctly says "6 complete 3-arm blocks".
2. **`next`/`next2` were about to silently reopen already-closed rounds.**
   Both commands' cap checks were computed from the SAME live-arm-restricted
   trial list used for arm selection -- so once `variant-c` (with its 7
   phase-1 / 6 round-2 trials) left the live arm set, `len(trials)` for the
   cap check dropped from 15 to 8 (phase-1) and from 18 to 12 (round 2),
   both now under their caps, and a real invocation right after the
   retirement printed a brand-new `variant-b` phase-1 pick and a fresh
   round-2 pick instead of `STOP cap-reached` for BOTH already-completed
   rounds. A trial already spent is spent regardless of whether its arm is
   later retired -- a cap must never un-trip. Fix: the cap check in
   `cmd_next`/`cmd_next_round` now counts `phase1_trials_all(all_trials)` /
   `round_trials_all(all_trials, prefix)` (retired-arm-inclusive, smoke
   still excluded), while the *arm-selection* logic (seed phase/Thompson
   pick, block completeness/rotation) still correctly uses only
   live-arm-restricted trials (`phase1_trials`/`round_trials` with
   `arms=discover_arms()`), since a retired arm must never be handed a new
   trial and its own historical count is irrelevant to balancing the arms
   still running. Phase-1's scenario rotation (`scenario_counts`) was
   already arm-agnostic by design (CONTRACT: "round-robin over scenarios
   independent of arm choice") so it, too, now draws from
   `phase1_trials_all` -- consistent with, not a change to, its original
   semantics. Verified against real data: `next`/`next2` both now correctly
   print `STOP cap-reached` post-retirement, matching their pre-retirement
   state exactly.

Neither bug was in the round-3 task list -- both were caught only because
every change in this build gets smoke-verified against the *real*,
currently-evolving `skills/`/`envs/scenarios/`/`trials.jsonl` state (per the
existing verification habit from §6/§8/§9), not just fixture data. Tests
added: `test_next_cap_stays_closed_after_arm_retirement`,
`test_next2_cap_stays_closed_after_arm_retirement` (asserts the cap's
STOP/no-STOP verdict is identical before and after retiring an arm),
`test_cmd_next_cap_counts_retired_arm_trials_directly` (unit-level, on the
`_all` vs. restricted helpers directly), `test_historical_arms_includes_retired_variant`,
and `test_report_shows_retired_arm_and_report2_arithmetic_reflects_original_arm_count`
(asserts `"3-arm blocks"` appears, not `"2-arm blocks"`, after retiring one
of the 3 arms that actually ran a completed round-2 block).

**Tests**: 42/42 passing (up from 37 after round 2), covering everything
above plus round 3's own block sequencing (`test_next3_full_cycle_4arms_6scenarios_matches_expected_blocks_and_stops_at_cap_24`,
hand-tracing a 4-arm/6-scenario/24-trial run to the exact expected block
order and first-arm-per-block rotation) and r2/r3 mutual isolation
(`test_next3_and_next2_are_mutually_blind_to_each_others_blocks`,
`test_report3_filters_to_r3_only_ignoring_phase1_and_r2`).

## 11. Round 4 ("confirmation round"): fixed scenario subset + pooled r3+r4 analysis

Real state at the start of this round: `variant-b` retired too (joining
`variant-c` in `skills-retired/`), so live arms are now `variant-a`,
`variant-d`, `variant-e`. Round 3 had actually run with 4 arms
(`variant-a`, `variant-b`, `variant-d`, `variant-e` -- confirmed from the
real `trials.jsonl`: 6 r3- trials each, 24 total, matching `ROUND3_CAP`)
before `variant-b`'s retirement, so this is a genuine **second** retirement
exercising the §10 fixes, not a repeat of the first.

**Re-verified §10's two fixes against this second retirement, live, before
writing any round-4 code** (exactly as asked): `next`/`next2`/`next3` all
still correctly print `STOP cap-reached` with `variant-b` retired (both
already-closed rounds' caps count ALL historical trials, not just
currently-live arms' -- Bug B stays fixed under repeated retirement), and
`report`/`report3` still show `variant-b`'s historical rows with correct
arm-count arithmetic (Bug A stays fixed too). Confirmed with the actual
`bandit.py` CLI against the real `skills/`/`trials.jsonl`, not just by
re-reading the code.

**`next4`/`report4` generalize the round-2+ machinery one step further**:
round 4 is restricted to a **fixed, hardcoded** 3-scenario "discriminating
set" (`ROUND4_SCENARIOS = ["declare-coupling", "reconcile-drift",
"triage-mixed-drift"]`), not the dynamically-discovered full set round 2/3
use. To support this without copy-pasting `cmd_next_round`/
`cmd_report_round`, both now take `scenarios` as a parameter instead of
calling `discover_scenarios()` internally:
- `cmd_next2`/`cmd_next3` pass `discover_scenarios(scenarios_root())`
  (unchanged behavior).
- `cmd_next4` passes `round4_scenarios()`, a small validator that checks
  each of the 3 hardcoded names actually exists as a real scenario dir
  under `envs/scenarios/` and **fails loudly** (fail-closed, per
  CLAUDE.md) if one is missing/misconfigured, rather than silently
  proceeding with a broken scenario reference. `ROUND4_SCENARIOS` is
  already listed in alphabetical order (`declare-coupling` <
  `reconcile-drift` < `triage-mixed-drift`), which is also the intended
  block-sequence order CONTRACT describes ("declare, reconcile, triage,
  then declare again for cycle 2") -- `round4_scenarios()` still
  `sorted()`s it defensively so that stays true even if the constant is
  ever reordered.
- Same pattern for `cmd_report2`/`cmd_report3`/`cmd_report4`.

`ROUND4_CAP = 12` (4 complete 3-arm blocks over the 3 fixed scenarios:
declare-coupling, reconcile-drift, triage-mixed-drift, declare-coupling
again for cycle 2) -- verified via a full 12-call `next4` simulation that
the block sequence is exactly that and the 13th call prints
`STOP cap-reached`. r2-/r3--tagged trials for the very same arms/scenarios,
seeded in the same fixture, provably don't consume or influence r4
allocation at all (same exact-prefix isolation as r2/r3, extended to a
third prefix -- no new logic needed since `is_round_trial`/`round_trials`
were already prefix-generic).

**`report4`'s pooled section is new, additive logic** (not something
`cmd_report_round` needed to know about): `cmd_report4()` first calls the
normal shared `cmd_report_round("r4", ROUND4_CAP, 4, round4_scenarios())`
(prints the exact same kind of stratified-by-scenario report as
report2/report3, just restricted to the 3 round-4 scenarios and r4- blocks
only), then appends a second, separate section pooling **every** completed
block from **both** r3- and r4- prefixes (not restricted to the 3 round-4
scenarios -- CONTRACT says "pooling ALL completed blocks from r3- and r4-",
and round 3 ran the full 6-scenario set, so the pooled analysis is
deliberately broader than the stratified table above it) for two
hardcoded "confirmation pairs" (`ROUND4_POOLED_PAIRS = [("variant-e",
"variant-d"), ("variant-e", "variant-a")]`, per CONTRACT). Pooling across
r3/r4 is sound here specifically because `paired_sign_test_detailed`
groups purely by `block_id`/`variant`/`reward` -- it has no idea (and
doesn't need to know) which round a block came from, and CONTRACT confirms
"the design and graders are identical across these rounds," so an
`r3-declare-coupling-1` trial and an `r4-declare-coupling-1` trial are
equally valid independent paired-comparison units for the same pair of
arms.

Extracted `paired_sign_test_detailed(trials, a1, a2) -> (wins_a1, wins_a2,
ties, p)` out of the old `paired_sign_test` (which only ever returned
`(k, n, p)` with `n` = non-tied comparisons, silently discarding the tie
count) so the win/loss/tie breakdown CONTRACT wants for the pooled section
is available without duplicating the per-block grouping logic; `report2`/
`report3` still call `paired_sign_test`, now a 3-line wrapper over the new
function, so their `(k, n, p)`-shaped printed line is unchanged.

**Verified against real data**: `next4` on the real (3-live-arm,
6-real-scenario) state correctly prints
`variant-a declare-coupling r4-declare-coupling-1` (first block, first
arm, restricted scenario, ignoring the retired arms entirely); `report4`
correctly short-circuits its own stratified section (`"No round-4 trials
recorded yet"`, since no r4- data exists yet) while still printing the
pooled section against the real 24 r3- trials, e.g. `variant-e wins: 5,
variant-d wins: 1, ties: 0, p = 0.2188` for the real historical data --
this pooled section works even with zero round-4 trials recorded, since it
only needs r3-/r4- data to exist in combination, not r4- data specifically.

**Tests**: 47/47 passing (up from 42). New coverage: `next4`'s scenario
restriction + exact 12-trial/4-block cap sequence + r2/r3-trial blindness
(`test_next4_restricted_to_fixed_scenarios_cap12_and_ignores_r2_r3`);
`next4`'s fail-loud path when a required scenario dir is missing
(`test_next4_fails_loudly_if_a_round4_scenario_dir_is_missing`); `report4`'s
pooling arithmetic cross-checked both against the printed text AND a direct
call to `paired_sign_test_detailed` on the same pooled trial list
(`test_report4_pools_r3_and_r4_for_confirmation_pairs` -- this test's first
draft had a hand-calculation bug of its own, a hidden reward tie between
two arms in one fixture block, caught immediately by the test itself
failing against the real implementation rather than the implementation
being bent to match a wrong expectation); `paired_sign_test_detailed` vs.
`paired_sign_test` equivalence
(`test_paired_sign_test_detailed_matches_paired_sign_test`); and a second-
retirement regression, `test_next_next2_next3_all_stay_stopped_after_second_retirement`,
which builds the real production history shape (phase-1 + round-2 on
{a,b,c}, round-3 on {a,b,d,e}) then retires b (and c) and asserts all three
already-closed rounds' `next`/`next2`/`next3` stay at `STOP cap-reached`
across the retirement.
