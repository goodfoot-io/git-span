#!/bin/bash
# Round-4 confirmation driver: 3 arms x discriminating scenarios via bandit.py next4.
set -u
cd /tmp/git-span-skill-test || exit 1

while true; do
  pick=$(python3 runner/bandit.py next4) || { echo "bandit next4 failed"; exit 1; }
  case "$pick" in
    STOP*) echo "BANDIT: $pick"; break ;;
  esac
  read -r variant scenario block <<<"$pick"
  echo "=== $(date -u +%H:%M:%S) round-4 trial: $variant / $scenario / $block ==="
  bash runner/run-trial.sh "$variant" "$scenario" "$block" || echo "!!! trial errored for $variant/$scenario (continuing)"
done

echo
echo "================ ROUND 4 REPORT ================"
python3 runner/bandit.py report4
