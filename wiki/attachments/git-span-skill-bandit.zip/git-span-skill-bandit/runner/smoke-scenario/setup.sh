#!/usr/bin/env bash
# bash setup.sh <dest-dir>
# Builds a trivial, deterministic fixture at <dest-dir> for the runner smoke test.
# Idempotent per fresh dest. No network. Exit 0 on success.
set -euo pipefail

dest="${1:?usage: setup.sh <dest-dir>}"
mkdir -p "$dest"
cd "$dest"

git init -q .
git config user.email "smoke@example.com"
git config user.name "Smoke Test"

echo "hello world" > README.md
git add README.md
git commit -q -m "Initial commit"

exit 0
