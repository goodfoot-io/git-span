#!/usr/bin/env bash
# bash grade.sh <env-dir>
# Deterministic terminal-state grader. Exit 0 = pass, nonzero = fail.
# Prints reason lines to stdout. Never inspects transcripts.
set -uo pipefail

env_dir="${1:?usage: grade.sh <env-dir>}"

if [[ ! -f "$env_dir/DONE.txt" ]]; then
  echo "FAIL: DONE.txt not found in $env_dir"
  exit 1
fi

content="$(cat "$env_dir/DONE.txt")"
if [[ "$content" != "ok" ]]; then
  echo "FAIL: DONE.txt content mismatch (got: $content)"
  exit 1
fi

echo "PASS: DONE.txt present with expected content"
exit 0
