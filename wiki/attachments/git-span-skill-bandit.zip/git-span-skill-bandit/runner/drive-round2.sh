#!/bin/bash
# Round-2 driver: scenario-matched complete blocks via bandit.py next2.
set -u
cd /tmp/git-span-skill-test || exit 1

while true; do
  pick=$(python3 runner/bandit.py next2) || { echo "bandit next2 failed"; exit 1; }
  case "$pick" in
    STOP*) echo "BANDIT: $pick"; break ;;
  esac
  read -r variant scenario block <<<"$pick"
  echo "=== $(date -u +%H:%M:%S) round-2 trial: $variant / $scenario / $block ==="
  bash runner/run-trial.sh "$variant" "$scenario" "$block" || echo "!!! trial errored for $variant/$scenario (continuing)"
done

echo
echo "================ ROUND 2 REPORT ================"
python3 runner/bandit.py report2
