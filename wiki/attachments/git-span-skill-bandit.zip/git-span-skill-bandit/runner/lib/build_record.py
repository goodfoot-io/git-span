#!/usr/bin/env python3
"""build_record.py -- assemble one CONTRACT-schema trial record as JSON.

All free-text fields are read from files or plain argv (never interpolated
into shell/heredoc source), so arbitrary quotes/newlines in grade output
can't corrupt the JSON.
"""
import argparse
import json


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--out", required=True)
    p.add_argument("--trial-id", required=True)
    p.add_argument("--ts", required=True)
    p.add_argument("--variant", required=True)
    p.add_argument("--scenario", required=True)
    p.add_argument("--session-id", default="")
    p.add_argument("--env-dir", required=True)
    p.add_argument("--pass", dest="pass_", required=True, choices=["true", "false"])
    p.add_argument("--grade-output-file", required=True)
    p.add_argument("--main-chars", type=int, required=True)
    p.add_argument("--subagent-chars", type=int, required=True)
    p.add_argument("--total-chars", type=int, required=True)
    p.add_argument("--reward", type=float, required=True)
    p.add_argument("--duration-s", type=int, required=True)
    p.add_argument("--notes", default="")
    p.add_argument(
        "--block", default=None,
        help='Round-2 block id (e.g. "r2-declare-coupling-1"). Omit entirely '
             'for phase-1 trials -- the "block" key is only added to the '
             "record when this flag is passed with a non-empty value, so "
             "phase-1 records genuinely lack the field (not just falsy).",
    )
    args = p.parse_args()

    with open(args.grade_output_file) as f:
        grade_output = f.read()

    record = {
        "trial_id": args.trial_id,
        "ts": args.ts,
        "variant": args.variant,
        "scenario": args.scenario,
        "session_id": args.session_id,
        "env_dir": args.env_dir,
        "pass": args.pass_ == "true",
        "grade_output": grade_output,
        "main_chars": args.main_chars,
        "subagent_chars": args.subagent_chars,
        "total_chars": args.total_chars,
        "reward": args.reward,
        "duration_s": args.duration_s,
        "notes": args.notes,
    }
    if args.block:
        record["block"] = args.block
    with open(args.out, "w") as f:
        json.dump(record, f)


if __name__ == "__main__":
    main()
