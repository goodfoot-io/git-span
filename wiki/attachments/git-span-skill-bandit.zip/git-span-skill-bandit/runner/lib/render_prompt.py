#!/usr/bin/env python3
"""render_prompt.py <task-prompt.md> <skill-path-abs> <dest>

Substitutes the literal placeholder {{SKILL_PATH}} in the scenario's
task-prompt.md with the absolute path to the variant's SKILL.md, writing the
result to <dest>.
"""
import sys


def main():
    src, skill_path, dest = sys.argv[1:4]
    with open(src) as f:
        text = f.read()
    text = text.replace("{{SKILL_PATH}}", skill_path)
    with open(dest, "w") as f:
        f.write(text)


if __name__ == "__main__":
    main()
