#!/usr/bin/env python3
"""Helper utilities for run-trial.sh. All JSON handling lives here so the
shell script never has to do fragile string-quoting of JSON.

Subcommands:
  encode-cwd <abs-path>
      Print the ~/.claude/projects/<...> directory-name encoding of an
      absolute cwd path. Empirically determined (see runner/NOTES.md):
      every character that is not [a-zA-Z0-9-] is replaced with '-'.

  next-trial-dir <results-dir>
      Atomically allocate the next trial id (tNNN, scanning both
      trials.jsonl and any existing results/envs/t* dirs so a half-written
      trial can't be reused) and mkdir results/envs/<id>. Prints the id.

  extract-result <claude-output-json-file>
      Parse the (possibly multi-event-array) output of
      `claude -p ... --output-format json` and print a single-line JSON
      object: {"found": bool, "session_id": str|null, "is_error": bool|null,
      "result_text": str|null, "num_result_events": int, "error": str|null}
      Picks the LAST event of type "result" (there can be more than one --
      see NOTES.md).

  measure-transcript <projects-root> <abs-cwd> <session-id>
      Compute transcript sizes for one trial. Prints a single-line JSON
      object: {"main_path", "main_chars", "main_found", "subagent_chars",
      "subagent_files": [...], "total_chars"}.

  append-trial <trials-jsonl-path> <record-json-file>
      Append one JSON record (read from a file, must already be a single
      valid JSON object) to trials.jsonl under an exclusive flock, one line,
      newline-terminated. Prints the exact line it wrote.
"""
import fcntl
import glob
import json
import os
import re
import sys


def encode_cwd(abs_path):
    return re.sub(r"[^a-zA-Z0-9-]", "-", abs_path)


def cmd_encode_cwd(args):
    print(encode_cwd(args[0]))


def cmd_next_trial_dir(args):
    (results_dir,) = args
    envs_dir = os.path.join(results_dir, "envs")
    trials_path = os.path.join(results_dir, "trials.jsonl")
    os.makedirs(envs_dir, exist_ok=True)
    lock_path = os.path.join(results_dir, ".trials.lock")
    with open(lock_path, "a+") as lockf:
        fcntl.flock(lockf, fcntl.LOCK_EX)
        try:
            max_n = 0
            if os.path.exists(trials_path):
                with open(trials_path) as f:
                    for line in f:
                        line = line.strip()
                        if not line:
                            continue
                        try:
                            rec = json.loads(line)
                        except json.JSONDecodeError:
                            continue
                        m = re.match(r"^t(\d+)$", str(rec.get("trial_id", "")))
                        if m:
                            max_n = max(max_n, int(m.group(1)))
            for name in os.listdir(envs_dir) if os.path.isdir(envs_dir) else []:
                m = re.match(r"^t(\d+)$", name)
                if m:
                    max_n = max(max_n, int(m.group(1)))
            # Find the first free tNNN dir starting just above the max seen.
            n = max_n + 1
            while True:
                trial_id = "t%03d" % n
                env_dir = os.path.join(envs_dir, trial_id)
                try:
                    os.mkdir(env_dir)
                    break
                except FileExistsError:
                    n += 1
            print(trial_id)
        finally:
            fcntl.flock(lockf, fcntl.LOCK_UN)


def _all_events(data):
    if isinstance(data, list):
        return data
    if isinstance(data, dict):
        return [data]
    return []


def cmd_extract_result(args):
    (path,) = args
    out = {
        "found": False,
        "session_id": None,
        "is_error": None,
        "result_text": None,
        "num_result_events": 0,
        "error": None,
    }
    try:
        with open(path) as f:
            raw = f.read()
        data = json.loads(raw)
    except Exception as e:  # noqa: BLE001 - report any parse failure verbatim
        out["error"] = "parse-failed: %s" % e
        print(json.dumps(out))
        return
    events = _all_events(data)
    results = [e for e in events if isinstance(e, dict) and e.get("type") == "result"]
    out["num_result_events"] = len(results)
    if not results:
        out["error"] = "no result-type event in output"
        print(json.dumps(out))
        return
    last = results[-1]
    out["found"] = True
    out["session_id"] = last.get("session_id")
    out["is_error"] = bool(last.get("is_error"))
    out["result_text"] = last.get("result") if isinstance(last.get("result"), str) else None
    out["subtype"] = last.get("subtype")
    print(json.dumps(out))


def cmd_measure_transcript(args):
    projects_root, abs_cwd, session_id = args
    encoded = encode_cwd(abs_cwd)
    project_dir = os.path.join(projects_root, encoded)
    main_path = os.path.join(project_dir, "%s.jsonl" % session_id)
    session_dir = os.path.join(project_dir, session_id)
    subagents_dir = os.path.join(session_dir, "subagents")

    main_found = os.path.isfile(main_path)
    main_chars = os.path.getsize(main_path) if main_found else 0

    subagent_files = []
    subagent_chars = 0
    if os.path.isdir(subagents_dir):
        # Non-recursive glob is what we've empirically observed (flat
        # agent-<agentId>.jsonl files, even for nested spawns -- agentId is
        # unique per spawn regardless of depth) but walk recursively anyway
        # in case a future version nests further, so nothing is silently
        # dropped.
        for root, _dirs, files in os.walk(subagents_dir):
            for name in files:
                if name.endswith(".jsonl"):
                    p = os.path.join(root, name)
                    subagent_files.append(p)
                    subagent_chars += os.path.getsize(p)

    out = {
        "project_dir": project_dir,
        "main_path": main_path,
        "main_found": main_found,
        "main_chars": main_chars,
        "subagent_files": sorted(subagent_files),
        "subagent_chars": subagent_chars,
        "total_chars": main_chars + subagent_chars,
    }
    print(json.dumps(out))


def cmd_append_trial(args):
    trials_path, record_path = args
    with open(record_path) as f:
        record = json.load(f)  # validates it's a single JSON object
    line = json.dumps(record, sort_keys=False)
    lock_path = trials_path + ".lock"
    os.makedirs(os.path.dirname(trials_path) or ".", exist_ok=True)
    with open(lock_path, "a+") as lockf:
        fcntl.flock(lockf, fcntl.LOCK_EX)
        try:
            with open(trials_path, "a") as f:
                f.write(line + "\n")
        finally:
            fcntl.flock(lockf, fcntl.LOCK_UN)
    print(line)


COMMANDS = {
    "encode-cwd": cmd_encode_cwd,
    "next-trial-dir": cmd_next_trial_dir,
    "extract-result": cmd_extract_result,
    "measure-transcript": cmd_measure_transcript,
    "append-trial": cmd_append_trial,
}


def main():
    if len(sys.argv) < 2 or sys.argv[1] not in COMMANDS:
        sys.stderr.write(
            "usage: trial_helper.py <%s> [args...]\n" % "|".join(COMMANDS)
        )
        sys.exit(2)
    COMMANDS[sys.argv[1]](sys.argv[2:])


if __name__ == "__main__":
    main()
