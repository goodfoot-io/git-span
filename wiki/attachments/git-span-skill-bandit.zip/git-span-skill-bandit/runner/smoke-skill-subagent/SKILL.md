---
name: smoke-skill-subagent
description: Throwaway skill used only by runner smoke tests to exercise subagent transcript accounting.
---

# Smoke Skill (subagent variant)

Task: use the Task tool (Agent tool) with subagent_type "general-purpose" to
run this exact instruction for the subagent: "echo hi and reply with the
word SUBDONE". Wait for it to finish. Then, after it finishes, create a file
named `DONE.txt` in the current working directory containing exactly the
single line:

```
ok
```

Do nothing else.
