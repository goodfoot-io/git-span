# git-span skill bandit — breeding brief (round 3 input)

Method: read `.claude/projects/.../<session>.jsonl` event-by-event for 9 trials (2
scenario-pair comparisons + 1 three-way triage + 2 lean baselines); classified tool
calls into skill-read / fs-explore / git-explore / gitspan-call / raw-span-read /
repo-read / edit / results / thinking / RTK-hook-attachment (`research/analyze.py`).
Fixed per-session overhead (deferred-tools/agent/skill listing) is ~10.5k chars
regardless of variant; each Bash call costs another ~800-930 chars in an RTK
`hook_success` attachment — **every extra tool call has a fixed ~850-char tax before
its own result/thinking cost is counted.** Call count, not just content size, drives
cost.

## 1. t030 (variant-a, reconcile-drift, 156k) vs t028 (variant-b, 92k)

Both sessions solve the identical fixture identically in the end (same final `git span
add` call, same commit). t030 diverges after `git span show` succeeds — it already has
everything needed to act — and instead runs a 6-call investigative detour with no
bearing on the fix:

```
git log --oneline -10
git show 694d12b:.span/ops/retry-behavior-doc-sync.toml   # fails: wrong extension, guessed
ls -la .span/
ls -la .span/ops/
Read .span/ops/retry-behavior-doc-sync                     # raw checksum-bearing span file
git diff 694d12b src/retry.py
```
This window (events 31–61 of 93) is **45,024–54,710 raw chars — 34% of the entire
session and ~70-85% of the a-vs-b gap**, for zero decision-relevant information: the
edit and `git span add` call that follow are byte-identical to what t028 does without
any of this. t028 never touches `git log`/`git show`/raw `.span/` files at all; it goes
`stale → Read doc → Read src → show → Edit → add → stale → status → commit → stale &&
status` — 10 gitspan-relevant calls total vs t030's 18.

**Diagnosis:** nothing in variant-a's SKILL.md *tells* the agent to inspect git history
or raw span-file checksums — this is unprompted curiosity the model indulges once it
notices a "why is this marked changed" question it already has the answer to; variant-b
isn't structurally immune, it simply didn't trigger here. Same skill facts, same
correct final action, wildly different spend from optional detours — a call-count
problem, not a content problem. **Cost driver: a recipe ending in an explicit "you have
enough, stop and act" signal after the confirming read suppresses open-ended
exploration; ending in a plain checklist item ("recheck `stale`") does not.**

## 2. Triage-mixed-drift three-way: t032 (a, 219k, pass) vs t033 (b, 150k, pass) vs t031 (c, 215k, FAIL)

All three correctly read all 6 code/doc files up front and correctly identify the
Moved/Changed/Dead triage. Cost splits on *how much side-investigation happens between
identification and action*:
- **t033 (b, cheapest passing)**: batches history with 2 wide `git log --all
  --full-history -- <path1> <path2> <path3>` calls (one per class: src, docs) instead
  of per-file calls, does exactly 3 `git show <hash>`, never touches `.span/` raw files
  or `ls -la`. 26 gitspan-relevant calls, zero raw-span reads.
- **t032 (a, passing but priciest of the two passes)**: same file reads, then adds `git
  show 63ba5d9 --stat`, `git show a1bfd02:.span` (fails — `.span` is a dir, not a blob
  path), `ls -la .span/notifications/`, three separate `cat .span/notifications/<name>`
  raw-file reads, `cat -n src/dispatch.py`, an extra unscoped `git log --all --
  src/legacy_dispatch.py` repeat. 807 chars of pure `other_bash` (the failed `git show
  a1bfd02:.span` error) plus ~440 chars of fs-explore layered on top of what b needed.
  It still passes because it double-checks with `cat -n` before writing anchors — see
  §3 — but pays ~70k more for the same correctness.
- **t031 (c, FAILED)**: same file reads, same git-log/show pattern as a, *plus* raw
  `.span/` file reads for all three spans (298 chars) — but skips the `cat -n`/`wc -l`
  discipline until *after* it has already reasoned its way to a wrong target line for
  one span. Root cause in §3.

**Driver:** batching git-history calls by target *class* (one call covering all `src/*`
paths, one covering all `docs/*` paths) instead of one call per file roughly halves both
call count and result size for a 3-span triage — a matter of how the recipe phrases
the "check history" step, not which variant's prose is longer.

## 3. t031 failure root cause (variant-c, rate-limit anchor mis-set to L4-4)

Ground truth: `should_throttle` lives at `src/rate_limit.py#L7-L8` (unchanged location);
commit `df1084c` renamed its parameter (`request_count` → `requests_this_minute`) —
that's *why* `stale` reports this anchor Changed. The original anchor `L7-8` already
covers the changed code exactly; the correct fix is the same move t032/t033 both made:
re-run `git span add <name> src/rate_limit.py#L7-L8` unchanged, just refreshing the
checksum.

t031 instead did: `git show a1bfd02:src/rate_limit.py` (the historical blob) → saw the
constant `RATE_LIMIT_PER_MINUTE = 20` at line 4 and the function at 7-8, unchanged from
current — then, despite having *already seen the `df1084c` diff land inside the function
body* two tool calls earlier, talked itself into a new claim: "the coupling is about the
threshold... the actual constant is at line 4," and re-anchored to `L4-4` — the constant,
not the function whose content actually changed. This is a **semantic reinterpretation
of what the span "should" mean, substituted for verifying what the diff actually
touched.** It never re-checked its own conclusion against the diff it had already
printed, and neither variant-c's recipe nor any other variant's gotcha list states a
rule against this class of error — every variant's "re-anchor" instruction says "use
`git span add <name> <new-anchor>`" without saying *the anchor for a Changed
(non-Moved) entry is presumptively the same range unless the symbol itself moved.*

**The discipline that prevents it:** before writing any anchor for a *Changed* (not
Moved) drift, `grep -n <symbol>` the target file for the identifier the span's `why`
text names, confirm the anchor's existing line range already covers that grep hit, and
if it does, re-add the *same* range — do not re-derive a new range from a fresh reading
of "what this coupling is conceptually about." Only Moved drift (or `stale` explicitly
reporting a different path) licenses picking a new range. This is missing from all
three variants and must be a first-class gotcha in the hybrids.

## 4. t017 (variant-b, consistent-update, 189k) vs t016 (variant-a, 107k)

t017 opens with **5 filesystem-discovery calls** (`find *.md/*.yaml/...`, `find` again
with a different extension list, `ls -la`, `find src docs`, `ls -R`) before its first
file `Read` — because variant-b's router bullets are keyed on symptoms
("stale reports drift" / "no span yet") that don't match consistent-update's shape (a
value change the agent itself will cause to drift), so **no section file gets read at
all** — grep of the full transcript shows zero `sections/*.md` reads in t017. The agent
falls back to guessing the repo layout from scratch instead of using `git span list`
first (which t016 runs as its 3rd call and immediately gets the real span name).

Lacking the section's naming/re-anchor guidance, t017 then creates a **duplicate span
under the wrong name** — `git span add retry-limit-doc-sync ...` (missing the `ops/`
prefix the real span `ops/retry-limit-doc-sync` uses, already seen verbatim in a `Read
.span/ops/retry-limit-doc-sync` two calls earlier). It discovers the split via a second
`ls -la .span/`, re-reads both raw span files, `git span delete
ops/retry-limit-doc-sync` (the *correct*-named original) and keeps the wrongly-named
duplicate, justified with a fresh `why -m`. The grader passes this — it never checks
span-name continuity — but it's a real correctness regression the harness doesn't
catch. Net cost: 2 extra `ls -la .span*`, 2 extra raw-span `Read`s, a `delete`, an
extra `why -m`, an extra commit — on top of the 5-call discovery detour.

**Driver: router bullets keyed on drift-already-present phrasing miss a scenario shape
(self-caused future drift) entirely, and the fallback when no bullet matches is silent
non-read + improvisation, not a request for more info.** This is the exact risk
variant-b's design brief flagged ("a vague bullet costs an extra read hop") — realized
here as *worse* than a wrong hop: a skipped hop.

## 5. What "lean" sessions do NOT do (t027 variant-c reanchor, 71.6k; t024 variant-b inspect, 74.2k)

t027: `stale → remove → add → commit → stale-recheck → show` — **6 gitspan calls, zero
file Reads beyond SKILL.md, zero git-log/show, zero raw `.span/` reads** — trusting the
line range `stale` already reported instead of re-deriving it with `wc -l`/`cat -n`
(safe here since the file only moved, lines didn't shift).

t024: `SKILL.md → list → history×5 → Write ANSWERS.md` — answers every question
straight from `git span history` output; never opens a source file, never runs
`stale`, never second-guesses a result. Common to both: no `git log`/`git show`, no
raw `.span/*` reads, no repeat reads, no confirm-then-reconfirm beyond one terminal
recheck. **Lean sessions treat the git-span CLI's own output as ground truth and act
on the first read; expensive ones re-derive that truth from git history or raw files
"to be sure."**

## Cost drivers, generalized

| Driver | Cheap pattern | Expensive pattern |
|---|---|---|
| Trust boundary | Act on `git span stale`/`show`/`history` output directly | Re-verify via `git log`/`git show <hash>`/raw `.span/` reads |
| History calls | One batched `git log -- <all relevant paths>` | One `git log`/`git show` per file/commit |
| Call tax | Every Bash call costs ~850 chars fixed (RTK hook attachment) before its own result | Detour sequences of 5-6 calls compound this invisibly |
| Router fit (b-style) | Symptom bullet matches task shape → 1 extra read, self-contained | No bullet matches → zero section reads, improvisation, naming errors |
| Anchor discipline | Changed (non-Moved): keep existing range, `grep -n <symbol>` to confirm coverage, re-`add` unchanged | Re-derive "what the anchor should cover" from the code's current shape → picks the wrong line |
| Write-task overhead | `git span list` first call to get canonical existing name | Guess/reconstruct name from raw `.span/` file inspection → transcription slips |

## Hybrid variant designs

### variant-d — single-file, recipe-first, with an embedded triage decision tree
Structure: one file (a's economy — no router-miss risk from §4). Order: (1) the 7-line
command block, (2) a **6-line decision tree** placed *before* any recipe:
```
stale reports an anchor as:
  Moved              → remove old + add new (same lines, new path)      [recipe 3]
  Changed            → grep -n <the why's named symbol> in the target file.
                        If the grep hit falls inside the anchor's existing range:
                          re-`add` the SAME range (checksum refresh only). Do NOT
                          pick a new range because the code "looks like" it changed
                          meaning — only a symbol that physically moved lines changes
                          the range.                                     [recipe 1]
  not in stale at all → declare fresh                                    [recipe 2]
```
This targets §3's failure directly and is the single highest-leverage addition — none
of the three original variants state it. (3) Recipes 1-5 (reconcile, declare, re-anchor,
triage-batch, inspect) each ≤5 lines, each ending in an explicit **stop condition**,
e.g. "stop once `git span stale <name>` exits 0 — do not additionally check `git
log`/`git show`/raw `.span/*` files, the CLI's own output is authoritative" (targets
§1/§5). (4) For multi-span triage, one line: batch history/log lookups by path *class*
(all `src/*` in one `git log --all --full-history --` call), not per-file (targets §2).
Target size: ~130-160 lines, still single-hop.

### variant-e — adaptive disclosure: inline for writes, sectioned for investigation
Structure: `SKILL.md` (~50-60 lines) covers the three *write-shaped* recipes verbatim
inline — declare, consistent-update/write-both-sides, simple re-anchor where `stale`
already names the right target — no read hop, since §1/§4 show write tasks get cheaper
with fewer hops and less improvisation-surface. Two sibling files only for genuinely
open-ended *investigation*, where structure earns back its hop cost by preventing the
detours in §1/§2: `sections/triage.md` (multi-span drift classification: variant-d's
decision tree + §2's batched-history discipline + a §5 "do not run" list: no `git log`
beyond one batched call, no `git show` beyond the one commit that explains the drift,
no raw `.span/*` reads — `git span show`/`stale` supersede them) and
`sections/inspect.md` (unchanged from variant-b — §5 shows it's already near-optimal;
t024 is one of the two cheapest sessions in the corpus). Dispatch is a single countable
trigger, not a symptom guess: "if the task involves more than one drifted span, or the
resolution isn't obvious from `stale`'s single-anchor output, read
`sections/triage.md` first; every other write task is answered inline above." This
removes §4's silent-no-read failure by making inline-vs-section a binary the agent can
evaluate mechanically instead of a symptom match it can fail to recognize.

Differentiation: d bets a single well-ordered file with an explicit decision procedure
beats any router; e bets only multi-span/ambiguous investigation earns back a read hop,
triggered by a countable condition, not symptom prose. Both must state the §3
grep-before-anchor discipline and the §1/§5 "CLI output is authoritative, stop there"
rule — the two highest-confidence, evidence-backed fixes regardless of which structural
bet wins.
