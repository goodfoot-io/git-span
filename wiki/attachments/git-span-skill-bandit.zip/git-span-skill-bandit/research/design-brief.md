# git-span skill bandit — design brief

Consumption model for all three variants: a Haiku agent in a headless session is given
the absolute path to `SKILL.md` and told to read it plus `git span --help`/subcommand
`--help`, nothing else. No frontmatter-triggered loading — the file is read directly, once.
Score = 0 on task failure, else `1/total_transcript_chars`. Optimize for: correct on the
first attempt, minimal re-reads, minimal wasted `--help` lookups, minimal wrong-flag errors.

## 0. CRITICAL — verify against the installed CLI, not the historical report

The installed binary in this harness is **git-span 1.0.134**. It is a *smaller* surface
than `/workspace/reports/used-git-mesh-functionality.md` describes — that report was mined
from historical transcripts spanning multiple CLI versions. Confirmed by direct `--help`
and live invocation against this exact binary:

- **No `move` subcommand at all** (`error: unrecognized subcommand 'move'`). Re-anchor/rename
  must be done as `remove` + `add` (or `delete` + `add`), never `git span move`.
- **`stale` has no `--patch`, `--stat`, `--worktree`, `--staged`, `--head`, or `--search`.**
  Only: `--format {human,porcelain,json}`, `--fix` (human-only), `--no-exit-code`,
  `--perf`, `--perf-trace`.
- **`why` has no `--at`, `-F`, or `--edit`** (the prose in `why --help` mentions them but the
  `Options:` list does not — trust the `Options:` list, not the prose). Only `-m <MSG>`.
- **`show` has no `--patch`/`--at`.** Only `<NAME>`.
- **`add` has no `--replace`.** Only `--at <COMMIT-ISH>`.
- **`list` has no `--search` or `--batch`.** Filtering is via positional `[TARGETS]...`
  (paths, `#L` ranges, or bare span names), plus `--oneline`/`--porcelain`/`--offset`/`--limit`.
- **`doctor` has no `--strict`.** Flags: `--perf` only.
- **`history` defaults to `--format xml`**, not text; `--format json` also available.
- Real `stale` human output uses a `## span-name` header, an anchor list with a trailing
  `— changed`/`— moved` suffix (no bracketed `[CHANGED]`/`[MOVED]` markers, no `(ack)`,
  no `src=…`), then the why prose, then a `---` separator. **This does not match the
  incumbent skill's `reading-stale-output.md` marker vocabulary** — do not port that section
  verbatim into a new variant without re-verifying against this binary.

**Implication:** do not copy flag tables or output-marker descriptions straight out of the
usage report or the incumbent skill — every flag claim must be traceable to this binary's
actual `--help`/behavior. Confusion-catalog items referencing now-nonexistent flags
(`--patch`/`--stat`/`--worktree`/`--staged`/`--head`, `--at` on `why`, `--replace`, `move`)
should be **dropped** — teaching a nonexistent-flag gotcha wastes tokens and can't
reproduce in the grading envs. Structural/behavioral confusion items (not flag-surface-
dependent) are still live — the real must-cover list is §3.

## 1. Skill-authoring principles that apply here

1. Write for the reader, not for completeness — the reader is a Haiku agent with one read pass.
2. Cut tokens aggressively: remove ≥1.2 tokens for every 1 token added: no rationale asides,
   no restated `--help` content, no "why this rule exists" prose.
3. Every line must be actionable: if a sentence doesn't change what the agent does next, cut it.
4. Front-load by observed frequency, not conceptual tidiness: >70% of real usage is
   `stale`→`add`→`why`; that trio must be unmissable in the first screen, not buried under
   `tree`/`doctor`/`merge-driver` (which are near-zero usage).
5. State gotchas as **imperative workarounds**, not narrated bug reports: "`stale --fix`
   silently no-ops on drifted content — re-anchor with `git span add <name> <anchor>`
   directly" beats a paragraph explaining the bug's mechanism.
6. Do not duplicate what `--help` already documents well (arg shapes, per-flag defaults) —
   point at `--help` instead of re-deriving it. Duplicate only what `--help` is silent or
   misleading on.
7. No skill-name/invocation-alias content — irrelevant here, the agent is handed the path
   directly, never told a skill name to resolve.
8. Progressive disclosure (SKILL.md thin + sibling reference files) only pays for itself if
   the router's dispatch is cheap and precise — a router with vague dispatch conditions
   causes wrong-section reads, which cost turns and chars, worse than a single well-ordered
   file. If using sections, key them on **symptom/verb the agent will type or see**, not on
   abstract topic taxonomy.
9. No untested claims: every gotcha must be something this binary actually does (see §0).
   A wrong gotcha is worse than no gotcha — it burns a turn discovering the claim is false.
10. Optimize for the four graded scenarios specifically (§5), not for encyclopedic coverage
    of every subcommand. `merge-driver` (0 real manual invocations, automatic-only) and
    `doctor` (setup-only) earn at most one line each, if any.

## 2. What `--help` already covers vs. what it misses

**`--help` covers adequately (do not duplicate):**
- Per-subcommand arg shapes and flag lists (`add <NAME> <ANCHORS>...`, `remove`'s anchor
  match requirement, `delete`'s `<NAME>`-only shape, `list`'s `[TARGETS]...`).
- Anchor syntax: `<path>` (whole-file) vs `<path>#L<start>-L<end>` (1-indexed inclusive).
- `stale --fix`'s own scope rules ("`Only supported with --format human`", re-anchors
  Moved unconditionally, whitespace-equivalent Changed in place, meaning-changing Changed
  left drifting).
- `history`'s default format (xml) and `--format json` alternative.
- `tree`'s requirement for explicit root globs and its depth semantics.
- The top-level `EXAMPLES` block (add→why→commit sequence) — this is genuinely a good
  worked example already; don't re-explain it, just reference the pattern.
- `why`'s guidance on *what* to write (definitional, role-words, survives rewrites,
  inherited across re-anchors) — this prose is already good and skill content should not
  restate it, only reference it.

**`--help` misses (this is what a skill must cover):**
- That `stale --fix` **silently fails to clear drift that reappears on next check** for
  content beyond whitespace-equivalence — `--help` documents the *intended* scope precisely,
  but does not warn that agents historically misread "whitespace-equivalent" and expected
  `--fix` to close out ordinary content edits too, then were confused when `--fix` reported
  success but the same anchor stale'd again. The fix (`git span add` directly) isn't spelled
  out as the escape hatch in `--help`.
- That `add` never retires the anchor it supersedes — no cross-reference from `add --help`
  to `remove`; the "re-anchor to a new location" idiom (`remove` old + `add` new) is not
  stated anywhere in `--help`, only implied by two separate command docs existing.
  `--help` also never states there's no atomic replace (there being no `--replace` flag at
  all in this build is itself the missing information).
- Span **name** grammar (kebab-case segments, no leading dot, `a-z0-9` segment start) is not
  in any `--help` text at all — only surfaces as a runtime error message.
- That the anchor end-line must match the file's *current* line count exactly, and that
  editing a file changes that count — `--help` states the syntax, not the "recount after
  edit" discipline (`wc -l <path>`).
- That `stale --format json` is one-JSON-object-per-line (NDJSON), not a JSON array —
  `--help` just says `[possible values: human, porcelain, json]` with no shape note.
- That passing a file **path** where `stale` expects to match on **span name** is not an
  error — it's a silent 0-result match. `--help` says "File paths, globs, or span names"
  as if interchangeable; it does not warn about the silent-empty-match failure mode.
- That `stale` exits 1 on any drift (breaking `&&` chains) unless `--no-exit-code` is passed
  — `--help` documents the flag's existence but not the *reason* to reach for it (a chained
  `git span stale && git span tree ...` pipeline breaking).
- Cross-command relationships / recommended sequencing (`add` then `why -m` is the real
  idiom order — declare, then justify — not "check why first").
- The `## name` / anchor-list / `— changed` / why / `---` shape of real `stale`/`show`
  human output (so an agent parses it correctly on first read instead of guessing).

## 3. Must-cover content (usage-frequency-ranked, flag-surface-verified)

**Load-bearing workflow (in this order — matches real usage weight):**
```
git span stale [<name-or-path>] [--fix] [--no-exit-code] [--format human|porcelain|json]
git span add <name> <anchor>...          # declare or re-anchor; anchor = path or path#Lx-Ly
git span why <name> [-m "..."]           # bare = read; -m = write, after add/remove
git span remove <name> <anchor>...       # paired with add to retire a superseded anchor
git span delete <name>                   # dead coupling, or overwrite-idiom during renames
git span list [<target>...] [--oneline]  # positional filter, not --search
git span show <name>   (== bare `git span <name>`)
```
`tree`, `history`, `doctor` are secondary/read-only specialist tools — one line each, no
flag deep-dive. `merge-driver` — one sentence: automatic only, never invoke manually.

**Top confusion items to cover, ranked by observed cost (structural ones only — see §0):**

1. **`stale <name> --fix` can silently fail to clear drift** for content-level changes
   (only whitespace-equivalent Changed + all Moved are auto-fixed). Workaround: re-anchor
   directly with `git span add <name> <new-anchor>`. Highest-cost item in the corpus
   (10-20+ wasted tool calls per occurrence) — must be the first gotcha stated.
2. **Anchor end-line off-by-one after editing the anchored file** — `add` rejects
   `end=N exceeds file line count (M)`. Discipline: `wc -l <path>` immediately before
   writing the anchor, especially right after an edit to that same file.
3. **`add` does not retire the anchor it supersedes.** Re-anchoring to a new location is a
   two-step idiom: `git span remove <name> <old-anchor>` + `git span add <name> <new-anchor>`
   (or `delete` + recreate for a full overwrite). Skipping `remove` leaves `stale` still
   reporting the old anchor as Moved.
3. **`stale --format json` is NDJSON** (one object per line), not a JSON array — parse
   line-by-line.
4. **Span name vs. anchor path**: names are kebab-case segments (`a-z0-9`-leading, no
   leading dot); never name a span after a literal dotfile path
   (`.github/workflows/x.yml` → invalid name, `'.github'` fails). Pick a descriptive
   subsystem slug instead.
5. **`delete` accepts `<NAME>` only** — no anchor args, no `--note`/rationale flag. Record
   rationale (if any) via `why -m` *before* deleting, or in the commit message.
6. **Selector-type trap**: `stale`/`list` match on span *name* or *path*, but passing the
   wrong one doesn't error — it silently matches nothing (exit 0, empty). If a `stale <arg>`
   call reports clean with zero anchors listed, double check `<arg>` is actually a real span
   name or a path that has anchors, not a `.span/`-relative file path.
7. **`stale` exits 1 on any drift** — breaks `&&` chains. Use `--no-exit-code` when chaining,
   or check drift and branch instead of chaining blindly.
8. **`stale --fix` with no name/path filter scans and rewrites every span** — scope it to a
   specific name/path when only one coupling is under repair, to avoid touching unrelated
   `.span/` files.
9. **`why` idiom order is declare-then-justify**: `add` (or `remove`+`add`) first, `why -m`
   second, in the same logical step — not "check `why` first" as a pre-flight gate.

Explicitly omit (near-zero real usage or flag-surface-nonexistent in this build):
`--replace`, `move`, `--at` on `why`/`show`, `--patch`/`--stat`/`--worktree`/`--staged`/
`--head` on `stale`/`why`/`show`, `--search`/`--batch` on `list`, `doctor --strict`.

## 4. Three variant specs

### variant-a — single-file gotcha-first cheat sheet
**Thesis:** one read, zero navigation. Everything the agent needs is in the one file it was
told to read; no second file-read round-trip risk.
**Structure:** flat Markdown, no sections/ dir. Order: (1) the 7-line load-bearing command
block from §3 verbatim, as a fenced snippet, (2) a numbered gotchas list — §3's 9 items,
each one 1-3 lines, imperative, workaround-first, (3) one worked mini-recipe per graded
scenario shape (reconcile, declare, re-anchor+retire, inspect) as 3-5 line command
sequences, (4) explicit "do not bother with" list (the omitted flags from §3, one line,
so the agent doesn't waste a `--help` call discovering they don't exist).
**Target size:** ~110-150 lines / ~900-1100 words.
**Includes:** everything in §3 must-cover list; the 4 recipe skeletons; the omitted-flags
list.
**Omits:** `tree`/`history`/`doctor`/`merge-driver` beyond one line each; no prose
rationale for *why* each gotcha happens, only *what to do*; no output-format walkthrough
beyond a 3-line annotated example of `stale` human output.
**Scenario handling:**
- *reconcile-drift*: gotcha #1 (fix no-op) is right at the top — agent goes straight to
  `stale` → `add` re-anchor → `why -m` refresh → commit, never trusts `--fix` alone.
- *declare-coupling*: recipe #2 gives the exact `add <name> <anchor>...` then
  `why -m "..."` order and the name-grammar gotcha (#4) prevents a dotfile-name error.
- *reanchor-retire*: recipe #3 is the `remove` old + `add` new pair verbatim, citing
  gotcha #3 (add doesn't retire) so the agent doesn't skip `remove`.
- *inspect-report*: recipe #4 lists `list`/`show`/`why`/`history` as the read-only
  toolkit with the selector-trap gotcha (#6) so a bad name/path doesn't silently return
  empty and get misreported as "no such span."

### variant-b — minimal router + compact merged sections
**Thesis:** token-economized descendant of the incumbent 25-line-router/17-file structure,
but collapsed to the few dispatch conditions that actually matter for this agent's task
set, so progressive disclosure pays for itself instead of costing an extra read hop for
no benefit.
**Structure:** `SKILL.md` router, ~25-30 lines: the §3 command block, then 4 dispatch
bullets keyed on **symptom** (not abstract taxonomy), each pointing at one sibling file:
- `sections/reconcile.md` — stale reading, `--fix` gotcha, re-anchor idiom, gotchas
  #1/#2/#3/#6/#7/#8. Covers reconcile-drift *and* reanchor-retire (same underlying idiom:
  judge drift → `remove`+`add` → `why`).
- `sections/declare.md` — add/why grammar, naming gotcha #4, declare-then-justify order
  gotcha #9. Covers declare-coupling.
- `sections/inspect.md` — list/show/why/history read-only usage, selector trap #6, NDJSON
  gotcha #3. Covers inspect-report.
- `sections/reference.md` — delete's arg shape #5, the omitted-flags list, one-liners for
  tree/doctor/merge-driver.
Router ≤30 lines; each section ≤40 lines; total package ≤180 lines / 4 files. Each section
self-contained enough that one read suffices per scenario (no cross-section hops mid-task).
No top-level/section duplication — one fact lives in exactly one place, unlike the
incumbent's 17-file structure with overlapping cross-references.
**Risk:** this variant only wins if the router's dispatch is symptom-precise; a vague
bullet costs an extra read hop, making it strictly worse than variant-a for the same
content.

### variant-c — workflow-recipe format
**Thesis:** organize around the four *observed idioms* as literal executable recipes, not
around subcommands or symptoms — commands first, prose minimal, so the agent can pattern-
match its task to a recipe and copy the shape.
**Structure:** single file (or file + 1 optional `sections/reference.md` for the omitted-
flags/edge-case table, kept out of the main path). Body is four fenced recipe blocks:
```
## Reconcile loop           (reconcile-drift)
git span stale [<name>]
# if drift and content changed (not just Moved/whitespace): --fix will NOT clear it
git span add <name> <path>#L<start>-L<end> ...   # wc -l <path> first
git span why <name> -m "..."                      # only if the subsystem itself changed
git add .span && git commit -m "..."

## Declare-then-justify      (declare-coupling)
git span add <name> <anchor>...
git span why <name> -m "one-sentence definition, role-words, survives rewrites"
git add .span && git commit -m "..."

## Re-anchor + retire        (reanchor-retire)
git span remove <name> <old-anchor>
git span add <name> <new-anchor>
git span why <name> -m "..."     # only if relationship itself changed, else inherited
git add .span && git commit -m "..."

## Inspect                   (inspect-report)
git span list [<target>]      # positional filter; --oneline for terse
git span show <name>          # == bare `git span <name>`
git span why <name>            # bare = read
git span history <name>        # xml default, --format json alt
```
Each recipe followed by a 3-5 line "watch for" list of just the gotchas from §3 that apply
to *that* recipe (not the full 9-item list every time) — e.g. the reconcile recipe carries
gotchas #1, #2, #6, #7, #8; the inspect recipe carries only #6.
**Target size:** ~90-130 lines / ~700-950 words — smallest of the three if the reference
table is split out, since gotchas are distributed inline near their trigger point rather
than listed once globally.
**Includes:** the four recipes verbatim-runnable; per-recipe gotcha subsets; name-grammar
rule inlined in the declare recipe (where it bites); NDJSON/selector-trap notes inlined in
the recipe where relevant instead of centralized.
**Omits:** any subcommand not in one of the four recipes gets a single trailing one-line
"also exists" list (`tree`/`doctor`/`merge-driver`), no elaboration.
**Scenario handling:** near 1:1 — each CONTRACT.md scenario maps to exactly one recipe
block, so the agent's read-to-action distance is shortest of the three variants. Main risk:
if a real task doesn't cleanly match one recipe (e.g. needs a `delete`-based overwrite
instead of `remove`+`add`), the agent has less generalizable narrative than variant-a/b to
fall back on — mitigate with one line under "Re-anchor + retire" noting `delete`+recreate
as the alternate shape for a full overwrite.

**Comparative framing:** a = safest single-hop baseline; b = tests whether progressive
disclosure earns its extra hop when dispatch is symptom-precise; c = bets recipe-shaped,
command-first content minimizes errors and chars by matching the agent's action shape
most tightly. Whether b's misrouting risk actually materializes is the main thing the
bandit should resolve.

## 5. Grading rubric alignment

- **reconcile-drift**: skill must convey, cheaply and early, that `--fix` cannot be trusted
  alone for content drift and that the real move is `add` (re-anchor) then `why -m` if the
  relationship changed, then commit `.span`. Grader checks `stale` exits clean + anchors/why
  match — so the skill must also convey that a *fresh* `stale` recheck after re-anchoring is
  the way to confirm, not just trusting the `add` succeeded.
- **declare-coupling**: skill must convey the anchor syntax (`path#Lstart-Lend`, `wc -l`
  discipline), the name-grammar constraint (kebab-case, no leading dot — grader checks
  "name shape"), that anchors must land on the *right* lines (grader checks this precisely,
  so the wc -l discipline is load-bearing, not optional polish), and that `why` needs
  non-empty definitional prose, plus `git add .span && git commit`.
- **reanchor-retire**: skill must convey the two-step `remove` old + `add` new pairing
  explicitly — this is the single highest-risk scenario for a skill that only lists `add`,
  since the grader checks the *old* anchor is gone (`add` alone leaves it, per gotcha #3).
  Whichever variant states this pairing most unambiguously wins this scenario most cheaply.
- **inspect-report**: skill must convey which command answers which question shape
  (existence/content → `list`/`show`; rationale → `why`; timeline → `history`) and the
  selector-trap gotcha so a wrong name/path doesn't get misreported as "doesn't exist" in
  ANSWERS.md. No repo mutation should be attempted — a skill that leads with mutation
  recipes (variant-c) must make the inspect recipe clearly read-only-labeled so the agent
  doesn't reflexively `add`/`commit` here.

Cross-cutting: all three variants should state the `.span`-commit step (`git add .span &&
git commit`) at every write, since 3 of 4 scenarios require a commit — cheap to state
inline vs. forcing a re-derivation.
