#!/usr/bin/env python3
"""Break down transcript chars by event type/tool for a given trial session."""
import json, sys, os

def encode(env_dir):
    return ''.join(c if (c.isalnum() or c == '-') else '-' for c in env_dir)

def load_trials():
    recs = {}
    with open('/tmp/git-span-skill-test/results/trials.jsonl') as f:
        for line in f:
            d = json.loads(line)
            recs[d['trial_id']] = d
    return recs

def transcript_path(trial):
    enc = encode(trial['env_dir'])
    base = os.path.expanduser(f"~/.claude/projects/{enc}/{trial['session_id']}.jsonl")
    return base

def classify_tool_use(name, inp):
    if name == 'Bash':
        cmd = inp.get('command', '')
        return cmd
    if name == 'Read':
        return f"Read {inp.get('file_path','')}"
    if name == 'Write':
        return f"Write {inp.get('file_path','')}"
    if name == 'Edit':
        return f"Edit {inp.get('file_path','')}"
    return f"{name} {json.dumps(inp)[:80]}"

def analyze(trial_id):
    trials = load_trials()
    t = trials[trial_id]
    path = transcript_path(t)
    if not os.path.exists(path):
        print(f"MISSING: {path}")
        return
    events = []
    with open(path) as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            events.append(json.loads(line))

    total_chars = sum(len(json.dumps(e)) for e in events)
    print(f"=== {trial_id} {t['variant']} {t['scenario']} pass={t['pass']} total_chars(recorded)={t['total_chars']} events={len(events)} raw_json_chars={total_chars}")

    buckets = {}
    def add(bucket, n):
        buckets[bucket] = buckets.get(bucket, 0) + n

    tool_calls = []
    for e in events:
        etype = e.get('type')
        msg = e.get('message', {})
        content = msg.get('content') if isinstance(msg, dict) else None
        if isinstance(content, str):
            add(f"{etype}:text", len(content))
            continue
        if not isinstance(content, list):
            add(f"{etype}:other", len(json.dumps(e)))
            continue
        for block in content:
            btype = block.get('type')
            if btype == 'text':
                add(f"{etype}:text", len(block.get('text','')))
            elif btype == 'tool_use':
                name = block.get('name')
                inp = block.get('input', {})
                s = classify_tool_use(name, inp)
                size = len(json.dumps(inp))
                add(f"tool_use:{name}", size)
                tool_calls.append((name, s, size))
            elif btype == 'tool_result':
                c = block.get('content')
                if isinstance(c, list):
                    s = sum(len(json.dumps(x)) for x in c)
                elif isinstance(c, str):
                    s = len(c)
                else:
                    s = len(json.dumps(c))
                add('tool_result', s)
            elif btype == 'thinking':
                add(f"{etype}:thinking", len(block.get('thinking','')))
            else:
                add(f"{etype}:{btype}", len(json.dumps(block)))

    for k,v in sorted(buckets.items(), key=lambda x:-x[1]):
        print(f"  {k:30s} {v:8d}  ({100*v/total_chars:.1f}%)")

    print("  -- tool call sequence --")
    for name, s, size in tool_calls:
        label = s if len(s) < 140 else s[:140] + '...'
        print(f"    [{name:6s} {size:6d}] {label}")

if __name__ == '__main__':
    for tid in sys.argv[1:]:
        analyze(tid)
        print()
