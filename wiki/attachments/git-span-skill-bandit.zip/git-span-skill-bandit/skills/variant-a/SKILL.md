---
name: git-span
description: Track, declare, and reconcile implicit semantic couplings between file/line ranges in a git repo via anchored spans.
---

# git-span

Load-bearing commands, in real-usage order:

```
git span stale [<name-or-path>] [--fix] [--no-exit-code] [--format human|porcelain|json]
git span add <name> <anchor>...          # declare or re-anchor; anchor = path or path#Lstart-Lend
git span why <name> [-m "..."]           # bare = read current why; -m = write new why
git span remove <name> <anchor>...       # retire a superseded anchor (pair with add when re-anchoring)
git span delete <name>                   # delete whole span; NAME only, no anchor args
git span list [<target>...] [--oneline]  # positional filter on name or path, not --search
git span show <name>                     # == bare `git span <name>`
```
`tree`, `history`, `doctor` are secondary read-only tools — use `--help` if needed, rarely used.
`merge-driver` runs automatically only; never invoke it by hand.

After any `add` / `remove` / `why -m` / `delete`: `git add .span && git commit -m "..."`.

## Gotchas — read before acting, workaround stated first

1. `stale --fix` does **not** clear content-level drift — it only auto-fixes whitespace-equivalent
   Changed anchors and all Moved anchors. Re-anchor real content changes directly:
   `git span add <name> <anchor>`, then re-run `stale` to confirm clean.
2. Anchor end-line must equal the file's *current* line count — `add` rejects
   `end=N exceeds file line count (M)`. Run `wc -l <path>` immediately before writing
   `#Lstart-Lend`, especially right after editing that same file.
3. `add` never retires the anchor it replaces. Re-anchoring is a two-step idiom:
   `git span remove <name> <old-anchor>` then `git span add <name> <new-anchor>` (or
   `delete` + recreate for a full overwrite). Skip `remove` and `stale` keeps reporting the
   old anchor.
4. `stale --format json` prints one pretty-printed JSON object per invocation (top-level
   `findings` array) — it is **not** NDJSON. Parse it as a single document, not line-by-line.
5. Span names are kebab-case segments (`a-z0-9`, no leading dot); `.github/workflows/x.yml`
   is rejected as a name. Use a descriptive subsystem/flow slug, never a literal dotfile path.
6. `delete <name>` takes no anchor args and no rationale flag. Record rationale with `why -m`
   before deleting, or put it in the commit message.
7. `stale`/`list` accept a span name or a path, but a wrong or uncovered one does not error —
   it's a silent empty match (`0 stale across 0 spans` / `No spans match the filters.`,
   exit 0). Zero results ≠ "no such span" — run `git span list` to confirm the real
   name/path before concluding nothing exists.
8. `stale` exits 1 whenever it finds drift, breaking `&&` chains. Pass `--no-exit-code` when
   chaining, or check then branch instead.
9. `stale --fix` with no name/path argument scans and rewrites every span in the repo. Pass
   the specific `<name>` or `<path>` when only one coupling is under repair.
10. Write order is declare-then-justify: run `add` (or `remove`+`add`) first, `why -m`
    second, same logical step — not as a pre-flight check before acting.

## Recipes

### Reconcile drift (`stale` reports Changed/Moved)
```
git span stale [<name-or-path>]
# --fix only clears whitespace-equivalent Changed + all Moved (gotcha 1) — don't trust it beyond that
git span add <name> <path>#L<start>-L<end> ...   # wc -l <path> first (gotcha 2)
git span why <name> -m "..."                      # only if the relationship itself changed
git span stale <name>                             # recheck: must exit clean before commit
git add .span && git commit -m "..."
```

### Declare a new coupling
```
git span add <name> <anchor>...           # kebab-case name (gotcha 5); wc -l <path> first for #L ranges
git span why <name> -m "one-sentence definition, role-words, survives rewrites"
git add .span && git commit -m "..."
```

### Re-anchor + retire (moved to a new file/location)
```
git span remove <name> <old-anchor>       # required (gotcha 3) — add alone leaves old anchor stale
git span add <name> <new-anchor>
git span why <name> -m "..."              # only if the relationship changed, else inherited
git add .span && git commit -m "..."
```
Full overwrite instead: `git span delete <name>` then recreate with `add`.

### Inspect (read-only — no add/remove/delete/commit here)
```
git span list [<target>]      # existence/content; --oneline for terse; positional filter (gotcha 7)
git span show <name>          # == bare `git span <name>`; anchors + why + config
git span why <name>           # bare = read current rationale
git span history <name>       # timeline; default xml, --format json alt
```
Zero results from `list`/`stale` on a given name/path means check gotcha 7 before reporting
"doesn't exist" — confirm with a plain `git span list` that the name/path is real.

## `stale` human output shape
```
## <span-name>
- <anchor>                              (no suffix = clean)
- <anchor> — changed in the working tree     (or "— moved to <path>#Lx-Ly" for Moved)
<why prose>
```

## Not in this build — don't burn a `--help` call checking
`move` subcommand; `stale --patch/--stat/--worktree/--staged/--head/--search`;
`why --at/-F/--edit`; `show --patch/--at`; `add --replace`; `list --search/--batch`;
`doctor --strict`.
