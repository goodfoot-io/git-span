---
name: git-span
description: Track, declare, and reconcile implicit semantic couplings between file/line ranges in a git repo via anchored spans.
---

# git-span

Load-bearing commands, real-usage order:
```
git span stale [<name-or-path>] [--fix] [--no-exit-code] [--format human|porcelain|json]
git span add <name> <anchor>...          # declare or re-anchor; anchor = path or path#Lstart-Lend
git span why <name> [-m "..."]           # bare = read; -m = write, after add/remove
git span remove <name> <anchor>...       # retire a superseded anchor (pair with add)
git span delete <name>                   # delete whole span; NAME only, no anchor args
git span list [<target>...] [--oneline]  # positional filter on name or path, not --search
git span show <name>                     # == bare `git span <name>`
```
`tree`/`history`/`doctor` are secondary read-only tools, rarely needed; `merge-driver` runs
automatically only, never invoke it. After any `add`/`remove`/`why -m`/`delete`:
`git add .span && git commit -m "..."`.

## Trust boundary — stop once these answer you
`stale`/`show`/`why`/`history`/`list` output is ground truth — act on it, don't re-verify.
Never run `git log`, `git show <hash>`, or read raw `.span/*` files once one of these has
already answered you. The only source file to open is the anchor's target, to `grep -n` a
symbol (below) or `wc -l` it.

## Drift triage — decide before you touch a stale anchor
```
stale reports the anchor as:
  Moved               → same content, new location → Recipe 1/3, re-add at the new range.
  Changed             → grep -n <symbol the span's why names> in the target file.
                          Grep hit still inside the anchor's CURRENT range?
                            yes → re-add that SAME range (checksum refresh only).
                            no  → the symbol physically moved lines → anchor its new range.
                          Never pick a range because the code "conceptually" changed meaning
                          — only a symbol's physical line move licenses a new range.
  counterpart deleted → the other side of the coupling no longer exists → `delete <name>`;
                          never re-anchor a dead coupling to unrelated content.
  not in stale at all → nothing tracks it yet → Recipe 2 (declare).
```

## Recipe 1 — Reconcile drift
```
git span stale [<name-or-path>]
# --fix only clears whitespace-equivalent Changed + all Moved — don't trust it beyond that
# apply the triage above per anchor; wc -l <path> before writing any #Lstart-Lend
git span add <name> <path>#L<start>-L<end> ...
git span why <name> -m "..."              # only if the relationship itself changed
git span stale <name>                     # must exit 0
git add .span && git commit -m "..."
```
Stop once that `stale <name>` exits 0 — do not additionally check `git log`/`git show`.

## Recipe 2 — Declare a new coupling
```
git span add <name> <anchor>...           # kebab-case segments, a-z0-9-, no leading dot/dotfile
git span why <name> -m "one sentence: name the subsystem, say what it does across anchors"
git add .span && git commit -m "..."
```
`wc -l <path>` first for any `#Lx-Ly` anchor. Stop after the commit — nothing left to verify.

## Recipe 3 — Re-anchor + retire (moved to a new file/location)
```
git span remove <name> <old-anchor>       # required — add alone leaves the old anchor stale forever
git span add <name> <new-anchor>
git span why <name> -m "..."              # only if the relationship changed, else inherited
git span stale <name>                     # confirm exit 0 and old anchor gone
git add .span && git commit -m "..."
```
Full-overwrite alternative: `git span delete <name>` then recreate with `add`.

## Recipe 4 — Multi-span triage (several spans drift at once)
```
git span stale                                          # one call, all spans, read the whole report
git log --all --full-history -- <all src/* paths>       # one batched call per path CLASS
git log --all --full-history -- <all docs/* paths>      # (never one call per file)
```
Apply the drift triage above to each drifting anchor independently, then run Recipe 1, Recipe
3, or `delete` per span exactly as its triage branch says. Stop once a final bare `git span
stale` exits 0 and every resolution matches its triage branch — don't re-derive a range you
already confirmed covers the symbol.

## Recipe 5 — Inspect (read-only — no add/remove/delete/commit)
```
git span list [<target>]      # existence/content; --oneline for terse
git span show <name>          # anchors + why + config
git span why <name>           # bare = read
git span history <name>       # timeline; default xml, --format json alt
```
A zero/empty result from `list`/`stale` does not mean "doesn't exist" — it silently matches
nothing if you passed the wrong selector type (name vs. path). Run a bare `git span list` to
confirm the real name/path before reporting non-existence in an answer.

## Gotchas
- `stale --format json` is **one JSON object** (`{"findings": [...], "schema_version",
  "span"}`), not NDJSON and not an array — parse it as a single document.
- `add` never retires the anchor it supersedes; `delete <name>` takes no anchor args or note
  flag — record rationale with `why -m` first, or in the commit message.
- `stale` exits 1 on any drift, breaking `&&` chains — pass `--no-exit-code` when chaining.
- Unscoped `stale --fix` (no name/path) rewrites every span in the repo — scope it to
  `<name>`/`<path>` when only one coupling is under repair.
- Write order is declare-then-justify: `add`/`remove` first, `why -m` second, same step.

## Not in this build — don't burn a `--help` call checking
`move` subcommand; `stale --patch/--stat/--worktree/--staged/--head/--search`;
`why --at/-F/--edit`; `show --patch/--at`; `add --replace`; `list --search/--batch`;
`doctor --strict`.
