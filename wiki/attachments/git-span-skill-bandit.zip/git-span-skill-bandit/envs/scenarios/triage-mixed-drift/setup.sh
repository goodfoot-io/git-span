#!/usr/bin/env bash
# setup.sh <dest-dir>
#
# Builds a tiny fixture repo with three source+doc spans, each drifted in a
# DIFFERENT way that demands a different resolution:
#   - notifications/dispatch-doc-sync   : whole-file rename (Moved)
#   - notifications/rate-limit-doc-sync : cosmetic refactor, coupling still
#                                          holds (Changed, re-anchor + keep why)
#   - notifications/backoff-retry-doc-sync : the feature itself was deleted
#                                          from BOTH the code and the doc
#                                          (Changed, but the coupling is dead
#                                          -> the span should be deleted, not
#                                          re-anchored to the unrelated text
#                                          left behind at the same lines)
set -euo pipefail

DEST="${1:?usage: setup.sh <dest-dir>}"
mkdir -p "$DEST"
cd "$DEST"

export GIT_AUTHOR_NAME=fixture
export GIT_AUTHOR_EMAIL=fixture@test
export GIT_COMMITTER_NAME=fixture
export GIT_COMMITTER_EMAIL=fixture@test

COMMIT_MIN=0
commit() {
  COMMIT_MIN=$((COMMIT_MIN + 1))
  local d
  d=$(printf "2020-01-01T00:%02d:00Z" "$COMMIT_MIN")
  GIT_AUTHOR_DATE="$d" GIT_COMMITTER_DATE="$d" git commit -q -m "$1"
}

git init -q -b main
git config user.name fixture
git config user.email fixture@test

mkdir -p src docs

cat > src/legacy_dispatch.py <<'EOF'
"""Notification dispatch (pending rename)."""


def dispatch(event, subscribers):
    for sub in subscribers:
        sub.notify(event)
    return len(subscribers)
EOF

cat > docs/dispatch.md <<'EOF'
# Dispatch

Each event is sent to every subscriber via `dispatch`.
EOF

cat > src/rate_limit.py <<'EOF'
"""Per-minute request rate limiting."""


RATE_LIMIT_PER_MINUTE = 20


def should_throttle(request_count):
    return request_count >= RATE_LIMIT_PER_MINUTE
EOF

cat > docs/rate_limit.md <<'EOF'
# Rate Limit

Requests are throttled after 20 per minute.
EOF

cat > src/retry.py <<'EOF'
"""Retry helpers."""


def retry_with_backoff(fn, base_delay=1):
    delay = base_delay
    for _ in range(5):
        try:
            return fn()
        except RuntimeError:
            delay *= 2
    raise RuntimeError("exhausted")


def simple_retry(fn):
    try:
        return fn()
    except RuntimeError:
        return None
EOF

cat > docs/retry.md <<'EOF'
# Retry

`retry_with_backoff` retries with exponential backoff up to 5 attempts.

`simple_retry` is a single-attempt fallback with no backoff.

See `src/retry.py` for both implementations.
EOF

git add src docs
commit "Add dispatch, rate limit, and retry modules with docs"

git span add notifications/dispatch-doc-sync \
  src/legacy_dispatch.py#L4-L7 \
  docs/dispatch.md#L3-L3 >/dev/null
git span why notifications/dispatch-doc-sync \
  -m "Event dispatch whose subscriber fan-out behavior the doc describes for integrators." >/dev/null

git span add notifications/rate-limit-doc-sync \
  src/rate_limit.py#L7-L8 \
  docs/rate_limit.md#L3-L3 >/dev/null
git span why notifications/rate-limit-doc-sync \
  -m "Per-minute rate limit whose threshold the doc restates for API consumers." >/dev/null

git span add notifications/backoff-retry-doc-sync \
  src/retry.py#L4-L11 \
  docs/retry.md#L3-L3 >/dev/null
git span why notifications/backoff-retry-doc-sync \
  -m "Exponential backoff retry whose attempt count the doc restates for operators." >/dev/null

git add .span
commit "Declare dispatch, rate-limit, and backoff-retry spans"

# (i) Whole-file rename, content unchanged -> Moved.
git mv src/legacy_dispatch.py src/dispatch.py
commit "Rename legacy_dispatch module to dispatch"

# (ii) Cosmetic refactor that does not change the described behavior ->
#      Changed, but the coupling still holds.
cat > src/rate_limit.py <<'EOF'
"""Per-minute request rate limiting."""


RATE_LIMIT_PER_MINUTE = 20


def should_throttle(requests_this_minute):
    return requests_this_minute >= RATE_LIMIT_PER_MINUTE
EOF
git add src/rate_limit.py
commit "Rename should_throttle parameter for clarity"

# (iii) The backoff-retry feature is removed entirely, from BOTH the code
#       and the doc -> the coupling is dead, not just drifted. The lines
#       left behind at the old anchor locations describe an unrelated,
#       still-live feature (simple_retry) -- a trap for a naive re-anchor.
cat > src/retry.py <<'EOF'
"""Retry helpers."""


def simple_retry(fn):
    try:
        return fn()
    except RuntimeError:
        return None
EOF

cat > docs/retry.md <<'EOF'
# Retry

`simple_retry` is a single-attempt fallback with no backoff.

See `src/retry.py` for the implementation.
EOF

git add src/retry.py docs/retry.md
commit "Remove backoff retry feature and its doc paragraph"
