#!/usr/bin/env bash
# grade.sh <env-dir>
# Pass: git span stale is clean; the moved dispatch anchor now points at
# src/dispatch.py (old path retired); the rate-limit span is re-anchored to
# the current lines with a non-trivial, on-topic why; the dead backoff-retry
# coupling is fully GONE (no span anywhere still anchors src/retry.py or
# docs/retry.md -- ruling out both keeping the old span and re-anchoring it,
# under any name, to the unrelated leftover text); working tree clean.
set -uo pipefail

ENV_DIR="${1:?usage: grade.sh <env-dir>}"
cd "$ENV_DIR" || { echo "FAIL: cannot cd to $ENV_DIR"; exit 1; }

fail=0
reason() { echo "$1"; }

if ! git rev-parse --git-dir >/dev/null 2>&1; then
  reason "FAIL: not a git repo"
  exit 1
fi

if [[ -n "$(git status --porcelain)" ]]; then
  reason "FAIL: working tree not clean:"
  git status --short
  fail=1
else
  reason "PASS: working tree clean"
fi

stale_out="$(git span stale 2>&1)"
stale_exit=$?
if [[ $stale_exit -ne 0 ]]; then
  reason "FAIL: git span stale exited $stale_exit (drift remains):"
  echo "$stale_out"
  fail=1
else
  reason "PASS: git span stale exits 0"
fi

porcelain="$(git span list --porcelain 2>/dev/null)"

# The corpus must end up with exactly the two surviving spans (dispatch,
# rate-limit) -- the dead backoff-retry span deleted, and no redundant
# duplicate span added alongside any of the correctly-resolved ones.
span_count="$(printf '%s\n' "$porcelain" | awk -F'\t' '{print $1}' | sort -u | wc -l)"
if (( span_count != 2 )); then
  reason "FAIL: expected exactly 2 spans in the corpus (dispatch + rate-limit; backoff-retry deleted), found $span_count:"
  printf '%s\n' "$porcelain" | awk -F'\t' '{print $1}' | sort -u
  fail=1
else
  reason "PASS: span corpus has exactly 2 spans (no duplicate/extra span added)"
fi

# --- (i) dispatch: moved anchor must now point at src/dispatch.py, old path retired ---
dispatch_span="$(printf '%s\n' "$porcelain" | awk -F'\t' '$2=="src/dispatch.py"{print $1; exit}')"
if [[ -z "$dispatch_span" ]]; then
  reason "FAIL: no span anchors src/dispatch.py"
  fail=1
else
  reason "PASS: span '$dispatch_span' anchors src/dispatch.py"
  range="$(printf '%s\n' "$porcelain" | awk -F'\t' -v s="$dispatch_span" '$1==s && $2=="src/dispatch.py"{print $3; exit}')"
  file_lines=$(wc -l < src/dispatch.py 2>/dev/null || echo 0)
  start="${range%-*}"; end="${range#*-}"
  if [[ ! "$start" =~ ^[0-9]+$ || ! "$end" =~ ^[0-9]+$ || $((start)) -lt 1 || $((end)) -gt $file_lines || $((start)) -gt $((end)) ]]; then
    reason "FAIL: src/dispatch.py anchor range '$range' invalid/out of bounds (file has $file_lines lines)"
    fail=1
  elif (( start > 4 || end < 7 )); then
    reason "FAIL: src/dispatch.py anchor range $start-$end does not cover the dispatch function (lines 4-7)"
    fail=1
  else
    reason "PASS: src/dispatch.py anchor range $start-$end covers the dispatch function"
  fi
  doc_hit="$(printf '%s\n' "$porcelain" | awk -F'\t' -v s="$dispatch_span" '$1==s && $2=="docs/dispatch.md"{print; exit}')"
  if [[ -z "$doc_hit" ]]; then
    reason "FAIL: span '$dispatch_span' no longer anchors docs/dispatch.md"
    fail=1
  else
    reason "PASS: span '$dispatch_span' still anchors docs/dispatch.md"
  fi
fi

old_dispatch_anchor="$(printf '%s\n' "$porcelain" | awk -F'\t' '$2=="src/legacy_dispatch.py"{print; exit}')"
if [[ -n "$old_dispatch_anchor" ]]; then
  reason "FAIL: an anchor on the retired src/legacy_dispatch.py still exists: $old_dispatch_anchor"
  fail=1
else
  reason "PASS: no anchor remains on retired src/legacy_dispatch.py"
fi
if [[ -e src/legacy_dispatch.py ]]; then
  reason "FAIL: src/legacy_dispatch.py still exists on disk"
  fail=1
fi

# --- (ii) rate-limit: re-anchored to current lines, why intact and on-topic ---
rl_span="$(printf '%s\n' "$porcelain" | awk -F'\t' '$2=="src/rate_limit.py"{print $1; exit}')"
if [[ -z "$rl_span" ]]; then
  reason "FAIL: no span anchors src/rate_limit.py"
  fail=1
else
  reason "PASS: span '$rl_span' anchors src/rate_limit.py"
  range="$(printf '%s\n' "$porcelain" | awk -F'\t' -v s="$rl_span" '$1==s && $2=="src/rate_limit.py"{print $3; exit}')"
  file_lines=$(wc -l < src/rate_limit.py 2>/dev/null || echo 0)
  start="${range%-*}"; end="${range#*-}"
  if [[ ! "$start" =~ ^[0-9]+$ || ! "$end" =~ ^[0-9]+$ || $((start)) -lt 1 || $((end)) -gt $file_lines || $((start)) -gt $((end)) ]]; then
    reason "FAIL: src/rate_limit.py anchor range '$range' invalid/out of bounds (file has $file_lines lines)"
    fail=1
  elif (( start > 7 || end < 8 )); then
    reason "FAIL: src/rate_limit.py anchor range $start-$end does not cover should_throttle (lines 7-8)"
    fail=1
  else
    reason "PASS: src/rate_limit.py anchor range $start-$end covers should_throttle"
  fi
  doc_hit="$(printf '%s\n' "$porcelain" | awk -F'\t' -v s="$rl_span" '$1==s && $2=="docs/rate_limit.md"{print; exit}')"
  if [[ -z "$doc_hit" ]]; then
    reason "FAIL: span '$rl_span' no longer anchors docs/rate_limit.md"
    fail=1
  else
    reason "PASS: span '$rl_span' still anchors docs/rate_limit.md"
  fi

  why_out="$(git span why "$rl_span" 2>/dev/null | sed '/^[[:space:]]*$/d')"
  why_lc="$(printf '%s' "$why_out" | tr '[:upper:]' '[:lower:]')"
  if [[ -z "$why_out" ]]; then
    reason "FAIL: span '$rl_span' has an empty why"
    fail=1
  elif [[ "$why_out" != *" "* || ${#why_out} -le 20 ]]; then
    reason "FAIL: span '$rl_span' why is too short/trivial: '$why_out'"
    fail=1
  elif [[ "$why_lc" != *"rate"* && "$why_lc" != *"throttl"* && "$why_lc" != *"minute"* ]]; then
    reason "FAIL: span '$rl_span' why no longer looks on-topic for rate limiting: '$why_out'"
    fail=1
  else
    reason "PASS: span '$rl_span' why intact and on-topic: $why_out"
  fi
fi

# --- (iii) backoff-retry: coupling is dead. No span anywhere may still
#     anchor src/retry.py or docs/retry.md -- this rules out both leaving
#     the old span in place AND re-anchoring it (under any name) to the
#     unrelated simple_retry text left behind at the same line numbers. ---
retry_hits="$(printf '%s\n' "$porcelain" | awk -F'\t' '$2=="src/retry.py" || $2=="docs/retry.md"{print}')"
if [[ -n "$retry_hits" ]]; then
  reason "FAIL: a span still anchors the retired backoff-retry files (should be deleted, not re-anchored):"
  echo "$retry_hits"
  fail=1
else
  reason "PASS: no span anchors src/retry.py or docs/retry.md (dead coupling fully retired)"
fi

# Sanity: the unrelated, still-live simple_retry feature must be untouched.
if [[ ! -f src/retry.py ]] || ! grep -q "simple_retry" src/retry.py; then
  reason "FAIL: src/retry.py's surviving simple_retry function was disturbed"
  fail=1
fi
if [[ ! -f docs/retry.md ]] || ! grep -q "simple_retry" docs/retry.md; then
  reason "FAIL: docs/retry.md's surviving simple_retry paragraph was disturbed"
  fail=1
fi

if [[ $fail -eq 0 ]]; then
  echo "PASS: triage-mixed-drift satisfied"
  exit 0
else
  echo "FAIL: triage-mixed-drift not satisfied"
  exit 1
fi
