You are working in a small git repository in the current directory. It has a
`.span/` directory tracking several couplings between files (implicit
semantic dependencies that no schema or test enforces).

First, read `{{SKILL_PATH}}` for guidance on how to work with these spans.
Beyond that file, consult only `git span --help` and its subcommands'
`--help` output (e.g. `git span add --help`) — do not read any other
documentation.

Several spans in this repository have drifted since they were declared, and
they haven't drifted for the same reason. For each one, look at what
actually happened in the repository — not just what `git span stale` says —
and use your judgment about what a correct, truthful outcome looks like:

- If the coupling still genuinely holds, bring the span back in sync with
  where things stand now.
- If the coupling no longer describes anything real, don't keep pretending
  it does — remove the record rather than pointing it at something
  unrelated.

When you're done, span tracking in this repository should be fully
consistent and truthful: `git span stale` should report no drift, every
remaining span should describe a real, current coupling, and the working
tree should be committed with no leftover changes.
