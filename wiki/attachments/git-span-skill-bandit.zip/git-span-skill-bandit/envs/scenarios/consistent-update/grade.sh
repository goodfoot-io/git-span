#!/usr/bin/env bash
# grade.sh <env-dir>
# Pass: RETRY_LIMIT is 7 in src/config.py AND the doc's prose says 7 (not
# still 5 anywhere), the span still anchors both current lines, git span
# stale is clean, and the working tree is fully committed. Fails on a
# one-sided edit (code only / doc only), a two-sided edit that leaves the
# span drifted, or anything left uncommitted.
set -uo pipefail

ENV_DIR="${1:?usage: grade.sh <env-dir>}"
cd "$ENV_DIR" || { echo "FAIL: cannot cd to $ENV_DIR"; exit 1; }

fail=0
reason() { echo "$1"; }

if ! git rev-parse --git-dir >/dev/null 2>&1; then
  reason "FAIL: not a git repo"
  exit 1
fi

if [[ -n "$(git status --porcelain)" ]]; then
  reason "FAIL: working tree not clean:"
  git status --short
  fail=1
else
  reason "PASS: working tree clean"
fi

# Code side: the constant must now be 7.
if [[ ! -f src/config.py ]]; then
  reason "FAIL: src/config.py is missing"
  fail=1
elif grep -qE '^RETRY_LIMIT[[:space:]]*=[[:space:]]*7[[:space:]]*$' src/config.py; then
  reason "PASS: src/config.py has RETRY_LIMIT = 7"
elif grep -qE '^RETRY_LIMIT[[:space:]]*=[[:space:]]*5[[:space:]]*$' src/config.py; then
  reason "FAIL: src/config.py still has RETRY_LIMIT = 5 (code not updated)"
  fail=1
else
  reason "FAIL: src/config.py does not have RETRY_LIMIT = 7 (found: $(grep RETRY_LIMIT src/config.py || echo 'no RETRY_LIMIT line'))"
  fail=1
fi

# Doc side: prose must say 7, and must not still say 5.
if [[ ! -f docs/config.md ]]; then
  reason "FAIL: docs/config.md is missing"
  fail=1
else
  doc_lc="$(tr '[:upper:]' '[:lower:]' < docs/config.md)"
  if [[ "$doc_lc" == *"5 times"* ]]; then
    reason "FAIL: docs/config.md still says '5 times' (doc not updated)"
    fail=1
  elif [[ "$doc_lc" == *"7 times"* ]]; then
    reason "PASS: docs/config.md says '7 times'"
  else
    reason "FAIL: docs/config.md does not say '7 times' anywhere"
    fail=1
  fi
fi

# Span must still cover both current lines.
stale_out="$(git span stale 2>&1)"
stale_exit=$?
if [[ $stale_exit -ne 0 ]]; then
  reason "FAIL: git span stale exited $stale_exit (drift remains):"
  echo "$stale_out"
  fail=1
else
  reason "PASS: git span stale exits 0"
fi

porcelain="$(git span list --porcelain 2>/dev/null)"

# The corpus must still be exactly the original span set -- the update must
# edit/re-anchor the existing span, not add a sibling duplicate (or any
# other new span) alongside it.
EXPECTED_SPANS="ops/retry-limit-doc-sync"
actual_spans="$(printf '%s\n' "$porcelain" | awk -F'\t' '{print $1}' | sort -u)"
expected_sorted="$(printf '%s\n' "$EXPECTED_SPANS" | tr ' ' '\n' | sort -u)"
if [[ "$actual_spans" != "$expected_sorted" ]]; then
  reason "FAIL: span corpus changed shape -- expected exactly [$EXPECTED_SPANS], found:"
  printf '%s\n' "$actual_spans"
  fail=1
else
  reason "PASS: span corpus is still exactly [$EXPECTED_SPANS] (no duplicate/extra span added)"
fi

target="$(printf '%s\n' "$porcelain" | awk -F'\t' '$2=="src/config.py"{print $1; exit}')"
if [[ -z "$target" ]]; then
  reason "FAIL: no span anchors src/config.py"
  fail=1
else
  reason "PASS: span '$target' anchors src/config.py"
  doc_hit="$(printf '%s\n' "$porcelain" | awk -F'\t' -v s="$target" '$1==s && $2=="docs/config.md"{print; exit}')"
  if [[ -z "$doc_hit" ]]; then
    reason "FAIL: span '$target' no longer anchors docs/config.md"
    fail=1
  else
    reason "PASS: span '$target' still anchors docs/config.md"
  fi

  py_range="$(printf '%s\n' "$porcelain" | awk -F'\t' -v s="$target" '$1==s && $2=="src/config.py"{print $3; exit}')"
  py_lines=$(wc -l < src/config.py 2>/dev/null || echo 0)
  p_start="${py_range%-*}"; p_end="${py_range#*-}"
  if [[ ! "$p_start" =~ ^[0-9]+$ || ! "$p_end" =~ ^[0-9]+$ || $((p_start)) -lt 1 || $((p_end)) -gt $py_lines || $((p_start)) -gt $((p_end)) ]]; then
    reason "FAIL: src/config.py anchor range '$py_range' invalid/out of bounds (file has $py_lines lines)"
    fail=1
  else
    line_content="$(sed -n "${p_start},${p_end}p" src/config.py)"
    if [[ "$line_content" != *"RETRY_LIMIT"* ]]; then
      reason "FAIL: src/config.py anchor range $p_start-$p_end does not cover the RETRY_LIMIT line"
      fail=1
    else
      reason "PASS: src/config.py anchor range $p_start-$p_end covers the RETRY_LIMIT line"
    fi
  fi

  md_range="$(printf '%s\n' "$porcelain" | awk -F'\t' -v s="$target" '$1==s && $2=="docs/config.md"{print $3; exit}')"
  md_lines=$(wc -l < docs/config.md 2>/dev/null || echo 0)
  m_start="${md_range%-*}"; m_end="${md_range#*-}"
  if [[ ! "$m_start" =~ ^[0-9]+$ || ! "$m_end" =~ ^[0-9]+$ || $((m_start)) -lt 1 || $((m_end)) -gt $md_lines || $((m_start)) -gt $((m_end)) ]]; then
    reason "FAIL: docs/config.md anchor range '$md_range' invalid/out of bounds (file has $md_lines lines)"
    fail=1
  else
    line_content="$(sed -n "${m_start},${m_end}p" docs/config.md | tr '[:upper:]' '[:lower:]')"
    if [[ "$line_content" != *"7 times"* ]]; then
      reason "FAIL: docs/config.md anchor range $m_start-$m_end does not cover the '7 times' sentence"
      fail=1
    else
      reason "PASS: docs/config.md anchor range $m_start-$m_end covers the '7 times' sentence"
    fi
  fi
fi

if [[ $fail -eq 0 ]]; then
  echo "PASS: consistent-update satisfied"
  exit 0
else
  echo "FAIL: consistent-update not satisfied"
  exit 1
fi
