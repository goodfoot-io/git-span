You are working in a small git repository in the current directory. It has a
`.span/` directory tracking a coupling between files (an implicit semantic
dependency that no schema or test enforces).

First, read `{{SKILL_PATH}}` for guidance on how to work with these spans.
Beyond that file, consult only `git span --help` and its subcommands'
`--help` output (e.g. `git span add --help`) — do not read any other
documentation.

Product change request: raise the retry limit to 7. Make the change and
keep the repository fully consistent — `git span stale` must stay clean
afterward, and the documentation must stay truthful (it should describe the
new limit, not the old one).

When you are done, commit your work so the working tree is clean.
