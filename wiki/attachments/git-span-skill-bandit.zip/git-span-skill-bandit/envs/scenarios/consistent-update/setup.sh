#!/usr/bin/env bash
# setup.sh <dest-dir>
#
# Builds a tiny fixture repo with ONE already-declared, currently-CLEAN span
# coupling a retry-limit constant to a doc sentence that restates its value.
# The task (given separately, in task-prompt.md) asks the agent to change
# the value as a product request -- the trap is editing only one side, or
# editing both but leaving the span drifted / uncommitted.
set -euo pipefail

DEST="${1:?usage: setup.sh <dest-dir>}"
mkdir -p "$DEST"
cd "$DEST"

export GIT_AUTHOR_NAME=fixture
export GIT_AUTHOR_EMAIL=fixture@test
export GIT_COMMITTER_NAME=fixture
export GIT_COMMITTER_EMAIL=fixture@test

COMMIT_MIN=0
commit() {
  COMMIT_MIN=$((COMMIT_MIN + 1))
  local d
  d=$(printf "2020-01-01T00:%02d:00Z" "$COMMIT_MIN")
  GIT_AUTHOR_DATE="$d" GIT_COMMITTER_DATE="$d" git commit -q -m "$1"
}

git init -q -b main
git config user.name fixture
git config user.email fixture@test

mkdir -p src docs

cat > src/config.py <<'EOF'
"""Service configuration constants."""

RETRY_LIMIT = 5
EOF

cat > docs/config.md <<'EOF'
# Configuration

The service retries failed operations up to 5 times before giving up.

See `src/config.py` for the value.
EOF

git add src docs
commit "Add service configuration with retry limit"

git span add ops/retry-limit-doc-sync \
  src/config.py#L3-L3 \
  docs/config.md#L3-L3 >/dev/null
git span why ops/retry-limit-doc-sync \
  -m "Retry limit constant whose value the doc restates for operators." >/dev/null

git add .span
commit "Declare retry limit doc-sync span"
