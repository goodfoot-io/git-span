#!/usr/bin/env bash
# grade.sh <env-dir>
# Pass: a new span (beyond the pre-existing "ops/logging-event-doc-sync")
# exists with a valid kebab-case name, has >=2 anchors landing on
# src/constants.py and README.md and covering the coupled lines (constants
# line 3, README line 3), a non-trivial prose why, git span stale is clean,
# and everything is committed.
set -uo pipefail

ENV_DIR="${1:?usage: grade.sh <env-dir>}"
cd "$ENV_DIR" || { echo "FAIL: cannot cd to $ENV_DIR"; exit 1; }

fail=0
reason() { echo "$1"; }
PRE_EXISTING="ops/logging-event-doc-sync"

if ! git rev-parse --git-dir >/dev/null 2>&1; then
  reason "FAIL: not a git repo"
  exit 1
fi

if [[ -n "$(git status --porcelain)" ]]; then
  reason "FAIL: working tree not clean:"
  git status --short
  fail=1
else
  reason "PASS: working tree clean"
fi

stale_out="$(git span stale 2>&1)"
stale_exit=$?
if [[ $stale_exit -ne 0 ]]; then
  reason "FAIL: git span stale exited $stale_exit (drift remains):"
  echo "$stale_out"
  fail=1
else
  reason "PASS: git span stale exits 0"
fi

porcelain="$(git span list --porcelain 2>/dev/null)"
all_spans="$(printf '%s\n' "$porcelain" | awk -F'\t' '{print $1}' | sort -u)"

new_spans="$(printf '%s\n' "$all_spans" | grep -v -x "$PRE_EXISTING" || true)"
if [[ -z "$new_spans" ]]; then
  reason "FAIL: no new span was declared beyond '$PRE_EXISTING'"
  fail=1
  exit 1
fi

# Exactly one new span, not a redundant duplicate declaration of the same
# coupling under a second new name.
new_span_count="$(printf '%s\n' "$new_spans" | grep -c .)"
if (( new_span_count > 1 )); then
  reason "FAIL: expected exactly 1 new span beyond '$PRE_EXISTING', found $new_span_count (redundant duplicate declaration):"
  printf '%s\n' "$new_spans"
  fail=1
fi

# Find a new span that anchors both coupled files.
target=""
for s in $new_spans; do
  has_const="$(printf '%s\n' "$porcelain" | awk -F'\t' -v s="$s" '$1==s && $2=="src/constants.py"{print; exit}')"
  has_readme="$(printf '%s\n' "$porcelain" | awk -F'\t' -v s="$s" '$1==s && $2=="README.md"{print; exit}')"
  if [[ -n "$has_const" && -n "$has_readme" ]]; then
    target="$s"
    break
  fi
done

if [[ -z "$target" ]]; then
  reason "FAIL: no new span anchors both src/constants.py and README.md. New spans found:"
  printf '%s\n' "$new_spans"
  fail=1
else
  reason "PASS: new span '$target' anchors both src/constants.py and README.md"

  # Name grammar: kebab-case segments separated by '/'.
  if [[ ! "$target" =~ ^[a-z0-9]+(-[a-z0-9]+)*(/[a-z0-9]+(-[a-z0-9]+)*)*$ ]]; then
    reason "FAIL: span name '$target' does not look like valid kebab-case (slug or slug/slug)"
    fail=1
  else
    reason "PASS: span name '$target' matches kebab-case grammar"
  fi

  anchor_count="$(printf '%s\n' "$porcelain" | awk -F'\t' -v s="$target" '$1==s' | wc -l)"
  if (( anchor_count < 2 )); then
    reason "FAIL: span '$target' has only $anchor_count anchor(s), need >=2"
    fail=1
  else
    reason "PASS: span '$target' has $anchor_count anchors"
  fi

  const_range="$(printf '%s\n' "$porcelain" | awk -F'\t' -v s="$target" '$1==s && $2=="src/constants.py"{print $3; exit}')"
  const_lines=$(wc -l < src/constants.py)
  c_start="${const_range%-*}"
  c_end="${const_range#*-}"
  if [[ -z "$c_start" || -z "$c_end" || ! "$c_start" =~ ^[0-9]+$ || ! "$c_end" =~ ^[0-9]+$ ]]; then
    reason "FAIL: could not parse constants.py anchor range '$const_range'"
    fail=1
  elif (( c_start < 1 || c_end > const_lines || c_start > c_end )); then
    reason "FAIL: constants.py anchor range $c_start-$c_end out of bounds (file has $const_lines lines)"
    fail=1
  elif (( c_start > 3 || c_end < 3 )); then
    reason "FAIL: constants.py anchor range $c_start-$c_end does not cover line 3 (MAX_RETRIES)"
    fail=1
  else
    reason "PASS: constants.py anchor range $c_start-$c_end covers MAX_RETRIES"
  fi

  readme_range="$(printf '%s\n' "$porcelain" | awk -F'\t' -v s="$target" '$1==s && $2=="README.md"{print $3; exit}')"
  readme_lines=$(wc -l < README.md)
  r_start="${readme_range%-*}"
  r_end="${readme_range#*-}"
  if [[ -z "$r_start" || -z "$r_end" || ! "$r_start" =~ ^[0-9]+$ || ! "$r_end" =~ ^[0-9]+$ ]]; then
    reason "FAIL: could not parse README.md anchor range '$readme_range'"
    fail=1
  elif (( r_start < 1 || r_end > readme_lines || r_start > r_end )); then
    reason "FAIL: README.md anchor range $r_start-$r_end out of bounds (file has $readme_lines lines)"
    fail=1
  elif (( r_start > 3 || r_end < 3 )); then
    reason "FAIL: README.md anchor range $r_start-$r_end does not cover line 3 (the '5 times' sentence)"
    fail=1
  else
    reason "PASS: README.md anchor range $r_start-$r_end covers the retry-count sentence"
  fi

  why_out="$(git span why "$target" 2>/dev/null | sed '/^[[:space:]]*$/d')"
  why_len=${#why_out}
  if [[ -z "$why_out" ]]; then
    reason "FAIL: span '$target' has an empty why"
    fail=1
  elif [[ "$why_out" != *" "* ]]; then
    reason "FAIL: span '$target' why has no spaces (looks like a filename restatement): '$why_out'"
    fail=1
  elif (( why_len <= 20 )); then
    reason "FAIL: span '$target' why is too short ($why_len chars): '$why_out'"
    fail=1
  else
    reason "PASS: span '$target' why is non-trivial prose: $why_out"
  fi
fi

if [[ $fail -eq 0 ]]; then
  echo "PASS: declare-coupling satisfied"
  exit 0
else
  echo "FAIL: declare-coupling not satisfied"
  exit 1
fi
