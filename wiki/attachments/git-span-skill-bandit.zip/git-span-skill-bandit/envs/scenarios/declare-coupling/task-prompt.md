You are working in a small git repository in the current directory. It has a
`.span/` directory tracking couplings between files (implicit semantic
dependencies — line ranges in code or prose that no schema or test enforces
but that must be kept consistent by hand).

First, read `{{SKILL_PATH}}` for guidance on how to work with these spans.
Beyond that file, consult only `git span --help` and its subcommands'
`--help` output (e.g. `git span add --help`) — do not read any other
documentation.

This repository already has one span declared. Look at the rest of the
repository's files and find a value that is duplicated in two places — a
constant defined in the source code and restated in prose in a doc — where
changing one without the other would leave them silently inconsistent. That
relationship is real but currently undeclared.

Declare it as a new span:

- Give it a name that fits the existing naming convention used by the span
  already in the repository.
- Anchor it at the two locations that hold the coupled value (the constant's
  definition and the doc's restatement of it).
- Give it a one-sentence why that describes the relationship the anchors
  form, not just a restatement of the file names.
- Commit the new span so the working tree is clean.

When you are done, `git span stale` should still report no drift anywhere in
the repository.
