#!/usr/bin/env bash
# setup.sh <dest-dir>
#
# Builds a tiny fixture repo with one already-declared span (logging
# source/doc sync, so the .span/ corpus is non-empty) and one obvious,
# UNDECLARED coupling: a constants file's MAX_RETRIES value and a README
# sentence that restates the same number in prose. The task is to notice
# and declare that second coupling as a new span.
set -euo pipefail

DEST="${1:?usage: setup.sh <dest-dir>}"
mkdir -p "$DEST"
cd "$DEST"

export GIT_AUTHOR_NAME=fixture
export GIT_AUTHOR_EMAIL=fixture@test
export GIT_COMMITTER_NAME=fixture
export GIT_COMMITTER_EMAIL=fixture@test

COMMIT_MIN=0
commit() {
  COMMIT_MIN=$((COMMIT_MIN + 1))
  local d
  d=$(printf "2020-01-01T00:%02d:00Z" "$COMMIT_MIN")
  GIT_AUTHOR_DATE="$d" GIT_COMMITTER_DATE="$d" git commit -q -m "$1"
}

git init -q -b main
git config user.name fixture
git config user.email fixture@test

mkdir -p src docs

cat > src/constants.py <<'EOF'
"""Shared service constants."""

MAX_RETRIES = 5
REQUEST_TIMEOUT_SECONDS = 30
EOF

cat > README.md <<'EOF'
# Widget Service

This service retries failed requests 5 times before giving up.

Configuration lives in `src/constants.py`.
EOF

cat > src/logging.py <<'EOF'
"""Structured logging helper."""


def log_event(name, **fields):
    payload = {"event": name, **fields}
    print(payload)
EOF

cat > docs/logging.md <<'EOF'
# Logging

Events are logged as flat JSON objects via `log_event`.

See `src/logging.py` for the implementation.
EOF

git add src docs README.md
commit "Add constants, README, and logging helper"

git span add ops/logging-event-doc-sync \
  src/logging.py#L4-L6 \
  docs/logging.md#L3-L3 >/dev/null
git span why ops/logging-event-doc-sync \
  -m "Logging helper whose emitted event shape the doc describes for readers." >/dev/null

git add .span
commit "Declare logging event/doc sync span"
