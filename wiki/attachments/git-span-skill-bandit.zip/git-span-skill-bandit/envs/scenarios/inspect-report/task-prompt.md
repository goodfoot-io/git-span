You are working in a small git repository in the current directory. It has a
`.span/` directory tracking several couplings between files (implicit
semantic dependencies that no schema or test enforces).

First, read `{{SKILL_PATH}}` for guidance on how to work with these spans.
Beyond that file, consult only `git span --help` and its subcommands'
`--help` output (e.g. `git span list --help`) — do not read any other
documentation.

This is a read-only investigation task — do not modify any file other than
the one answers file described below, and do not commit anything.

Answer these four questions by inspecting the span corpus (`list`, `show`,
`why`, `history`, etc.), and write your answers to a new file named
`ANSWERS.md` in the current directory, with each answer clearly labeled by
number:

1. Which span or spans anchor `docs/auth.md`?
2. What is the why of the span `cache/ttl-config-sync`?
3. How many anchors does the span `cache/eviction-doc-sync` have?
4. Which span's why was changed after it was first declared (check each
   span's history)?
