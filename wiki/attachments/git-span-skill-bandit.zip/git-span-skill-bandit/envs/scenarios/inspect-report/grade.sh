#!/usr/bin/env bash
# grade.sh <env-dir>
# Pass: ANSWERS.md exists in the env dir and its labeled answers 1-4 match
# the known ground truth via lenient, case-insensitive substring/token
# matching. Repo mutations are ignored (this scenario is read-only by
# design, but the grader itself never inspects git state).
set -uo pipefail

ENV_DIR="${1:?usage: grade.sh <env-dir>}"
ANSWERS="$ENV_DIR/ANSWERS.md"

fail=0
reason() { echo "$1"; }

if [[ ! -f "$ANSWERS" ]]; then
  reason "FAIL: $ANSWERS does not exist"
  exit 1
fi

content="$(cat "$ANSWERS")"
lower="$(printf '%s' "$content" | tr '[:upper:]' '[:lower:]')"

# Split into per-question sections by finding lines that start a numbered
# answer (tolerating "1.", "1)", "**1.", "### 1", "Q1", etc.). Falls back to
# the whole document for a question if no such marker is found.
section_for() {
  local n="$1"
  awk -v n="$n" '
    BEGIN { cur = 0; }
    {
      line = $0
      stripped = line
      gsub(/^[[:space:]]*[#*]*[[:space:]]*/, "", stripped)
      if (match(stripped, "^[Qq]?" n "[.):][[:space:]]*")) {
        cur = n
        print substr(stripped, RLENGTH + 1)
        next
      } else if (match(stripped, /^[Qq]?[0-9]+[.):][[:space:]]*/)) {
        cur = 0
        next
      }
      if (cur == n) print line
    }
  ' <<<"$content"
}

s1="$(section_for 1 | tr '[:upper:]' '[:lower:]')"
[[ -z "$s1" ]] && s1="$lower"
s2="$(section_for 2 | tr '[:upper:]' '[:lower:]')"
[[ -z "$s2" ]] && s2="$lower"
s3="$(section_for 3 | tr '[:upper:]' '[:lower:]')"
[[ -z "$s3" ]] && s3="$lower"
s4="$(section_for 4 | tr '[:upper:]' '[:lower:]')"
[[ -z "$s4" ]] && s4="$lower"

# Q1: docs/auth.md is anchored by both auth/token-issuance-doc-sync and
# auth/session-expiry-doc-sync.
if [[ "$s1" == *"token-issuance"* && "$s1" == *"session-expiry"* ]]; then
  reason "PASS: Q1 names both spans anchoring docs/auth.md"
else
  reason "FAIL: Q1 does not name both 'token-issuance' and 'session-expiry' spans. Section text: $s1"
  fail=1
fi

# Q2: why of cache/ttl-config-sync is
# "Cache TTL constant whose value the config file must mirror."
if [[ "$s2" == *"ttl"* && "$s2" == *"config"* && ( "$s2" == *"mirror"* || "$s2" == *"match"* || "$s2" == *"track"* || "$s2" == *"sync"* || "$s2" == *"consisten"* ) ]]; then
  reason "PASS: Q2 captures the cache/ttl-config-sync why"
else
  reason "FAIL: Q2 does not look like the cache/ttl-config-sync why. Section text: $s2"
  fail=1
fi

# Q3: cache/eviction-doc-sync has 3 anchors.
if [[ "$s3" =~ (^|[^0-9])3([^0-9]|$) ]] || [[ "$s3" == *"three"* ]]; then
  reason "PASS: Q3 answers 3 anchors"
else
  reason "FAIL: Q3 does not state 3 (or 'three') anchors. Section text: $s3"
  fail=1
fi

# Q4: auth/token-issuance-doc-sync's why was changed after creation.
if [[ "$s4" == *"token-issuance"* ]]; then
  reason "PASS: Q4 names auth/token-issuance-doc-sync"
else
  reason "FAIL: Q4 does not name 'token-issuance'. Section text: $s4"
  fail=1
fi

if [[ $fail -eq 0 ]]; then
  echo "PASS: inspect-report satisfied"
  exit 0
else
  echo "FAIL: inspect-report not satisfied"
  exit 1
fi
