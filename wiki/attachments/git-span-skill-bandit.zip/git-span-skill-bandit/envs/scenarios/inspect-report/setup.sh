#!/usr/bin/env bash
# setup.sh <dest-dir>
#
# Builds a small fixture repo with five spans across auth/cache/version
# concerns, some sharing anchor files, declared across several commits. One
# span's why is revised in a later commit (after its initial declaration) so
# `git span history` shows a why-only change. This scenario is read-only for
# the agent under test: it should answer questions about the corpus without
# mutating the repo.
set -euo pipefail

DEST="${1:?usage: setup.sh <dest-dir>}"
mkdir -p "$DEST"
cd "$DEST"

export GIT_AUTHOR_NAME=fixture
export GIT_AUTHOR_EMAIL=fixture@test
export GIT_COMMITTER_NAME=fixture
export GIT_COMMITTER_EMAIL=fixture@test

COMMIT_MIN=0
commit() {
  COMMIT_MIN=$((COMMIT_MIN + 1))
  local d
  d=$(printf "2020-01-01T00:%02d:00Z" "$COMMIT_MIN")
  GIT_AUTHOR_DATE="$d" GIT_COMMITTER_DATE="$d" git commit -q -m "$1"
}

git init -q -b main
git config user.name fixture
git config user.email fixture@test

mkdir -p src docs config

cat > src/auth.py <<'EOF'
"""Authentication token issuance."""


def issue_token(user_id):
    return f"tok-{user_id}"


def verify_token(token):
    return token.startswith("tok-")
EOF

cat > src/session.py <<'EOF'
"""Session expiry handling."""


SESSION_TTL_SECONDS = 3600


def is_expired(created_at, now):
    return now - created_at > SESSION_TTL_SECONDS
EOF

cat > docs/auth.md <<'EOF'
# Auth

Tokens are issued as `tok-<user_id>` strings.

Sessions expire after 3600 seconds of inactivity.

See `src/auth.py` and `src/session.py` for the implementation.
EOF

cat > src/cache.py <<'EOF'
"""In-memory cache with simple TTL eviction."""


CACHE_TTL_SECONDS = 300


def evict_expired(entries, now):
    return {k: v for k, v in entries.items() if now - v.created_at < CACHE_TTL_SECONDS}
EOF

cat > docs/cache.md <<'EOF'
# Cache

Entries are evicted once older than 300 seconds.

TTL is configured via `CACHE_TTL_SECONDS` in `src/cache.py`.
EOF

cat > config/cache.yaml <<'EOF'
cache:
  ttl_seconds: 300
EOF

cat > src/version.py <<'EOF'
"""Package version."""

VERSION = "2.3.0"
EOF

cat > README.md <<'EOF'
# Widgets

Current release: 2.3.0.
EOF

git add src docs config README.md
commit "Add auth, cache, and version modules"

git span add auth/token-issuance-doc-sync \
  src/auth.py#L4-L5 \
  docs/auth.md#L3-L3 >/dev/null
git span why auth/token-issuance-doc-sync \
  -m "Token issuance format whose string shape the doc restates for API consumers." >/dev/null

git span add auth/session-expiry-doc-sync \
  src/session.py#L4-L8 \
  docs/auth.md#L5-L5 >/dev/null
git span why auth/session-expiry-doc-sync \
  -m "Session expiry window whose duration the doc restates for operators." >/dev/null

git add .span
commit "Declare auth spans"

git span add cache/eviction-doc-sync \
  src/cache.py#L4-L8 \
  docs/cache.md#L3-L3 \
  config/cache.yaml#L1-L2 >/dev/null
git span why cache/eviction-doc-sync \
  -m "Cache eviction policy whose TTL the doc and config both restate." >/dev/null

git span add cache/ttl-config-sync \
  src/cache.py#L4-L4 \
  config/cache.yaml#L2-L2 >/dev/null
git span why cache/ttl-config-sync \
  -m "Cache TTL constant whose value the config file must mirror." >/dev/null

git add .span
commit "Declare cache spans"

git span add ops/version-readme-sync \
  src/version.py#L3-L3 \
  README.md#L3-L3 >/dev/null
git span why ops/version-readme-sync \
  -m "Release version constant whose README restatement must track it." >/dev/null

git add .span
commit "Declare version/readme span"

# Revise the auth token span's why in a LATER commit, with no anchor change,
# after adding verify_token to the picture.
git span why auth/token-issuance-doc-sync \
  -m "Token issuance and verification whose shared string format the doc restates for API consumers." >/dev/null
git add .span
commit "Refine token issuance span why to cover verify_token too"
