#!/usr/bin/env bash
# setup.sh <dest-dir>
#
# Builds a tiny fixture repo with a span anchoring a `tokenize` function in
# src/legacy_parser.py plus a description of it in docs/parser.md. After the
# span is declared and committed, the module is renamed (relocated) from
# src/legacy_parser.py to src/tokenizer.py with its content unchanged, and
# that rename is committed WITHOUT touching the span — so `git span stale`
# reports the source-side anchor as moved to the new file.
set -euo pipefail

DEST="${1:?usage: setup.sh <dest-dir>}"
mkdir -p "$DEST"
cd "$DEST"

export GIT_AUTHOR_NAME=fixture
export GIT_AUTHOR_EMAIL=fixture@test
export GIT_COMMITTER_NAME=fixture
export GIT_COMMITTER_EMAIL=fixture@test

COMMIT_MIN=0
commit() {
  COMMIT_MIN=$((COMMIT_MIN + 1))
  local d
  d=$(printf "2020-01-01T00:%02d:00Z" "$COMMIT_MIN")
  GIT_AUTHOR_DATE="$d" GIT_COMMITTER_DATE="$d" git commit -q -m "$1"
}

git init -q -b main
git config user.name fixture
git config user.email fixture@test

mkdir -p src docs

cat > src/legacy_parser.py <<'EOF'
"""Legacy parser module (pending relocation)."""


def tokenize(text):
    tokens = []
    for word in text.split():
        tokens.append(word.lower())
    return tokens
EOF

cat > docs/parser.md <<'EOF'
# Parser

Input text is tokenized by lower-casing and splitting on whitespace.

See `tokenize` for the implementation.
EOF

git add src docs
commit "Add legacy parser module and its doc"

git span add parsing/tokenizer-doc-sync \
  src/legacy_parser.py#L4-L8 \
  docs/parser.md#L3-L3 >/dev/null
git span why parsing/tokenizer-doc-sync \
  -m "Tokenizer whose whitespace-splitting behavior the doc describes for readers." >/dev/null

git add .span
commit "Declare tokenizer doc-sync span"

# Relocate the module: content unchanged, just moved to a new home.
git mv src/legacy_parser.py src/tokenizer.py
commit "Relocate legacy_parser module to tokenizer"
