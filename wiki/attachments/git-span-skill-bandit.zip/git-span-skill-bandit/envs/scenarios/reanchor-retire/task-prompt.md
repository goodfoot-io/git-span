You are working in a small git repository in the current directory. It has a
`.span/` directory tracking couplings between files (implicit semantic
dependencies that no schema or test enforces).

First, read `{{SKILL_PATH}}` for guidance on how to work with these spans.
Beyond that file, consult only `git span --help` and its subcommands'
`--help` output (e.g. `git span add --help`) — do not read any other
documentation.

A module that a span anchors was relocated to a new file path, and that
relocation was committed without updating the span. Find the span affected
by this, and re-anchor it so it points at the code's new home:

- The anchor that used to point at the old file path should be retired —
  no anchor should remain pointing at the file that no longer exists.
- A new anchor should point at the same code, wherever it now lives.
- Any anchor unaffected by the move should be left as-is.
- Commit the result so the working tree is clean.

When you are done, `git span stale` should report no drift anywhere in the
repository, and no anchor should reference the retired file path.
