#!/usr/bin/env bash
# grade.sh <env-dir>
# Pass: the tokenizer span has an anchor on src/tokenizer.py covering the
# tokenize function, no anchor remains on the retired src/legacy_parser.py
# path, the doc anchor on docs/parser.md is intact, git span stale is clean,
# and everything is committed.
set -uo pipefail

ENV_DIR="${1:?usage: grade.sh <env-dir>}"
cd "$ENV_DIR" || { echo "FAIL: cannot cd to $ENV_DIR"; exit 1; }

fail=0
reason() { echo "$1"; }

if ! git rev-parse --git-dir >/dev/null 2>&1; then
  reason "FAIL: not a git repo"
  exit 1
fi

if [[ -n "$(git status --porcelain)" ]]; then
  reason "FAIL: working tree not clean:"
  git status --short
  fail=1
else
  reason "PASS: working tree clean"
fi

stale_out="$(git span stale 2>&1)"
stale_exit=$?
if [[ $stale_exit -ne 0 ]]; then
  reason "FAIL: git span stale exited $stale_exit (drift remains):"
  echo "$stale_out"
  fail=1
else
  reason "PASS: git span stale exits 0"
fi

porcelain="$(git span list --porcelain 2>/dev/null)"

# The corpus must still have exactly the original single span -- re-anchoring
# must edit the existing span in place, not add a sibling duplicate pointing
# at the relocated code alongside it.
span_count="$(printf '%s\n' "$porcelain" | awk -F'\t' '{print $1}' | sort -u | wc -l)"
if (( span_count != 1 )); then
  reason "FAIL: expected exactly 1 span in the corpus, found $span_count:"
  printf '%s\n' "$porcelain" | awk -F'\t' '{print $1}' | sort -u
  fail=1
else
  reason "PASS: span corpus still has exactly 1 span (no duplicate/extra span added)"
fi

# Identify the span that anchors src/tokenizer.py (identity may or may not
# have been kept as "parsing/tokenizer-doc-sync").
target="$(printf '%s\n' "$porcelain" | awk -F'\t' '$2=="src/tokenizer.py"{print $1; exit}')"

if [[ -z "$target" ]]; then
  reason "FAIL: no span anchors src/tokenizer.py"
  fail=1
else
  reason "PASS: span '$target' anchors src/tokenizer.py"

  range="$(printf '%s\n' "$porcelain" | awk -F'\t' -v s="$target" '$1==s && $2=="src/tokenizer.py"{print $3; exit}')"
  file_lines=$(wc -l < src/tokenizer.py 2>/dev/null || echo 0)
  start="${range%-*}"
  end="${range#*-}"
  if [[ -z "$start" || -z "$end" || ! "$start" =~ ^[0-9]+$ || ! "$end" =~ ^[0-9]+$ ]]; then
    reason "FAIL: could not parse tokenizer.py anchor range '$range'"
    fail=1
  elif (( start < 1 || end > file_lines || start > end )); then
    reason "FAIL: tokenizer.py anchor range $start-$end out of bounds (file has $file_lines lines)"
    fail=1
  elif (( start > 4 || end < 8 )); then
    reason "FAIL: tokenizer.py anchor range $start-$end does not cover the tokenize function (lines 4-8)"
    fail=1
  else
    reason "PASS: tokenizer.py anchor range $start-$end covers the tokenize function"
  fi

  doc_hit="$(printf '%s\n' "$porcelain" | awk -F'\t' -v s="$target" '$1==s && $2=="docs/parser.md"{print; exit}')"
  if [[ -z "$doc_hit" ]]; then
    reason "FAIL: span '$target' no longer anchors docs/parser.md"
    fail=1
  else
    reason "PASS: span '$target' still anchors docs/parser.md"
  fi
fi

# No span anywhere should still anchor the retired path.
stale_anchor="$(printf '%s\n' "$porcelain" | awk -F'\t' '$2=="src/legacy_parser.py"{print; exit}')"
if [[ -n "$stale_anchor" ]]; then
  reason "FAIL: an anchor on the retired src/legacy_parser.py still exists: $stale_anchor"
  fail=1
else
  reason "PASS: no anchor remains on retired src/legacy_parser.py"
fi

# The retired path itself should no longer exist in the tree.
if [[ -e src/legacy_parser.py ]]; then
  reason "FAIL: src/legacy_parser.py still exists on disk"
  fail=1
fi

if [[ $fail -eq 0 ]]; then
  echo "PASS: reanchor-retire satisfied"
  exit 0
else
  echo "FAIL: reanchor-retire not satisfied"
  exit 1
fi
