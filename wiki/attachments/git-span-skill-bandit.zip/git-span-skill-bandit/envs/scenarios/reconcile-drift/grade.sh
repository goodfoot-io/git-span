#!/usr/bin/env bash
# grade.sh <env-dir>
# Pass: git span stale is clean, the retry span still anchors src/retry.py
# (covering the edited default-attempts line) and docs/retry.md, its why is
# non-empty, and the working tree is fully committed.
set -uo pipefail

ENV_DIR="${1:?usage: grade.sh <env-dir>}"
cd "$ENV_DIR" || { echo "FAIL: cannot cd to $ENV_DIR"; exit 1; }

fail=0
reason() { echo "$1"; }

if ! git rev-parse --git-dir >/dev/null 2>&1; then
  reason "FAIL: not a git repo"
  exit 1
fi

# 1. Working tree must be fully committed.
if [[ -n "$(git status --porcelain)" ]]; then
  reason "FAIL: working tree not clean:"
  git status --short
  fail=1
else
  reason "PASS: working tree clean"
fi

# 2. git span stale must exit 0 (no drift anywhere).
stale_out="$(git span stale 2>&1)"
stale_exit=$?
if [[ $stale_exit -ne 0 ]]; then
  reason "FAIL: git span stale exited $stale_exit (drift remains):"
  echo "$stale_out"
  fail=1
else
  reason "PASS: git span stale exits 0"
fi

# 3. Find the span anchoring src/retry.py (identity may have been kept or
#    the anchor re-added under the same/different span name; we only care
#    that some span anchors both the retry source and the retry doc).
porcelain="$(git span list --porcelain 2>/dev/null)"

# The corpus must still have exactly the original two spans -- reconciling
# must edit/re-anchor the drifted span in place, not add a sibling
# duplicate alongside it while leaving (or re-touching) the original.
span_count="$(printf '%s\n' "$porcelain" | awk -F'\t' '{print $1}' | sort -u | wc -l)"
if (( span_count != 2 )); then
  reason "FAIL: expected exactly 2 spans in the corpus, found $span_count:"
  printf '%s\n' "$porcelain" | awk -F'\t' '{print $1}' | sort -u
  fail=1
else
  reason "PASS: span corpus still has exactly 2 spans (no duplicate/extra span added)"
fi

retry_span="$(printf '%s\n' "$porcelain" | awk -F'\t' '$2=="src/retry.py"{print $1; exit}')"

if [[ -z "$retry_span" ]]; then
  reason "FAIL: no span anchors src/retry.py"
  fail=1
else
  reason "PASS: span '$retry_span' anchors src/retry.py"

  # Anchor range sanity: must be a real line-range within the file's bounds
  # and must contain the edited default-attempts line (line 8).
  range="$(printf '%s\n' "$porcelain" | awk -F'\t' -v s="$retry_span" '$1==s && $2=="src/retry.py"{print $3; exit}')"
  file_lines=$(wc -l < src/retry.py)
  start="${range%-*}"
  end="${range#*-}"
  if [[ -z "$start" || -z "$end" || ! "$start" =~ ^[0-9]+$ || ! "$end" =~ ^[0-9]+$ ]]; then
    reason "FAIL: could not parse retry.py anchor range '$range'"
    fail=1
  elif (( start < 1 || end > file_lines || start > end )); then
    reason "FAIL: retry.py anchor range $start-$end is out of bounds (file has $file_lines lines)"
    fail=1
  elif (( start > 8 || end < 8 )); then
    reason "FAIL: retry.py anchor range $start-$end does not cover the edited line 8 (max_attempts)"
    fail=1
  else
    reason "PASS: retry.py anchor range $start-$end covers the edited default-attempts line"
  fi

  # The same span must still anchor the doc.
  doc_hit="$(printf '%s\n' "$porcelain" | awk -F'\t' -v s="$retry_span" '$1==s && $2=="docs/retry.md"{print; exit}')"
  if [[ -z "$doc_hit" ]]; then
    reason "FAIL: span '$retry_span' no longer anchors docs/retry.md"
    fail=1
  else
    reason "PASS: span '$retry_span' still anchors docs/retry.md"
  fi

  # Why must be non-empty.
  why_out="$(git span why "$retry_span" 2>/dev/null | sed '/^[[:space:]]*$/d')"
  if [[ -z "$why_out" ]]; then
    reason "FAIL: span '$retry_span' has an empty why"
    fail=1
  else
    reason "PASS: span '$retry_span' why is non-empty: $why_out"
  fi
fi

if [[ $fail -eq 0 ]]; then
  echo "PASS: reconcile-drift satisfied"
  exit 0
else
  echo "FAIL: reconcile-drift not satisfied"
  exit 1
fi
