You are working in a small git repository in the current directory. It has a
`.span/` directory tracking couplings between files (implicit semantic
dependencies that no schema or test enforces).

First, read `{{SKILL_PATH}}` for guidance on how to work with these spans.
Beyond that file, consult only `git span --help` and its subcommands'
`--help` output (e.g. `git span add --help`) — do not read any other
documentation.

One of the source files that a span depends on was edited after the span was
declared, and the edit was committed without updating the span. Find the span
that has drifted out of sync with its source, decide whether the coupling it
describes still holds, and bring it back into a consistent state:

- Its anchors should reflect the current content at their files (no drift
  reported for this span).
- Its why should remain an accurate one-sentence description of the coupling
  (update it only if the relationship itself changed, not just the content).
- Commit the reconciled span so the working tree is clean.

When you are done, `git span stale` should report no drift anywhere in the
repository, and there should be no uncommitted changes.
