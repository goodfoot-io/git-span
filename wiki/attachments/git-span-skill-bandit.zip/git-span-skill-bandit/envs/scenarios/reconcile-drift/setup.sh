#!/usr/bin/env bash
# setup.sh <dest-dir>
#
# Builds a tiny fixture repo with two source+doc couplings ("retry" and
# "timeout"), each declared as a git span with a why. After declaring both
# spans, the retry source file is edited (its default retry count bumped)
# and committed WITHOUT reconciling the span, so `git span stale` reports
# drift on the retry span while the timeout span stays fresh.
set -euo pipefail

DEST="${1:?usage: setup.sh <dest-dir>}"
mkdir -p "$DEST"
cd "$DEST"

export GIT_AUTHOR_NAME=fixture
export GIT_AUTHOR_EMAIL=fixture@test
export GIT_COMMITTER_NAME=fixture
export GIT_COMMITTER_EMAIL=fixture@test

COMMIT_MIN=0
commit() {
  COMMIT_MIN=$((COMMIT_MIN + 1))
  local d
  d=$(printf "2020-01-01T00:%02d:00Z" "$COMMIT_MIN")
  GIT_AUTHOR_DATE="$d" GIT_COMMITTER_DATE="$d" git commit -q -m "$1"
}

git init -q -b main
git config user.name fixture
git config user.email fixture@test

mkdir -p src docs

cat > src/retry.py <<'EOF'
"""Retry helper for flaky network calls."""


def compute_delay(attempt):
    return min(2 ** attempt, 30)


def call_with_retry(fn, max_attempts=3):
    attempt = 0
    while attempt < max_attempts:
        try:
            return fn()
        except RuntimeError:
            attempt += 1
    raise RuntimeError("exhausted retries")
EOF

cat > docs/retry.md <<'EOF'
# Retry Policy

Network calls are retried up to 3 times before giving up.

See `src/retry.py` for the implementation.
EOF

cat > src/timeout.py <<'EOF'
"""Timeout helper for slow network calls."""


def default_timeout_seconds():
    return 10


def call_with_timeout(fn, seconds=10):
    return fn(timeout=seconds)
EOF

cat > docs/timeout.md <<'EOF'
# Timeout Policy

Network calls time out after 10 seconds.

See `src/timeout.py` for the implementation.
EOF

git add src docs
commit "Add retry and timeout helpers with docs"

git span add ops/retry-behavior-doc-sync \
  src/retry.py#L8-L15 \
  docs/retry.md#L3-L3 >/dev/null
git span why ops/retry-behavior-doc-sync \
  -m "Retry policy that keeps the doc's stated attempt count matching the code's default." >/dev/null

git span add ops/timeout-behavior-doc-sync \
  src/timeout.py#L8-L9 \
  docs/timeout.md#L3-L3 >/dev/null
git span why ops/timeout-behavior-doc-sync \
  -m "Timeout policy that keeps the doc's stated deadline matching the code's default." >/dev/null

git add .span
commit "Declare retry and timeout doc-sync spans"

# Drift: bump the retry default without touching the span.
sed -i 's/def call_with_retry(fn, max_attempts=3):/def call_with_retry(fn, max_attempts=5):/' src/retry.py
git add src/retry.py
commit "Bump default retry attempts to 5"
