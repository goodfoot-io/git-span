# Scenario verification

All four scenarios were verified end-to-end by hand against the real
`git-span` CLI (`~/.local/bin/git-span`, `git span ...`). For each scenario:

1. `setup.sh` was run into two fresh dirs (`*-A`, `*-B`) and the two outputs
   were diffed (`git log --format=%s`, `.span/`, and every source dir the
   scenario creates) to confirm determinism.
2. `grade.sh` was run against the **unsolved** `*-A` dir and confirmed to
   exit non-zero (except `inspect-report`, which fails because `ANSWERS.md`
   is missing, as expected).
3. The intended solution was performed by hand with the real CLI against
   `*-B`, then `grade.sh` was run against it and confirmed to exit 0.

All commands below were actually run in this session; output is trimmed to
the salient lines.

## 1. reconcile-drift

Setup declares two spans (`ops/retry-behavior-doc-sync`,
`ops/timeout-behavior-doc-sync`), then bumps `max_attempts` in
`src/retry.py` (inside the retry span's anchor) without reconciling.

```
$ bash setup.sh reconcile-drift-A
$ bash setup.sh reconcile-drift-B
$ diff <(git -C A log --format=%s) <(git -C B log --format=%s)   # identical
$ diff -r A/.span B/.span                                        # identical
$ diff -r A/src B/src; diff -r A/docs B/docs                      # identical

$ bash grade.sh reconcile-drift-A
PASS: working tree clean
FAIL: git span stale exited 1 (drift remains): ... src/retry.py#L8-L15 — changed
FAIL: reconcile-drift not satisfied
grade exit=1

# Solution, against B:
$ git span add ops/retry-behavior-doc-sync src/retry.py#L8-L15
Added 0 anchors and resolved 1 in place ... (hash changed)
$ git span why ops/retry-behavior-doc-sync -m "Retry policy that keeps the doc's stated attempt count matching the code's default."
$ git add .span && git commit -m "Reconcile retry span after bumping default attempts"

$ bash grade.sh reconcile-drift-B
PASS: working tree clean
PASS: git span stale exits 0
PASS: span 'ops/retry-behavior-doc-sync' anchors src/retry.py
PASS: retry.py anchor range 8-15 covers the edited default-attempts line
PASS: span 'ops/retry-behavior-doc-sync' still anchors docs/retry.md
PASS: span 'ops/retry-behavior-doc-sync' why is non-empty: ...
PASS: reconcile-drift satisfied
grade exit=0
```

## 2. declare-coupling

Setup declares one unrelated span (`ops/logging-event-doc-sync`) and leaves
an obvious undeclared coupling: `MAX_RETRIES = 5` in `src/constants.py` and
"retries failed requests 5 times" in `README.md`.

```
$ bash setup.sh declare-coupling-A
$ bash setup.sh declare-coupling-B
$ diff <(git -C A log --format=%s) <(git -C B log --format=%s)   # identical
$ diff -r A/.span B/.span                                        # identical

$ bash grade.sh declare-coupling-A
PASS: working tree clean
PASS: git span stale exits 0
FAIL: no new span was declared beyond 'ops/logging-event-doc-sync'
grade exit=1

# Solution, against B:
$ git span add ops/retry-count-doc-sync src/constants.py#L3-L3 README.md#L3-L3
Added 2 anchors to span `ops/retry-count-doc-sync`.
$ git span why ops/retry-count-doc-sync -m "Retry count constant whose value the README's prose statement must keep matching."
$ git add .span && git commit -m "Declare retry count doc-sync span"

$ bash grade.sh declare-coupling-B
PASS: working tree clean
PASS: git span stale exits 0
PASS: new span 'ops/retry-count-doc-sync' anchors both src/constants.py and README.md
PASS: span name 'ops/retry-count-doc-sync' matches kebab-case grammar
PASS: span 'ops/retry-count-doc-sync' has 2 anchors
PASS: constants.py anchor range 3-3 covers MAX_RETRIES
PASS: README.md anchor range 3-3 covers the retry-count sentence
PASS: span 'ops/retry-count-doc-sync' why is non-trivial prose: ...
PASS: declare-coupling satisfied
grade exit=0
```

## 3. reanchor-retire

Setup declares `parsing/tokenizer-doc-sync` anchoring `src/legacy_parser.py`
(the `tokenize` function) and `docs/parser.md`, then relocates the module
with `git mv src/legacy_parser.py src/tokenizer.py` (content unchanged) and
commits, without touching the span. `git span stale` reports the anchor as
`moved to src/tokenizer.py#L4-L8` — a genuine git-detected rename, not a
tool bug.

```
$ bash setup.sh reanchor-retire-A
$ bash setup.sh reanchor-retire-B
$ diff <(git -C A log --format=%s) <(git -C B log --format=%s)   # identical
$ diff -r A/.span B/.span                                        # identical

$ bash grade.sh reanchor-retire-A
PASS: working tree clean
FAIL: git span stale exited 1 (drift remains): ... moved to src/tokenizer.py#L4-L8
FAIL: no span anchors src/tokenizer.py
FAIL: an anchor on the retired src/legacy_parser.py still exists: ...
FAIL: reanchor-retire not satisfied
grade exit=1

# Solution, against B:
$ git span remove parsing/tokenizer-doc-sync src/legacy_parser.py#L4-L8
$ git span add parsing/tokenizer-doc-sync src/tokenizer.py#L4-L8
$ git span why parsing/tokenizer-doc-sync -m "Tokenizer whose whitespace-splitting behavior the doc describes for readers."
$ git add .span && git commit -m "Re-anchor tokenizer span to its relocated module"

$ bash grade.sh reanchor-retire-B
PASS: working tree clean
PASS: git span stale exits 0
PASS: span 'parsing/tokenizer-doc-sync' anchors src/tokenizer.py
PASS: tokenizer.py anchor range 4-8 covers the tokenize function
PASS: span 'parsing/tokenizer-doc-sync' still anchors docs/parser.md
PASS: no anchor remains on retired src/legacy_parser.py
PASS: reanchor-retire satisfied
grade exit=0
```

## 4. inspect-report

Setup declares five spans across auth/cache/version concerns (some sharing
`docs/auth.md`, `src/cache.py`, `config/cache.yaml`), and revises
`auth/token-issuance-doc-sync`'s why in a later, anchor-untouched commit
(confirmed via `git span history --format json`: two commits, the second
with `"anchors": []` and a new `"why"`). This scenario is read-only.

```
$ bash setup.sh inspect-report-A
$ bash setup.sh inspect-report-B
$ diff <(git -C A log --format=%s) <(git -C B log --format=%s)   # identical
$ diff -r A/.span B/.span; diff -r A/src B/src; diff -r A/docs B/docs; diff -r A/config B/config   # all identical

$ bash grade.sh inspect-report-A
FAIL: .../inspect-report-A/ANSWERS.md does not exist
grade exit=1

# Solution, against B (ANSWERS.md written by hand from `list`/`why`/`history`):
$ cat > ANSWERS.md <<'EOF'
1. auth/token-issuance-doc-sync and auth/session-expiry-doc-sync both anchor docs/auth.md.
2. Cache TTL constant whose value the config file must mirror.
3. cache/eviction-doc-sync has 3 anchors.
4. auth/token-issuance-doc-sync's why was changed after it was first declared.
EOF

$ bash grade.sh inspect-report-B
PASS: Q1 names both spans anchoring docs/auth.md
PASS: Q2 captures the cache/ttl-config-sync why
PASS: Q3 answers 3 anchors
PASS: Q4 names auth/token-issuance-doc-sync
PASS: inspect-report satisfied
grade exit=0
```

Additional negative check on `inspect-report`: an `ANSWERS.md` with four
plausible-but-wrong answers (wrong span for Q1, off-topic prose for Q2,
wrong count for Q3, wrong span for Q4) was graded and correctly failed all
four checks — confirming the lenient substring matcher isn't a rubber stamp.
The matcher also tolerates label-formatting variance (`**1.**`, `Q2:`,
`### 3`, `4)`) since graders must not depend on any particular skill's
output style.

## CLI surprises encountered while building these scenarios

- `git span stale <name> --fix` is correctly a no-op on a `Changed` anchor
  whose content differs beyond whitespace (by design — the docs say a
  meaning-altering edit stays drifting until a human re-anchors with
  `git span add`). Confirmed this directly and designed `reconcile-drift`'s
  edit to be a real content change so the task exercises the intended
  `add`-based reconciliation path, not the `--fix` shortcut.
- "Moved" detection is tied to git's own rename pairing (a fully deleted old
  path paired with a similar-content new path), not to independent content
  search across the repo. A *partial* move — deleting an anchored block from
  the middle of a file that otherwise survives, and adding an identical
  block to a brand-new file — is reported as `changed`/`deleted`, **not**
  `moved`, because git never pairs a merely-modified file as a rename
  source. `reanchor-retire` therefore models the move as a whole-file
  relocation (`git mv`, content unchanged) with a sub-range anchor, which
  reliably triggers `Moved` — this is normal, documented behavior, not a
  bug being exploited.
- `git span list --porcelain` emits one tab-separated row per anchor
  (`name\tpath\tstart-end`, or `name\tpath` alone for a whole-file anchor);
  used this instead of scraping human-formatted output for all graders.
- Span names are strict kebab-case per segment (`^[a-z0-9][a-z0-9-]*(/...)*$`);
  uppercase, leading dots, and underscores are all rejected with a clear
  `invalid name` error — confirmed empirically before relying on it in
  `declare-coupling`'s grader.
- `git span why <name>` with no writer flag just prints the current why
  (exit 0), which graders use directly for read-only checks.

---

# Round 2: triage-mixed-drift and consistent-update

Two new failure-capable scenarios, verified with the same discipline: setup
run twice and diffed for determinism; `grade.sh` run against the untouched
env (confirmed non-zero); the intended solution performed by hand with the
real CLI against a second fresh copy (confirmed `grade.sh` exits 0); plus,
for `triage-mixed-drift`, two additional adversarial "bad solve" runs to
confirm the dead-span bait is actually caught and not just structurally
plausible.

## 5. triage-mixed-drift

Setup declares three spans in one repo and drifts each a different way in
separate commits:

- `notifications/dispatch-doc-sync` — `git mv src/legacy_dispatch.py
  src/dispatch.py` (content unchanged) → reported `Moved`.
- `notifications/rate-limit-doc-sync` — `should_throttle`'s parameter is
  renamed (cosmetic refactor, doc's "20 per minute" claim stays true) →
  reported `Changed`, coupling still holds.
- `notifications/backoff-retry-doc-sync` — `retry_with_backoff` is deleted
  from `src/retry.py` entirely, and its doc paragraph is deleted from
  `docs/retry.md` entirely, leaving the *unrelated, still-live*
  `simple_retry` feature's text sitting at the exact same anchor line
  numbers → reported `Changed` on both anchors (same CLI verdict as the
  rate-limit case — the CLI cannot distinguish "still holds" from "dead" for
  you; that judgment call is the point of the scenario).

```
$ bash setup.sh triage-mixed-drift-A
$ bash setup.sh triage-mixed-drift-B
$ diff <(git -C A log --format=%s) <(git -C B log --format=%s)   # identical
$ diff -r A/.span B/.span; diff -r A/src B/src; diff -r A/docs B/docs         # all identical

$ git span stale   # on a fresh setup
## notifications/dispatch-doc-sync
- src/legacy_dispatch.py#L4-L7 — moved to src/dispatch.py#L4-L7
## notifications/rate-limit-doc-sync
- src/rate_limit.py#L7-L8 — changed
## notifications/backoff-retry-doc-sync
- docs/retry.md#L3-L3 — changed
- src/retry.py#L4-L11 — changed
exit=1

# Confirmed --fix does NOT over-reach: it resolves only the Moved anchor.
$ git span stale --fix
Reconciled 1 span, 1 anchor (1 updated, 0 removed).   # dispatch only
$ git span stale   # rate-limit and backoff-retry both STILL drifting, unchanged
## notifications/rate-limit-doc-sync
- src/rate_limit.py#L7-L8 — changed
## notifications/backoff-retry-doc-sync
- docs/retry.md#L3-L3 — changed
- src/retry.py#L4-L11 — changed
exit=1

$ bash grade.sh triage-mixed-drift-A     # untouched (module rebuilt fresh)
FAIL: git span stale exited 1 ...
FAIL: no span anchors src/dispatch.py
FAIL: an anchor on the retired src/legacy_dispatch.py still exists: ...
FAIL: a span still anchors the retired backoff-retry files: notifications/backoff-retry-doc-sync ...
FAIL: triage-mixed-drift not satisfied
grade exit=1

# Correct solution, against B:
$ git span stale --fix                                            # (i) moved -> auto-fixed
$ git span add notifications/rate-limit-doc-sync src/rate_limit.py#L7-L8
$ git span why notifications/rate-limit-doc-sync -m "Per-minute rate limit whose threshold the doc restates for API consumers."
                                                                    # (ii) changed, coupling holds -> re-anchor, why unchanged
$ git span delete notifications/backoff-retry-doc-sync             # (iii) dead coupling -> delete, not re-anchor
$ git add .span && git commit -m "Triage mixed drift: ..."

$ bash grade.sh triage-mixed-drift-B
PASS: working tree clean
PASS: git span stale exits 0
PASS: span 'notifications/dispatch-doc-sync' anchors src/dispatch.py
PASS: src/dispatch.py anchor range 4-7 covers the dispatch function
PASS: span 'notifications/dispatch-doc-sync' still anchors docs/dispatch.md
PASS: no anchor remains on retired src/legacy_dispatch.py
PASS: span 'notifications/rate-limit-doc-sync' anchors src/rate_limit.py
PASS: src/rate_limit.py anchor range 7-8 covers should_throttle
PASS: span 'notifications/rate-limit-doc-sync' still anchors docs/rate_limit.md
PASS: span 'notifications/rate-limit-doc-sync' why intact and on-topic: ...
PASS: no span anchors src/retry.py or docs/retry.md (dead coupling fully retired)
PASS: triage-mixed-drift satisfied
grade exit=0
```

**Bait check (adversarial, both variants of "wrongly keep the dead span"):**

1. `--fix` + re-anchor rate-limit + naive `git span add
   notifications/backoff-retry-doc-sync src/retry.py#L4-L8
   docs/retry.md#L3-L3` (add without removing the old anchor first, the
   sloppy idiom) — `grade.sh` fails with `git span stale exited 1` (the old
   `L4-L11` anchor is still there, still drifting) *and* the "span still
   anchors the retired backoff-retry files" check.
2. A *clean* re-anchor idiom — `git span remove ... L4-L11 ...` then
   `git span add ... L4-L8 ...` (properly retiring the old anchor first,
   pointing the survivor at the unrelated `simple_retry` text) — `stale`
   goes clean, but `grade.sh` still correctly fails on "a span still anchors
   the retired backoff-retry files (should be deleted, not re-anchored)",
   because the check is file-based (no span may anchor `src/retry.py` or
   `docs/retry.md` at all post-fix), not just "is stale clean." Confirmed
   both bad-solve variants fail; only actual deletion of the span passes.

## 6. consistent-update

Setup declares one already-CLEAN span (`ops/retry-limit-doc-sync`) coupling
`RETRY_LIMIT = 5` in `src/config.py` to "up to 5 times" in `docs/config.md`.
The task is a product-change request: raise the limit to 7, keep the repo
consistent.

```
$ bash setup.sh consistent-update-A
$ bash setup.sh consistent-update-B
$ diff <(git -C A log --format=%s) <(git -C B log --format=%s)   # identical
$ diff -r A/.span B/.span; diff -r A/src B/src; diff -r A/docs B/docs         # all identical

$ bash grade.sh consistent-update-A     # untouched
PASS: working tree clean
FAIL: src/config.py still has RETRY_LIMIT = 5 (code not updated)
FAIL: docs/config.md still says '5 times' (doc not updated)
FAIL: consistent-update not satisfied
grade exit=1

# Correct solution, against B:
$ sed -i 's/RETRY_LIMIT = 5/RETRY_LIMIT = 7/' src/config.py
$ sed -i 's/up to 5 times/up to 7 times/' docs/config.md
$ git add src/config.py docs/config.md
$ git span add ops/retry-limit-doc-sync src/config.py#L3-L3 docs/config.md#L3-L3
Added 0 anchors and resolved 2 in place ... (hash changed) x2
$ git span why ops/retry-limit-doc-sync -m "Retry limit constant whose value the doc restates for operators."
$ git add .span && git commit -m "Raise retry limit to 7 and keep the doc consistent"

$ bash grade.sh consistent-update-B
PASS: working tree clean
PASS: src/config.py has RETRY_LIMIT = 7
PASS: docs/config.md says '7 times'
PASS: git span stale exits 0
PASS: span 'ops/retry-limit-doc-sync' anchors src/config.py
PASS: span 'ops/retry-limit-doc-sync' still anchors docs/config.md
PASS: src/config.py anchor range 3-3 covers the RETRY_LIMIT line
PASS: docs/config.md anchor range 3-3 covers the '7 times' sentence
PASS: consistent-update satisfied
grade exit=0
```

**Trap checks (adversarial):**

1. Code-only edit (bump `RETRY_LIMIT` to 7, re-anchor that one anchor,
   commit; leave the doc at "5 times") — `grade.sh` fails on "docs/config.md
   still says '5 times'" and on the doc-side anchor-content check.
2. Both sides edited but the span left drifted (no `git span add`/commit of
   `.span/`) — value checks pass, but `grade.sh` fails on `git span stale
   exited 1`.
3. (Not separately re-tested here since it's structurally identical to the
   above:) doc-only edit fails symmetrically on the code-side check.

All three intended failure modes are caught.

## Round-2 CLI notes

- Confirmed empirically (per team lead's request) that `git span stale
  --fix` on a repo with a `Moved` anchor and two independent `Changed`
  anchors touches **only** the `Moved` one; the two `Changed` anchors are
  byte-for-byte untouched by `--fix` and still report drift afterward. This
  matches the documented behavior (whitespace-equivalent `Changed` anchors
  are also fixable, but neither drifted anchor here is whitespace-only) and
  is not something either scenario relies on as a workaround — `--fix` is
  simply the correct, intended step for the Moved leg of
  `triage-mixed-drift`.
- The CLI's `stale` verdict cannot distinguish "coupling still holds"
  (rate-limit leg) from "coupling is dead" (backoff-retry leg) — both show
  up as plain `Changed`. That's deliberate: the scenario's difficulty is
  entirely in reading the repository to make that judgment call, not in any
  CLI quirk.
- `git span delete <name>` prints a `(destructive)` warning and a reminder
  to run `git span list` to confirm before committing — no special handling
  needed in the grader beyond checking the name is absent from
  `git span list --porcelain` afterward.

---

# Grader-gap fix: duplicate-span solves passing (post round-2 trial autopsy)

**Finding:** round-2 trial t017 (variant-b, `consistent-update`) had the agent
leave the value-updated *original* span alone... actually re-anchor the
original span correctly (so `git span stale` went clean) but ALSO declare a
second, redundant span under a new name covering the same two sites. The old
`consistent-update` grader only ever picked *one* span that satisfied the
per-anchor checks and never looked at whether the corpus grew an extra
member, so it passed. This is a structural blind spot: every grader that
finds "a span satisfying X" via `awk '... {print $1; exit}'` without also
constraining the total span count will pass a solve that does the right
thing *and* leaves (or adds) a spurious duplicate alongside it.

**Fix applied to all five spans-get-mutated scenarios** (`inspect-report` is
read-only and exempt): add an explicit corpus-shape check.

- `consistent-update`: exact name-set check (per explicit instruction) —
  `git span list --porcelain` span names must equal exactly
  `{ops/retry-limit-doc-sync}`.
- `reconcile-drift`: exact count check — exactly 2 spans total.
- `reanchor-retire`: exact count check — exactly 1 span total.
- `declare-coupling`: exact count check — exactly 1 *new* span beyond the
  pre-existing `ops/logging-event-doc-sync` (was already partially guarding
  via `new_spans` non-empty; tightened to also reject >1 new span).
- `triage-mixed-drift`: exact count check — exactly 2 spans total (dispatch
  + rate-limit survive; backoff-retry is deleted). Found this same gap here
  independently while auditing (not explicitly flagged by the team lead, but
  same structural cause) and fixed it too.

Count-based (not exact-name) checks were used for `reconcile-drift`,
`reanchor-retire`, `declare-coupling`, and `triage-mixed-drift` deliberately,
to preserve the pre-existing, intentional design choice in those graders
that a solve may re-anchor a drifted span under a *different* name (their
docstrings already say "identity may have been kept or... re-added under
the same/different span name") — only *adding an extra* member is
disallowed, not renaming.

## Verification: consistent-update (the reported gap)

```
$ bash setup.sh consistent-update-A
$ bash setup.sh consistent-update-B
$ diff <(git -C A log --format=%s) <(git -C B log --format=%s)   # identical
$ diff -r A/.span B/.span                                        # identical

$ bash grade.sh consistent-update-A                # untouched, still fails as before
FAIL: src/config.py still has RETRY_LIMIT = 5 ...
FAIL: docs/config.md still says '5 times' ...
grade exit=1

# Original correct solve, re-run against B -- still passes:
$ sed -i 's/RETRY_LIMIT = 5/RETRY_LIMIT = 7/' src/config.py
$ sed -i 's/up to 5 times/up to 7 times/' docs/config.md
$ git add src/config.py docs/config.md
$ git span add ops/retry-limit-doc-sync src/config.py#L3-L3 docs/config.md#L3-L3
$ git span why ops/retry-limit-doc-sync -m "..."
$ git add .span && git commit -m "Raise retry limit to 7 and keep the doc consistent"
$ bash grade.sh consistent-update-B
PASS: working tree clean
PASS: src/config.py has RETRY_LIMIT = 7
PASS: docs/config.md says '7 times'
PASS: git span stale exits 0
PASS: span corpus is still exactly [ops/retry-limit-doc-sync] (no duplicate/extra span added)
... (all other PASS as before)
PASS: consistent-update satisfied
grade exit=0

# t017-shape adversarial: original span RECONCILED (stale goes clean) AND a
# redundant duplicate span added under a new name -- the exact shape that
# slipped through the old grader:
$ git span add ops/retry-limit-doc-sync src/config.py#L3-L3 docs/config.md#L3-L3   # reconcile original
$ git span add ops/retry-limit-doc-sync-v2 src/config.py#L3-L3 docs/config.md#L3-L3 # + redundant duplicate
$ git commit -m "bad solve 2: original reconciled AND a redundant duplicate span added"
$ git span stale
0 stale across 2 spans (4 anchors checked)          # <- clean; old grader would have PASSED this
$ bash grade.sh .
PASS: working tree clean
PASS: src/config.py has RETRY_LIMIT = 7
PASS: docs/config.md says '7 times'
PASS: git span stale exits 0
FAIL: span corpus changed shape -- expected exactly [ops/retry-limit-doc-sync], found:
ops/retry-limit-doc-sync
ops/retry-limit-doc-sync-v2
FAIL: consistent-update not satisfied
grade exit=1                                        # <- now correctly rejected
```

Also re-ran the naive variant (old span left untouched, still drifting, plus
a new duplicate span) — that one already failed before this fix too, since
`git span stale` alone catches an unreconciled original; the tightening
specifically closes the gap where the original *was* correctly reconciled
and an extra duplicate was added on top.

## Verification: the other three round-1 graders + triage-mixed-drift

Same three-way check for each (fresh double-build determinism already
re-confirmed identical to the original round-1/round-2 runs; correct
manual solve re-run and still passes; new duplicate-span adversarial run
added and confirmed to now fail):

**reconcile-drift** — adversarial: reconcile `ops/retry-behavior-doc-sync`
correctly, then also add `ops/retry-behavior-doc-sync-v2` anchoring the same
two sites.
```
$ bash grade.sh .
...
FAIL: expected exactly 2 spans in the corpus, found 3:
ops/retry-behavior-doc-sync
ops/retry-behavior-doc-sync-v2
ops/timeout-behavior-doc-sync
FAIL: reconcile-drift not satisfied
grade exit=1
```
Correct solve (no duplicate) still: `PASS: span corpus still has exactly 2
spans` → `grade exit=0`. Untouched env still: `grade exit=1` (stale drift,
as before).

**reanchor-retire** — adversarial: re-anchor `parsing/tokenizer-doc-sync`
correctly (remove old anchor, add new), then also add
`parsing/tokenizer-doc-sync-v2` anchoring the same new location.
```
$ bash grade.sh .
...
FAIL: expected exactly 1 span in the corpus, found 2:
parsing/tokenizer-doc-sync
parsing/tokenizer-doc-sync-v2
FAIL: reanchor-retire not satisfied
grade exit=1
```
Correct solve still: `PASS: span corpus still has exactly 1 span` →
`grade exit=0`. Untouched env still: `grade exit=1` (Moved drift, as
before).

**declare-coupling** — adversarial: declare the correct new span
`ops/retry-count-doc-sync`, then also declare a second new span
`ops/retry-count-doc-sync-v2` covering the same coupling.
```
$ bash grade.sh .
...
FAIL: expected exactly 1 new span beyond 'ops/logging-event-doc-sync', found 2 (redundant duplicate declaration):
ops/retry-count-doc-sync
ops/retry-count-doc-sync-v2
FAIL: declare-coupling not satisfied
grade exit=1
```
This confirms the team lead's "probably fine" guess was actually wrong —
the pre-tightening grader picked whichever new span happened to satisfy the
per-anchor checks and never checked there was only one. Correct (single new
span) solve still: `grade exit=0`. Untouched env still: `grade exit=1` (no
new span at all).

**triage-mixed-drift** (found independently while auditing for the same
class of gap, not explicitly named by the team lead but same root cause) —
adversarial: correctly triage all three legs (fix moved, re-anchor changed,
delete dead), then also add a redundant duplicate
`notifications/dispatch-doc-sync-v2` anchoring the already-correctly-fixed
dispatch site.
```
$ bash grade.sh .
...
FAIL: expected exactly 2 spans in the corpus (dispatch + rate-limit; backoff-retry deleted), found 3:
notifications/dispatch-doc-sync
notifications/dispatch-doc-sync-v2
notifications/rate-limit-doc-sync
FAIL: triage-mixed-drift not satisfied
grade exit=1
```
Correct solve still: `PASS: span corpus has exactly 2 spans` → `grade
exit=0`. Untouched env still fails on drift + missing/leftover anchors as
before, and now additionally on span count. Both original bait checks
(sloppy add-without-remove, and clean remove+add re-anchor onto the leftover
`simple_retry` text) were re-run and still correctly fail.

**Net result:** all six scenario graders now reject the "do the right thing
plus leave/add a spurious duplicate span" failure mode, while every
previously-verified correct solve and every previously-verified
untouched/adversarial failure still resolves the same way.
